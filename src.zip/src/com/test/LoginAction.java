package com.test;

import java.io.FileInputStream;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.ctl.app.virtual.util.LDAPUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport implements ServletRequestAware,SessionAware
{
	private String UserName;
    protected HttpServletRequest request;
    protected Map session;
    private String Password;
    boolean authenticated;
    RxContextPathDeploymentUtil util;
    String pathUser;
    Properties pro;

    public LoginAction()
    {
    	System.out.println("Inside login action");
        authenticated = false;
        util = new RxContextPathDeploymentUtil();
        System.out.println("Before replacement of path");
        pathUser = util.getConfigItPath().replace("it", "VirtualAppUser.properties");
        System.out.println("path user is"+pathUser);
        pro = new Properties();
    }

	
	public String getUserName() {
		return UserName;
	}



	public void setUserName(String userName) {
		UserName = userName;
	}



	public String getPassword() {
		return Password;
	}



	public void setPassword(String password) {
		Password = password;
	}

	
  public Map getSession() {
		return session;
	}



	public void setSession(Map sess) {
		this.session = sess;
	}



@Override
   public String execute() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("inside executemethod");
	return "success";
}
   public String logout(){
	   if(session!=null){
		   System.out.println("In logout");
		    session.clear();
	   }
	   return "success";
   }
	public String validation() {
		//Map session = (Map) ActionContext.getContext().get("session");
		System.out.println("inside validation method");
		session.put("UserName", UserName);
		try {
			System.out.println("pathUser value is"+pathUser);
		    FileInputStream f1= new FileInputStream(pathUser);
		    pro.load(f1);
		    
		} catch (Exception e) {
		   System.out.println("exception is"+e);
		   e.printStackTrace(); 
		}
		//String users[]=pro.getProperty("virApp.users").split(",");
		LDAPUtil authenticator = new LDAPUtil();
			authenticated = authenticator.authenticate(UserName,Password);
			System.out.println(authenticated);
			if (authenticated) {
				
				  return "success";  
				     }  
				      else{
				    	  addActionError(pro.getProperty("virApp.LoginPassError"));
				          return "error";  
				      }  
		}
	
	public String validateAdmin() {
		System.out.println("inside validation admin method");
		try {
		    FileInputStream f1= new FileInputStream(pathUser);
		    pro.load(f1);
		    
		} catch (Exception e) {
		   e.printStackTrace(); 
		}
		String admin[]=pro.getProperty("virApp.admin").split(",");
		
		//System.out.println("Admin: "+admin);
		LDAPUtil authenticator = new LDAPUtil();
		for(int i=0;i<admin.length;i++){
		if(admin[i].equalsIgnoreCase(UserName))
		{
			authenticated = authenticator.authenticate(UserName,Password);
			System.out.println(authenticated);
			if (authenticated) {
				  return "success";  
				     }  
				      else{  
				          addActionError(pro.getProperty("virApp.LoginPassError"));
				          return "error"; 
				      }  
		}
		}
		
		addActionError(pro.getProperty("virApp.adminAuthError"));
		return "error";
	}
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
		
	}



	
	
}
