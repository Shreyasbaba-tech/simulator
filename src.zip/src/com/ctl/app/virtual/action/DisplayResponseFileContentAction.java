package com.ctl.app.virtual.action;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.app.virtual.AddResponseInfo;
import com.ctl.app.virtual.util.AddKeyValueUtil;
import com.ctl.app.virtual.util.AddResponseUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;

public class DisplayResponseFileContentAction implements ServletRequestAware,ServletResponseAware  {
	private HttpServletRequest request;
	private HttpServletResponse response;

	public String execute() throws IOException 
{
		
		RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
        String path=contextDeploymentUtil.getConfigItPath().replace("it", "VirtualConfig.properties");
        Properties pro = new Properties();
		try {
			FileInputStream f = new FileInputStream(path);
			pro.load(f);
		} catch (Exception e) {
			
		}
		
		
	String responsePath=pro.getProperty("ResponeFilePath")+"/"+request.getParameter("appId")+"/"+request.getParameter("system")+"/"+request.getParameter("subSystem")+"/"+request.getParameter("keyName");
	
	AddResponseInfo info = new AddResponseInfo();
	info.setAppId(request.getParameter("appId"));
	info.setSystem(request.getParameter("system"));
	info.setSubSystem(request.getParameter("subSystem"));
	info.setKey(request.getParameter("keyName"));
	
	AddResponseUtil util = new AddResponseUtil();
	String output = util.readResponseFileContents(info);
	//AddKeyValueUtil addKeyValueUtil=new AddKeyValueUtil();
	//String output=addKeyValueUtil.displayControlFileContent(responsePath);
	
	response.setContentType("text/text;charset=utf-8");
	response.setHeader("cache-control", "no-cache"); 
	PrintWriter out;
	try {
		out = response.getWriter();
		out.println(output); 
		out.flush(); 

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	

	return null;
}



public void setServletRequest(HttpServletRequest arg0) {
	this.request=arg0;
	
}

public HttpServletRequest getRequest() {
	return request;
}
public HttpServletResponse getResponse() {
	return response;
}

public void setResponse(HttpServletResponse response) {
	this.response = response;
}
public void setRequest(HttpServletRequest request) {
	this.request = request;
}


public void setServletResponse(HttpServletResponse arg0) {
	this.response=arg0;
	
}










}
