package com.ctl.app.virtual.action;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ctl.app.virtual.AddResponseInfo;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;

public class SaveResponseMappingAction implements ServletRequestAware,ServletResponseAware  {
	private HttpServletRequest request;
	private HttpServletResponse response;
	private AddResponseInfo responseInfo;
	private boolean mappingPresent = false;
	private String presentResponse;
	private boolean mappedTNPresent = false;

public String execute(){
	
	 String responses = (String)request.getSession().getAttribute("responses");
	 String[] responseArray = responses.split("\\#\\$\\#");
	boolean res =true;
	int i=0;
	boolean[] result = new boolean[responseArray.length];
	 for(String resp:responseArray)
		{
		result[i] = addToTNMappingDB(resp);
		 i++;
		 
		}
	
	 for(int j=0;j<result.length;j++)
	 {
		 if(result[j]==false)
			 res=false;
	 }
	
	if(res)
	return "success";
	else if(res == false) return"mappingPresent";
	else return "error";
}
	

public boolean addToTNMappingDB(String responseString)
{
	mappedTNPresent = false;
	mappingPresent = false;
	boolean result=false;
String TN=(request.getParameter("TN"));
	
	RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
	 String TNMappingDBPath=contextDeploymentUtil.getConfigItPath()+"TNMappingDB.xml";
	
	    
	    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db;
		try {
			db = dbf.newDocumentBuilder();
			Document document = db.parse(TNMappingDBPath);
			NodeList list = document.getElementsByTagName("mappedTN");
			
			//code to check if TN mapping is present 
			
			
			//Node curNode = null  ;
			for(int i = 0; i < list.getLength();i++)
			{
		 
				if(list.item(i).getAttributes().item(0).getTextContent()!= null)
				{
					if(list.item(i).getAttributes().item(0).getTextContent().equals(TN))
					
					{
						mappedTNPresent = true;
						NodeList innerList = document.getElementsByTagName("mappedService");
						
						for(int j=0;j<innerList.getLength();j++)
						
						{
						String contentFromXml = (String)innerList.item(j).getTextContent().split("\\|\\|")[3].trim().replaceAll("\\\\n", "");
						String contentFromUser = (String)responseString.split("\\|\\|")[3].trim().replaceAll("\\\\n", "");
						System.out.println("left = --" + contentFromXml+"--");
						System.out.println("right = --" + contentFromUser+"--");
						
					     if(contentFromXml.equals(contentFromUser))
					    		 {
					    		mappingPresent =true;
					    		presentResponse= innerList.item(j).getTextContent().split("\\|\\|")[3];
					    		request.getSession().setAttribute("presentResponse", presentResponse);
					    
					    		 }
					     
						} 
					   //  curNode = list.item(i);
				}
				}
			}
			
			
		
			 if(mappingPresent == false && mappedTNPresent == false)
			{
				System.out.println("TN mapping not present.Mapping Not present.Creating new one");
				Node textNode = document.createTextNode(responseString);
				Element newNode = document.createElement("mappedTN");
				
				newNode.setAttribute("TN", TN);
				//newNode.appendChild(document.createAttribute("TN"));
				//////////newNode.getAttributes().
				Node mappedServiceNode = document.createElement("mappedService");
				mappedServiceNode.appendChild(textNode);
				newNode.appendChild(mappedServiceNode);
				document.getElementsByTagName("TNMappings").item(0).appendChild(newNode);
			    result = true;
			   // mappingPresent = false;
			 
			}
			 
			 
			 if(mappingPresent == false && mappedTNPresent == true)
			 {
				 System.out.println("Mapping present for the new TN. Adding a mapping to it");
				 Node textNode = document.createTextNode(responseString);
				 Node mappedServiceNode = document.createElement("mappedService");
					mappedServiceNode.appendChild(textNode);
					
				Node mappedNode = null;
				
				for(int i =0 ;i<list.getLength() ;i++)
				{
					if(list.item(i).getAttributes().item(0).getTextContent()!= null)
					{
						if(list.item(i).getAttributes().item(0).getTextContent().equals(TN))
						
						{
							mappedNode = list.item(i);
							
						}
					
					}	
				}
				
				mappedNode.appendChild(mappedServiceNode);
				result = true;
				mappedTNPresent = false;
				
				 
			 }
			
			 
			  TransformerFactory tff  = TransformerFactory.newInstance();
				Transformer transformer = tff.newTransformer();
				DOMSource xmlSource = new DOMSource(document);
				StreamResult outputTarget = new StreamResult(TNMappingDBPath);
				transformer.transform(xmlSource, outputTarget);
				
				
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	
	
	
	return result;
}
/*	
	public String execute() throws IOException 
{
		
	String TN=(request.getParameter("TN"));

	
	//String responses=(request.getParameter("responseInfoField"));
	String responses = (String)request.getSession().getAttribute("responses");
	 HashMap<String, List<AddResponseInfo>> map = convertToMap(responses,TN);
	 
	 Object obj = request.getSession().getAttribute("UseCaseToTNMapping");
	
	HashMap<String, List<AddResponseInfo>> useCaseToTNMapping = (HashMap<String, List<AddResponseInfo>>) obj;
	 	if(map != null && useCaseToTNMapping!= null)
	 	{
		 useCaseToTNMapping.putAll(map);
		 request.getSession().setAttribute("UseCaseToTNMapping", useCaseToTNMapping);
	 	}
	 	else if (useCaseToTNMapping == null) {
	 		request.getSession().setAttribute("UseCaseToTNMapping", map);
		}
	 	
	// request.getSession().setAttribute("UseCaseToTNMapping", useCaseToTNMapping);	
	 
	 
	 
	System.out.println("responses stored in session ");
	return "success";
}

	
	public HashMap<String, List<AddResponseInfo>> convertToMap(String responses,String TN) {
		HashMap<String, List<AddResponseInfo>> res = new HashMap<String, List<AddResponseInfo>>() ;
		String[] responseArray = responses.split("\\#\\$\\#");
		List<AddResponseInfo> list = new ArrayList<AddResponseInfo>();
		for(String resp:responseArray)
		{
			if(resp!=null)
			{
			String[] curResponseInfo = resp.split("\\|\\|");
			
			AddResponseInfo info = new AddResponseInfo();
			info.setAppId(curResponseInfo[0]);
			info.setSystem(curResponseInfo[1]);
			info.setSubSystem(curResponseInfo[2]);
			info.setKey(curResponseInfo[3]);
			list.add(info);
			//res.put("currentResponseKey", info);
			}
			
		}
		res.put( TN, list);
		return res;
	}
*/


public void setServletRequest(HttpServletRequest arg0) {
	this.request=arg0;
	
}

public HttpServletRequest getRequest() {
	return request;
}
public HttpServletResponse getResponse() {
	return response;
}

public void setResponse(HttpServletResponse response) {
	this.response = response;
}
public void setRequest(HttpServletRequest request) {
	this.request = request;
}


public void setServletResponse(HttpServletResponse arg0) {
	this.response=arg0;
	
}



public AddResponseInfo getResponseInfo() {
	return responseInfo;
}



public void setResponseInfo(AddResponseInfo responseInfo) {
	this.responseInfo = responseInfo;
}










}
