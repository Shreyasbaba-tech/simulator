package com.ctl.app.virtual.action;



import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.ctl.app.virtual.util.AddKeyValueUtil;
import com.ctl.app.virtual.util.AddServiceUtil;
import com.ctl.app.virtual.util.SearchKeyUtil;
import com.ctl.app.virtual.util.ValidationUtil;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.opensymphony.xwork2.ActionSupport;

public class GenerateReportAction extends ActionSupport implements ServletRequestAware {

	private AddKeyValueUtil util;
	private HttpServletRequest request;
	String root = SimulatorContextBeanPropertUtil.getResponseFilePath();
	private SearchKeyUtil searchKeyUtil;
	private AddServiceUtil addServiceUtil;
	private ValidationUtil validationUtil;
	
	public GenerateReportAction(){
		
		if(validationUtil == null){
			validationUtil = new ValidationUtil();
		}
		if(addServiceUtil==null)
		{
			addServiceUtil = new AddServiceUtil();
		}
		if(searchKeyUtil==null)
		{
			searchKeyUtil = new SearchKeyUtil();
		}
		if(util==null)
		{
			util = new AddKeyValueUtil();
		}
	}
	
	public String execute(){
		
		String data = "";
		
		System.out.println("Root = "+root);
		String[] apps = util.getAppIds(root);
		//request.setAttribute("apps", apps);
		for(String app:apps)
		{
			String[] systems = util.getSystems(app, root);
			Integer numOfSystems = systems.length;
			Integer numOfSubSystems = 0;
			Integer numOfResponses = 0;
			for(String sys:systems)
			{
				String[] subSys = util.getSubSystems(sys, root + app+"//");
				numOfSubSystems += subSys.length;
				for(String sub:subSys)
				{
					System.out.println("Response path------->"+app+"/"+sys+"/"+sub);
				}
				for(String sub:subSys)
				{
					String[] resp = util.getResponseFiles(sub, root +app+"//"+sys);
					numOfResponses += getLength(resp);
				}
			}
			
		 	data += app +"|"+numOfSystems+"|"+numOfSubSystems+"|"+numOfResponses+"@@";		
		}
		
		System.out.println(data.toString());
		request.setAttribute("data", data);
		
		return "success";
	}
	
	public String generateSystemReport()
	{
		System.out.println("Hits generateSystemReport action");
		String data = "";
		String appId = (String)request.getParameter("appId");
		//System.out.println((String)request.getParameter("appId"));
		
		
		
		String[] systems = util.getSystems(appId, root);
		String complexity="";
		
		
		for(String sys:systems)
		{
			Integer numOfSubSystems = 0;
			Integer numOfResponses = 0;
			String[] subSys = util.getSubSystems(sys, root + appId+"//");
			numOfSubSystems += subSys.length;
			complexity = addServiceUtil.getServiceComplexity(appId,sys);
			for(String sub:subSys)
			{
				String[] resp = util.getResponseFiles(sub, root +appId+"//"+sys+"//");
				numOfResponses += getLength(resp);
			}
		
		
	 	data += sys +"|"+numOfSubSystems+"|"+numOfResponses+"|"+complexity+"@@";	
		
		}
		
		System.out.println(data);
	    request.setAttribute("data", data);
	    request.setAttribute("appId", appId);
	 	return "success";
	}
	
	public String generateSubSystemReport()
	{
		System.out.println("Hits generateSubSystemReport action");
		String data = "";
		String appId = (String)request.getParameter("appId");
	    String system = (String)request.getParameter("system");
		
	    System.out.println("system: "+system);
		String[] systems = util.getSystems(appId, root);
	    
		
		if(system==null)
		for(String sys:systems)
		{
			Integer numOfResponses = 0;
		String[] subSystems = util.getSubSystems(sys, root+appId);
			for(String subSys:subSystems)
		{
			
				String[] resp = util.getResponseFiles(subSys, root + appId+"//"+sys);
				numOfResponses = getLength(resp);
				
				data +=sys+"|"+ subSys +"|"+numOfResponses+"@@";
		}
		}
		else
			for(String sys:systems)
			{
				Integer numOfResponses = 0;
			String[] subSystems = util.getSubSystems(sys, root+appId);
			if(sys!=null)
			if(sys.equals(system))
			{	System.out.println("inside if system: "+sys+system);
				for(String subSys:subSystems)
			    {
				
					String[] resp = util.getResponseFiles(subSys, root + appId+"//"+sys);
					numOfResponses = getLength(resp);
					
					data +=sys+"|"+ subSys +"|"+numOfResponses+"@@";
			    }
			}		
				
			}
		
		System.out.println(data);
	    request.setAttribute("data", data);
	    request.setAttribute("appId", appId);
	   
	 	return "success";
	}
	
	
	public String generateResponseReport()
	{
		System.out.println("Hits generateResponseReport action");
		String respCount = request.getParameter("respCount")==null?"0":(String)request.getParameter("respCount");
		//System.out.println("respCount = "+respCount);
		String pageNo = (String)request.getParameter("pageNo");
		//System.out.println("PageNo = "+pageNo);
		int pNo = 1;
		if(pageNo!=null && !pageNo.equals("")){
			pNo = Integer.parseInt(pageNo);
		}
		//System.out.println("PageNo = "+pNo);
		String data = "";
		String appId = (String)request.getParameter("appId");
		String system = (String)request.getParameter("system");
		
		String[] systems = util.getSystems(appId, root);
		String systemName = "";
		String responseName = "";
		String searchTags = "";
		
		if (system == null || system.equalsIgnoreCase("null")){
			System.out.println("I am in IF");
			int count = 0;
			for (String sys : systems) {
				String[] subSys = util.getSubSystems(sys, root + appId + "//");
				systemName = sys;
				for (String sub : subSys) {
					String[] resp = util.getResponseFiles(sub, root + appId	+ "//" + sys);
					for (String res : resp) {
						count++;
						if (res != null && count>((pNo*10)-10) && count <= (pNo*10)) {
							searchTags = searchKeyUtil.fetchSearchTags(appId, sys, sub, res);
							responseName = res;
							if (searchTags == null)
								searchTags = "NONE";
							data += responseName + "|" + systemName + "|" + searchTags+ "|" + sub + "@@";
						}
					}
				}
			}
		}
		else{
			System.out.println("I am in else");
			int count = 0;
			for (String sys : systems) {
				String[] subSys = util.getSubSystems(sys, root + appId + "//");
				systemName = sys;
				if (sys != null)
					if (sys.equals(system))
						for (String sub : subSys) {
							String[] resp = util.getResponseFiles(sub, root	+ appId + "//" + sys);
							for (String res : resp) {
								count++;
								if (res != null && count>((pNo*10)-10) && count <= (pNo*10)) {
									searchTags = searchKeyUtil.fetchSearchTags(appId, sys, sub, res);
									// searchTags =
									// searchKeyUtil.fetchSearchTags(appId,sys,sub,res);
									responseName = res;
									if (searchTags == null)
										searchTags = "NONE";
									data += responseName + "|" + systemName	+ "|" + searchTags+ "|" + sub + "@@";
								}
							}
						}
			}
		}
		System.out.println("data in generate system report action : "+data);
	 	request.setAttribute("appId", appId);
		request.setAttribute("data", data);
	 	request.setAttribute("system", system);
	 	request.setAttribute("respCount", respCount);
		
		return "success";
	}
	
	
	
	public int getLength(String[] a)
	{
		int number= 0;
		for(String s:a)
		{
			if(s!=null)
				number++;
		}
		return number;
	}
	
	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}
	public HttpServletRequest getRequest() {
		return request;
	}

	

}
