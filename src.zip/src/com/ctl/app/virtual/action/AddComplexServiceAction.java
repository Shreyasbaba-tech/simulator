/**
 * 
 */
package com.ctl.app.virtual.action;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.ctl.app.virtual.AddServiceInfo;
import com.ctl.app.virtual.util.AddServiceUtil;
import com.ctl.simulation.helper.FileUtility;
import com.ctl.simulation.helper.XpathUtil;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @author aa47173
 *
 */
public class AddComplexServiceAction extends ActionSupport implements SessionAware,ServletRequestAware{
	
	private AddServiceInfo serviceInfo;
	private AddServiceUtil serviceUtil;
	private HttpServletRequest request;
	private Map<String, Object> session;
	private String serviceComplexity;
	private File xslFile;
	private String selectedXpathsToAction;
	private String selectedValueXpathsToAction;	
	private String selectedOperXpathsToAction;
	private String valueOfKeyToAction;
	private String valueOfOperToAction;
	private boolean newOperFlagToAction;
	private String UserName; 
	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}	
	
	public AddComplexServiceAction() {
		if(serviceInfo==null){
			serviceInfo = new AddServiceInfo();
		}
		if(serviceUtil==null){
			serviceUtil= new AddServiceUtil();
		}
	}
	
	public String execute() throws Exception {
		UserName = (String) session.get("UserName");

		try {
			//System.out.println("Selected Keys :: "+ serviceInfo.getSelectedXpaths());
			//System.out.println("Selected Values :: " + selectedValueXpathsToAction);
			//System.out.println("Selected Operation :: " + selectedOperXpathsToAction);
			
			List<String> xpaths = new ArrayList<String>();
			File sampleResponseFile = serviceInfo.getSampleResponseFile();
			String[] strArray = StringUtils.split(serviceInfo.getSelectedXpaths(), "#");
			strArray = trimStringArray(strArray);
			String[] strArray2 = StringUtils.split(selectedValueXpathsToAction, "#");
			strArray2 = trimStringArray(strArray2);
			String[] strArray3 = StringUtils.split(selectedOperXpathsToAction, "#");
			strArray3 = trimStringArray(strArray3);
			//System.out.println("strArray length :: "+strArray.length);
			//System.out.println("strArray2 length :: "+strArray2.length);
			serviceInfo = (AddServiceInfo) session.get("serviceInfo");
			
			Map<String, String> xpathMap=(Map<String, String>)serviceInfo.getGeneratedXpathMap();
            String keyXpath="";
            String valueXpath = "";
			for (String string : strArray) {
				string = string.trim();
				xpaths.add(string);
				keyXpath = xpathMap.get(string);
				//System.out.println("-->"+string+"--"+xpathMap.get(string));
				
			}
			for (String string : strArray2) {
				string = string.trim();
				valueXpath = xpathMap.get(string);
				//System.out.println("-->"+string+"--"+xpathMap.get(string));
			}
			for (String string : strArray3) {
				string = string.trim();
				String xpathOfSelectedOperation=xpathMap.get(string);
				
				if(xpathOfSelectedOperation == null)
	 				xpathOfSelectedOperation = serviceInfo.getRestXpathMap().get(string);
				//System.out.println("-->"+string+"--"+xpathOfSelectedOperation);
			}
            
			String key = valueOfKeyToAction;
			//System.out.println("key in action = " +key);
			XpathUtil util = new XpathUtil();
			
			serviceInfo.setActionXpathValue(valueOfOperToAction.equals("NA")?"":valueOfOperToAction);		
			serviceInfo.setOperName(selectedOperXpathsToAction);
			serviceInfo.setSelectedXpathsList(xpaths);
			serviceInfo.setSampleResponseFile(sampleResponseFile);
			serviceInfo.setUserName((String) session.get("UserName"));
		
			String xpathOfSelectedOperation = xpathMap.get(selectedOperXpathsToAction);
			if(xpathOfSelectedOperation == null)
				xpathOfSelectedOperation = serviceInfo.getRestXpathMap().get(selectedOperXpathsToAction);
     		
			serviceUtil.addNewService(serviceInfo,xpathMap.get(strArray[0]),xpathMap.get(strArray2[0]),key,xpathOfSelectedOperation);
		
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String[] trimStringArray(String[] arr)
	{
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = arr[i].trim();
		}
		return arr;
	}
	
	public String loadServiceResponse() throws Exception{
		
		return "loadServiceResponse";
	}
	
	
	public AddServiceInfo getServiceInfo() {
		return serviceInfo;
	}

	public void setServiceInfo(AddServiceInfo serviceInfo) {
		this.serviceInfo = serviceInfo;
	}

	public AddServiceUtil getServiceUtil() {
		return serviceUtil;
	}

	public void setServiceUtil(AddServiceUtil serviceUtil) {
		this.serviceUtil = serviceUtil;
	}

	public void setSession(Map<String, Object> arg0) {
		this.session=arg0;
	}

	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		serviceUtil.setServletRequest(arg0);
		
	}

	public String getServiceComplexity() {
		return serviceComplexity;
	}

	public void setServiceComplexity(String serviceComplexity) {
		this.serviceComplexity = serviceComplexity;
	}

	public File getXslFile() {
		return xslFile;
	}

	public void setXslFile(File xslFile) {
		this.xslFile = xslFile;
	}

	public String getSelectedXpathsToAction() {
		return selectedXpathsToAction;
	}

	public void setSelectedXpathsToAction(String selectedXpathsToAction) {
		this.selectedXpathsToAction = selectedXpathsToAction;
	}

	public String getSelectedValueXpathsToAction() {
		return selectedValueXpathsToAction;
	}

	public void setSelectedValueXpathsToAction(String selectedValueXpathsToAction) {
		this.selectedValueXpathsToAction = selectedValueXpathsToAction;
	}

	public String getSelectedOperXpathsToAction() {
		return selectedOperXpathsToAction;
	}

	public void setSelectedOperXpathsToAction(String selectedOperXpathsToAction) {
		this.selectedOperXpathsToAction = selectedOperXpathsToAction;
	}

	public String getValueOfKeyToAction() {
		return valueOfKeyToAction;
	}

	public void setValueOfKeyToAction(String valueOfKeyToAction) {
		this.valueOfKeyToAction = valueOfKeyToAction;
	}

	public String getValueOfOperToAction() {
		return valueOfOperToAction;
	}

	public void setValueOfOperToAction(String valueOfOperToAction) {
		this.valueOfOperToAction = valueOfOperToAction;
	}

	public boolean isNewOperFlagToAction() {
		return newOperFlagToAction;
	}

	public void setNewOperFlagToAction(boolean newOperFlagToAction) {
		this.newOperFlagToAction = newOperFlagToAction;
	}

}
