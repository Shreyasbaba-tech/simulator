package com.ctl.app.virtual.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.app.virtual.util.AddKeyValueUtil;

public class AddKeyValueToControlAction implements ServletRequestAware,ServletResponseAware{
	private HttpServletRequest request;
	private HttpServletResponse response;
	private AddKeyValueUtil util;
	
	public AddKeyValueToControlAction() {
	
		this.util=new AddKeyValueUtil();
		// TODO Auto-generated constructor stub
	}
	public String execute()
	{
		
		String flag=request.getParameter("flag");
		if(flag.equals("edit"))
		{
			
			editKeyValue();
		}
		else
		{
			String controlFilePath=request.getParameter("controlFilePath");
			String key=request.getParameter("key");
			String value=request.getParameter("value");
			String curContents=request.getParameter("content");
			//System.out.println("curContents = "+curContents);
			String newDummyContents=util.addToDummy(controlFilePath,curContents, key, value);
			
			//send back the new dummy contents
			response.setContentType("text/text;charset=utf-8");
			response.setHeader("cache-control", "no-cache"); 
			PrintWriter out;
			
			try {
				out = response.getWriter();
				out.println(newDummyContents); 
				out.flush(); 
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			
		}
		
		
		return null;
	}
	
	public String editKeyValue()
	{
		String controlFilePath=request.getParameter("controlFilePath");
		String key=request.getParameter("key");
		String value=request.getParameter("value");
		String curContents=request.getParameter("content");
		
		String newDummyContents=util.editDummy(controlFilePath, curContents, key, value);
		//System.out.println("after edit " +newDummyContents);
		//send back the new dummy contents
		response.setContentType("text/text;charset=utf-8");
		response.setHeader("cache-control", "no-cache"); 
		PrintWriter out;
		
		try {
			out = response.getWriter();
			out.println(newDummyContents); 
			out.flush(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	
	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}
	public void setServletResponse(HttpServletResponse arg0) {
		this.response=arg0;
		
	}

}
