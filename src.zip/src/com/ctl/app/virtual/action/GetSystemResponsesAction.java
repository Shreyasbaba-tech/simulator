package com.ctl.app.virtual.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.app.virtual.util.AddKeyValueUtil;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;

public class GetSystemResponsesAction implements ServletRequestAware,ServletResponseAware{
private HttpServletRequest request;
private HttpServletResponse response;
	public HttpServletResponse getResponse() {
	return response;
}

public void setResponse(HttpServletResponse response) {
	this.response = response;
}

	public HttpServletRequest getRequest() {
	return request;
}

public void setRequest(HttpServletRequest request) {
	this.request = request;
}

	public String execute(){
		String system=request.getParameter("system");
		String appId=request.getParameter("appId");
		//System.out.println(system);
		String path=SimulatorContextBeanPropertUtil.getResponseFilePath()+"/"+appId+"/";
	
		
		AddKeyValueUtil addKeyValueUtil=new AddKeyValueUtil();
		String[] controlFiles=addKeyValueUtil.getControlFiles(system, path);
		String tokens=addKeyValueUtil.tokenise(controlFiles);

		response.setContentType("text/text;charset=utf-8");
		response.setHeader("cache-control", "no-cache"); 
		PrintWriter out;
		try {
			out = response.getWriter();
			out.println(tokens); 
			out.flush(); 

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return null;
	}

	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}

	public void setServletResponse(HttpServletResponse arg0) {
		this.response=arg0;
		
	}
}
