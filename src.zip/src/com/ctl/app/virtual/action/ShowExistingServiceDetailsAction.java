package com.ctl.app.virtual.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.springframework.beans.BeansException;

import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.simulator.ISimulator;
import com.ctl.simulation.simulator.WebSimulator;
import com.ctl.simulation.spring.BeanApplicationContext;
import com.opensymphony.xwork2.ActionSupport;

public class ShowExistingServiceDetailsAction extends ActionSupport implements ServletRequestAware,ServletResponseAware{
  private HttpServletRequest request;
  private HttpServletResponse response;
  final static String httpPrefix = "http://lxdenvmtc157.dev.qintra.com:9431/virtualApp/services/http/";
  final static String soapPrefix="http://lxdenvmtc157.dev.qintra.com:9431/virtualApp/services/soap/";
  final static String busSuffix="SYSTOR.CUSTSI.PROBH119";
  
  public String execute() throws Exception
  {
	
	  try {
		SimulatorContextBeanPropertUtil util=new SimulatorContextBeanPropertUtil(); 
		    String serviceURI=null;
		    String serviceType=null;
		    String appId=request.getParameter("appId");
		    String serviceName=request.getParameter("serviceName");
		
		 
		    ISimulator iSimulator;
			String beanId=null;
			
			String[] strArayyBean =(String[]) BeanApplicationContext.getApplicationBeanIds().toArray();
			for(String s:strArayyBean)
			{
				System.out.println("Bean: "+s);
				if(s.contains(serviceName+"_"+appId) || s.contains(serviceName+"."+appId))
				{
					
					beanId=s;
					break;
				}
			}
			System.out.println(beanId);
			iSimulator =(ISimulator) BeanApplicationContext.getApplicationContext().getBean(beanId);
			/*if(iSimulator.getClass().toString().contains("WebSimulator"))
			{
				
			}*/
			if(iSimulator instanceof WebSimulator){
			/*WebSimulator simulator =(WebSimulator) iSimulator;
			List<com.ctl.simulation.action.SimulatorAction> actionList=simulator.getActions();
			SimulatorAction action =actionList.get(0);
			action.getReqParams();*/
				
				serviceType="Web service";
				serviceURI=httpPrefix+beanId;
				
			}
			/*else //if(iSimulator instanceof BusSimulator)
			{
				serviceType="Bus Service";
				serviceURI=busserviceType;
				
			}
			*/
			
			String returnString=beanId+"#"+serviceURI+"#"+serviceType;
			System.out.println(returnString);
			/*response.setContentType("text/text;charset=utf-8");
			response.setHeader("cache-control", "no-cache"); 
			PrintWriter out;
			try {
				out = response.getWriter();
				out.println(returnString); 
				out.flush(); 

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} */
			
		 
	} catch (BeansException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return ERROR;
	}
	  return SUCCESS;
  }

public void setServletRequest(HttpServletRequest arg0) {
	this.request=arg0;
}

public void setServletResponse(HttpServletResponse arg0) {
	this.response=arg0;
	
}
}
