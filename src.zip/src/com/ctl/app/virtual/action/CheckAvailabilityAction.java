package com.ctl.app.virtual.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.app.virtual.util.AddServiceUtil;

public class CheckAvailabilityAction implements ServletRequestAware,ServletResponseAware{
	private HttpServletRequest request;
	private HttpServletResponse response;
     private AddServiceUtil addServiceUtil;
     
     public CheckAvailabilityAction() {
		addServiceUtil=new AddServiceUtil();
	}
     
	public void setServletResponse(HttpServletResponse arg0) {
		this.response=arg0;
		
	}

	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}
	
	public String execute()
	{
		
		System.out.println("yo");
		String serviceName=request.getParameter("serviceName");
		
		System.out.println("In action service name "+ serviceName);
		
		String present=addServiceUtil.checkAvailability(serviceName);
		
		response.setContentType("text/text;charset=utf-8");
		response.setHeader("cache-control", "no-cache"); 
		PrintWriter out;
		try {
			out = response.getWriter();
			out.println(present); 
			out.flush(); 

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return null;
	}

}
