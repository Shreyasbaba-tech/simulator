package com.ctl.app.virtual.action;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.app.virtual.AddResponseInfo;

public class ShowCustomizedResponsePageAction implements ServletRequestAware,ServletResponseAware  {
	private HttpServletRequest request;
	private HttpServletResponse response;
	private AddResponseInfo responseInfo;

	public String execute() throws IOException 
{
		
	String responses=(request.getParameter("responseInfoField"));
	
	request.getSession().setAttribute("responses", responses);
	/* HashMap<String, List<AddResponseInfo>> map = convertToMap(responses);
	 
	 Object obj = request.getSession().getAttribute("UseCaseToTNMapping");
	
	HashMap<String, List<AddResponseInfo>> useCaseToTNMapping = (HashMap<String, List<AddResponseInfo>>) obj;
	 	if(map != null && useCaseToTNMapping!= null)
	 	{
		 useCaseToTNMapping.putAll(map);
		 request.getSession().setAttribute("UseCaseToTNMapping", useCaseToTNMapping);
	 	}
	 	else if (useCaseToTNMapping == null) {
	 		request.getSession().setAttribute("UseCaseToTNMapping", map);
		}
	 	
	// request.getSession().setAttribute("UseCaseToTNMapping", useCaseToTNMapping);	
	 
	 
	 
	System.out.println("responses stored in session ");*/
	return "success";
}

	public HashMap<String, List<AddResponseInfo>> convertToMap(String responses) {
		HashMap<String, List<AddResponseInfo>> res = new HashMap<String, List<AddResponseInfo>>() ;
		String[] responseArray = responses.split("\\#\\$\\#");
		List<AddResponseInfo> list = new ArrayList<AddResponseInfo>();
		for(String resp:responseArray)
		{
			if(resp!=null)
			{
			String[] curResponseInfo = resp.split("\\|\\|");
			
			AddResponseInfo info = new AddResponseInfo();
			info.setAppId(curResponseInfo[0]);
			info.setSystem(curResponseInfo[1]);
			info.setSubSystem(curResponseInfo[2]);
			info.setKey(curResponseInfo[3]);
			list.add(info);
			//res.put("currentResponseKey", info);
			}
			
		}
		res.put("currentResponseKey", list);
		return res;
	}


public void setServletRequest(HttpServletRequest arg0) {
	this.request=arg0;
	
}

public HttpServletRequest getRequest() {
	return request;
}
public HttpServletResponse getResponse() {
	return response;
}

public void setResponse(HttpServletResponse response) {
	this.response = response;
}
public void setRequest(HttpServletRequest request) {
	this.request = request;
}


public void setServletResponse(HttpServletResponse arg0) {
	this.response=arg0;
	
}



public AddResponseInfo getResponseInfo() {
	return responseInfo;
}



public void setResponseInfo(AddResponseInfo responseInfo) {
	this.responseInfo = responseInfo;
}










}
