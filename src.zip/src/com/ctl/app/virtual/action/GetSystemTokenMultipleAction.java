package com.ctl.app.virtual.action;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.app.virtual.util.AddKeyValueUtil;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.opensymphony.xwork2.ActionSupport;


public class GetSystemTokenMultipleAction extends ActionSupport implements ServletRequestAware,ServletResponseAware {

	private HttpServletRequest request;
	private HttpServletResponse response;
	private String userId;
	private String drop0;
	private String adminId;
	private String selectedAppId;
	
public String getAdminId() {
		return adminId;
	}


	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}


public String getDrop0() {
		return drop0;
	}


	public void setDrop0(String drop0) {
		this.drop0 = drop0;
	}


public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


public String getSelectedAppId() {
		return selectedAppId;
	}


	public void setSelectedAppId(String selectedAppId) {
		this.selectedAppId = selectedAppId;
	}


public String execute() 
{
	
	String[] systems;
	
	String tokens="";
	String[] appid_selected=request.getParameter("appId").split(",");
	AddKeyValueUtil addKeyValueUtil=new AddKeyValueUtil();
	
for(int i=0;i<appid_selected.length;i++)
{
	systems=addKeyValueUtil.getSystems(appid_selected[i],SimulatorContextBeanPropertUtil.getResponseFilePath());
	tokens=tokens+","+tokenise(systems);
	//System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
	System.out.println(tokens);
	//System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
}
	
	

	response.setContentType("text/text;charset=utf-8");
	response.setHeader("cache-control", "no-cache"); 
	PrintWriter out;
	try {
		out = response.getWriter();
		out.println(tokens); 
		out.flush(); 

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	

	return null;
}


public String updateProperties() throws IOException{
	setDrop0( drop0.replace(", ",  ","));
	System.out.println("********************************************************************************");
	System.out.println(userId);
	System.out.println(drop0);
	System.out.println(adminId);
	System.out.println("********************************************************************************");

	RxContextPathDeploymentUtil util = new RxContextPathDeploymentUtil();
	String pathUser=util.getConfigItPath().replace("it", "VirtualAppUser.properties");
	Properties pro = new Properties();
	FileInputStream fileUser= new FileInputStream(pathUser);
	pro.load(fileUser);
	String admins=pro.getProperty("virApp.admin");
	String users=pro.getProperty("virApp.users");
	
	if(users!=null && !users.contains(userId))
	{
		users=users.concat(","+userId);
		pro.setProperty("virApp.users",users);
		pro.setProperty(userId, drop0);
		FileOutputStream out = new FileOutputStream(pathUser);
		pro.store(out, null);
	     out.close();
	}
	String appIds=pro.getProperty(userId);
	String drop[]=drop0.split(",");
	for(int i=0;i<drop.length;i++)
	{
		if(appIds!=null && !appIds.contains(drop[i])){
			appIds=appIds.concat(","+drop[i]);
			pro.setProperty(userId,appIds);
		}
	}
	
	
	if(!(adminId==null ||adminId.equals("")||admins.contains(adminId)))
	{
	admins=admins.concat(","+adminId);
	pro.setProperty("virApp.admin",admins)	;
	}
	if(!(userId==null ||userId.equals("")||users.contains(userId)))
	{
	users=users.concat(","+userId);
	pro.setProperty("virApp.users",users)	;
	}
	
	FileOutputStream out = new FileOutputStream(pathUser);
	pro.store(out, null);
     out.close();
	
     addActionMessage("appId("+drop0+") added successfully for "+userId);
	return SUCCESS;
}
public String tokenise(String[] subSystems)
{
	String tokens=new String();
	for(int i=0;i<subSystems.length;i++)
	{
		if(subSystems[i]!=null){
		tokens=tokens.concat(subSystems[i]);
		tokens=tokens.concat(",");
		}
				
	}
	
	return tokens;
}


public void setServletRequest(HttpServletRequest arg0) {
	this.request=arg0;
	
}

public HttpServletRequest getRequest() {
	return request;
}
public HttpServletResponse getResponse() {
	return response;
}

public void setResponse(HttpServletResponse response) {
	this.response = response;
}
public void setRequest(HttpServletRequest request) {
	this.request = request;
}


public void setServletResponse(HttpServletResponse arg0) {
	this.response=arg0;
	
}





}
