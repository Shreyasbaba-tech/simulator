package com.ctl.app.virtual.action;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import com.ctl.app.virtual.util.ZipUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.opensymphony.xwork2.ActionSupport;

public class TakeResponseBackup extends ActionSupport{
	
private String modeOfBackup;
private String appId;
	
	public String execute()
	{
		
		RxContextPathDeploymentUtil util = new RxContextPathDeploymentUtil();
		String path=util.getConfigItPath().replace("it", "VirtualConfig.properties");
		Properties pro = new Properties();
		try {
		    FileInputStream f = new FileInputStream(path);
		    pro.load(f);
		} catch (Exception e) {
		}
		
		String responsePath = pro.getProperty("ResponeFilePath");
		String appIdInAction = appId;
		String modeOfBackupInAction = modeOfBackup;
		String sourcePath = "";
		String destPath = "";
		if("Backup of whole Repository".equals(modeOfBackupInAction))
		{
			System.out.println(responsePath);
			sourcePath = responsePath;
			destPath = responsePath+"/temp.zip";
			System.out.println(sourcePath+"======"+destPath);
		}
		else if ("Application Level Backup".equals(modeOfBackupInAction)) {
			sourcePath = responsePath+appIdInAction;
			destPath = responsePath+appIdInAction+"/temp.zip";
			System.out.println(sourcePath+"======"+destPath);
		}
		
		File dir = new File(sourcePath);
	    String zipDirName = destPath;
        ZipUtil zipFiles = new ZipUtil();
        zipFiles.zipDirectory(dir, zipDirName);

        //code to commit the file to cvs
        
        
        
        //code to delete the temporary files
        
		
		return SUCCESS;
	}

	public String getModeOfBackup() {
		return modeOfBackup;
	}

	public void setModeOfBackup(String modeOfBackup) {
		this.modeOfBackup = modeOfBackup;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

}
