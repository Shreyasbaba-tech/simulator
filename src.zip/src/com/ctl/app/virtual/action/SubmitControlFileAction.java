package com.ctl.app.virtual.action;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import com.ctl.app.virtual.util.AddKeyValueUtil;
import com.ctl.simulation.resiliency.ResiliencyParameterManager;


public class SubmitControlFileAction{
	private String controlFilePath;
	private String content;
	private AddKeyValueUtil util;
	
	
	public SubmitControlFileAction() {
		// TODO Auto-generated constructor stub
		util=new AddKeyValueUtil();
	}
	public String execute(){
		System.out.println("controlFilePath= "+controlFilePath);
		String dummyFilePath=controlFilePath.replace(".ctrl", "Dummy.ctrl");
		File dummyFile=new File(dummyFilePath);
		File origControlFile=new File(controlFilePath);
		String newContents=null;
		try {
			newContents=util.readFileAsString(dummyFilePath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//util.copyFileContents(dummyFile, origControlFile);
		String[] props=newContents.split("##");
		/*Properties pro=new Properties();
		for(int i=0;i<pro.size();i++)
		{
			
			pro.put(props[i].substring(0, props[i].indexOf('=')),props[i].substring(props[i].indexOf('=')));
		}
		ResiliencyParameterManager man=new ResiliencyParameterManager();*/
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(origControlFile));
			for(int i=0;i<props.length;i++)
			{
				String line=props[i].trim();
				out.write(line);
				out.newLine();
			}
			out.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "success";
	}


	public String getControlFilePath() {
		return controlFilePath;
	}


	public void setControlFilePath(String controlFilePath) {
		this.controlFilePath = controlFilePath;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}
}
