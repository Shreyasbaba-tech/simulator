/**
 * 
 */
package com.ctl.app.virtual.action;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.ctl.app.virtual.AddJMSServiceInfo;
import com.ctl.app.virtual.AddServiceInfo;
import com.ctl.app.virtual.constant.CommonConstant;
import com.ctl.app.virtual.util.AddKeyValueUtil;
import com.ctl.app.virtual.util.AddServiceUtil;
import com.ctl.app.virtual.util.CommonUtility;
import com.ctl.app.virtual.util.JMSServerUtility;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @author aa47173
 *
 */
public class AddJMSServiceAction extends ActionSupport implements SessionAware,ServletRequestAware{
	
	private AddJMSServiceInfo servcInfo;
	private AddServiceUtil serviceUtil;
	private HttpServletRequest request;
	private Map<String, Object> session;
	private String applicationId;//Existing App Id
	private String appId;//New App Id
	private String serviceName;//Existing
	private String srvcName;//New
	private String operName;// QueueName
	private String respIdentifierKey;
	private List<String> queueName;
	private List<String> queueSize;
	private List<String> delMode;
	private List<File> fileField;
	private List<String> fileSelected;
	private File respFile;
	
	public AddJMSServiceAction() {
		if(servcInfo==null){
			servcInfo = new AddJMSServiceInfo();
		}
		if(serviceUtil==null){
			serviceUtil= new AddServiceUtil();
		}
	}
	
	public String execute() throws Exception {
		
		//System.out.println("Application ID :: "+applicationId);
		//System.out.println("New Application ID :: "+appId);
		//System.out.println("Service Name :: "+serviceName);		
		//System.out.println("New Service Name :: "+srvcName);
		
		String applID = null;
		String servName = null;
		
		try{
			applID = (applicationId==null || applicationId.equals("") || applicationId.equals("Create new application"))?appId:applicationId;
			servName = (serviceName==null || serviceName.equals("") || serviceName.equals("Create new service"))?srvcName:serviceName;
			
			for(int i=0; i<queueName.size(); i++){
				//System.out.println("Queue Name :: "+queueName.get(i)+" Queue size :: "+queueSize.get(i)+" Delivery Mode :: "+delMode.get(i)+" File Name :: "+fileField.get(i).getName());
				
				servcInfo.setApplID(applID);
				servcInfo.setDeliveryMode(delMode.get(i));
				servcInfo.setFileField(fileField.get(i));
				servcInfo.setQueueName(queueName.get(i));
				servcInfo.setQueueSize(queueSize.get(i));
				servcInfo.setServiceType("JMS");
				servcInfo.setServName(servName);
				
				serviceUtil.addJMSService(servcInfo);
				
				String tempStr = fileToString(fileField.get(i));
				new JMSServerUtility(queueName.get(i),delMode.get(i),tempStr);
				
				/*String defaultFileLocation=null; 
				defaultFileLocation=SimulatorContextBeanPropertUtil.getResponseFilePath()+applID+"/"+servName+"/"+queueName.get(i);
				String content = FileUtils.readFileToString(fileField.get(i));
				CommonUtility.writeToFile(defaultFileLocation, "default.vm", content);*/
			}
		}catch(Exception ex){
			ex.printStackTrace();
			return ERROR;
		}
		
		//Successfully created service. Please check service details 
		StringBuffer sb = new StringBuffer();
		String successMessage = "";
		sb.append("<table align=\"center\"><tr><td colspan=2><h3 align=\"center\"><b>Successfully created service. Please check service details.</b></h3></td><td></td></tr>");
		sb.append("<tr><td><label>Application Id : </label></td><td>"+applID+"</td><td></td></tr>");
		sb.append("<tr><td><label>Service Name : </label></td><td>"+servName+"</td><td></td></tr>");
		for(int i=0; i<queueName.size(); i++){
			sb.append("<tr><td><label>Queue"+(i+1)+" Name  : </label></td><td>"+queueName.get(i)+"</td><td>Delivery Mode : "+delMode.get(i)+"</td></tr>");
		}
		sb.append("<tr><td><label>Service URI : </label></td><td>"+CommonUtility.getPropertyValue("config.properties", "MESSAGEBROKERURL")+"</td><td></td></tr>");
		sb.append("<tr><td><label>Service JNDI PATH : </label></td><td>"+CommonUtility.getPropertyValue("config.properties", "JMSJNDIPATH")+"</td><td></td></tr>");
		sb.append("</table>");
		
		successMessage = sb.toString();
		//System.out.println("successMessage  ::"+successMessage);
		request.getSession().setAttribute("successMessage", successMessage);
		return SUCCESS;		
	}
	
	public String addJMSResponse() throws Exception{
		
		return SUCCESS;
	}
	
	public String addNewJMSResponse() throws Exception{
		request.getSession().setAttribute("appId", "appId");
		request.getSession().setAttribute("srvcName", "srvcName");
		request.getSession().setAttribute("operName", "operName");
		request.getSession().setAttribute("respIdentifierKey", "respIdentifierKey");
		return SUCCESS;
	}
	
	public String editJMSResponse()throws Exception{
		
		return SUCCESS;
	}
	
	public String loadJMSResponse()throws Exception{
		//System.out.println("New Application ID :: "+appId);
		//System.out.println("Service Name :: "+srvcName);		
		//System.out.println("New Service Name :: "+operName);
		
		File f=new File(SimulatorContextBeanPropertUtil.getResponseFilePath()+"/"+appId+"/"+srvcName+"/"+operName);
		File[] list=f.listFiles();
		/*for(File temp:list){
			String tempStr = fileToString(temp);
			new JMSServerUtility(operName,CommonConstant.NON_PERSISTENT,tempStr);
		}*/
		request.getSession().setAttribute("fileList", list);
		request.setAttribute("appId", appId);
		request.setAttribute("srvcName", srvcName);
		request.setAttribute("operName", operName);
		
		return SUCCESS;
	}
	public String loadSelectedJMSResponse()throws Exception{
		try {
			//System.out.println("New Application ID :: "+appId);
			//System.out.println("Service Name :: "+srvcName);		
			//System.out.println("New Service Name :: "+operName);
			File[] list = (File[]) request.getSession().getAttribute("fileList");
			for(int i = 0; i < fileSelected.size(); i++){
				//System.out.println(fileSelected.get(i));
				//System.out.println(list[Integer.parseInt(fileSelected.get(i))].getName());
			}
			/*for(File temp:list){
				String tempStr = fileToString(temp);
				new JMSServerUtility(operName,CommonConstant.NON_PERSISTENT,tempStr);
			}*/
			StringBuffer sb = new StringBuffer();
			String successMessage = "";
			sb.append("<table align=\"center\"><tr><td colspan=2><h3 align=\"center\"><b>Successfully created service. Please check service details.</b></h3></td><td></td></tr>");
			sb.append("<tr><td><label>Application Id : </label></td><td>"+appId+"</td><td></td></tr>");
			sb.append("<tr><td><label>Service Name : </label></td><td>"+srvcName+"</td><td></td></tr>");
			sb.append("<tr><td><label>Queue Name  : </label></td><td>"+operName+"</td><td></td></tr>");
			sb.append("<tr><td><label>Service URI : </label></td><td>"+CommonUtility.getPropertyValue("config.properties", "MESSAGEBROKERURL")+"</td><td></td></tr>");
			sb.append("<tr><td><label>Service JNDI PATH : </label></td><td>"+CommonUtility.getPropertyValue("config.properties", "JMSJNDIPATH")+"</td><td></td></tr>");
			sb.append("</table>");
			
			successMessage = sb.toString();
			//System.out.println("successMessage  ::"+successMessage);
			request.getSession().setAttribute("successMessage", successMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return SUCCESS;
	}
	
	public String loadResponse()throws Exception{
		
		return SUCCESS;
	}
	
	private String fileToString(final File file) throws IOException {
			    StringBuilder result = new StringBuilder();
			    BufferedReader reader = null;
			    try {
			        reader = new BufferedReader(new FileReader(file));

			        char[] buf = new char[1024];

			        int r = 0;

			        while ((r = reader.read(buf)) != -1) {
			            result.append(buf, 0, r);
			        }
			    }
			    finally {
			        reader.close();
			    }

			    return result.toString();
			}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		this.request = arg0;		
	}

	@Override
	public void setSession(Map<String, Object> arg0) {
		this.session = arg0;		
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getSrvcName() {
		return srvcName;
	}

	public void setSrvcName(String srvcName) {
		this.srvcName = srvcName;
	}

	public String getOperName() {
		return operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}

	public String getRespIdentifierKey() {
		return respIdentifierKey;
	}

	public void setRespIdentifierKey(String respIdentifierKey) {
		this.respIdentifierKey = respIdentifierKey;
	}

	public List<String> getQueueName() {
		return queueName;
	}

	public void setQueueName(List<String> queueName) {
		this.queueName = queueName;
	}

	public List<String> getQueueSize() {
		return queueSize;
	}

	public void setQueueSize(List<String> queueSize) {
		this.queueSize = queueSize;
	}

	public List<String> getDelMode() {
		return delMode;
	}

	public void setDelMode(List<String> delMode) {
		this.delMode = delMode;
	}

	public List<File> getFileField() {
		return fileField;
	}

	public void setFileField(List<File> fileField) {
		this.fileField = fileField;
	}

	public File getRespFile() {
		return respFile;
	}

	public void setRespFile(File respFile) {
		this.respFile = respFile;
	}

	public List<String> getFileSelected() {
		return fileSelected;
	}

	public void setFileSelected(List<String> fileSelected) {
		this.fileSelected = fileSelected;
	}

}
