package com.ctl.app.virtual.action;


	import java.io.IOException;
	import java.io.PrintWriter;

	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	import org.apache.struts2.interceptor.ServletRequestAware;
	import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.app.virtual.util.AddKeyValueUtil;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;

	public class GetControlFileTokensAction implements ServletRequestAware,ServletResponseAware  {
		private HttpServletRequest request;
		private HttpServletResponse response;
	
		public String execute() 
	{
		String pathTillNow=null;
		String[] controlFiles;
		String subSystem=request.getParameter("subSystem");
		String system=request.getParameter("system");
		String appId=request.getParameter("appId");
		
		pathTillNow=SimulatorContextBeanPropertUtil.getResponseFilePath()+"/"+appId+"/";
		if(subSystem==null)
		{
			pathTillNow+=system;
		}
		else
		{
			pathTillNow=pathTillNow+system+"/"+subSystem;
		}
		//request.setAttribute("pathTillNow", pathTillNow);
		//System.out.println("path tillnw= "+pathTillNow);
		//System.out.println("path tillnw=in action= "+ request.getParameter("pathTillNow"));
		//System.out.println("in control action System = "+system+" SubSystem = "+subSystem);
		//System.out.println(system+"in Action");
		AddKeyValueUtil addKeyValueUtil=new AddKeyValueUtil();
		controlFiles=addKeyValueUtil.getControlFiles(subSystem,SimulatorContextBeanPropertUtil.getResponseFilePath()+"/"+appId+"/"+system);
		String tokens=addKeyValueUtil.tokenise(controlFiles);
		
		response.setContentType("text/text;charset=utf-8");
		response.setHeader("cache-control", "no-cache"); 
		PrintWriter out;
		try {
			out = response.getWriter();
			out.println(tokens); 
			out.flush(); 

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		

		return null;
	}

	


	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}

	public HttpServletRequest getRequest() {
		return request;
	}
	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}


	public void setServletResponse(HttpServletResponse arg0) {
		this.response=arg0;
		
	}









}
