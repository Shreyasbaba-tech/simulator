package com.ctl.app.virtual.action;

import com.ctl.app.virtual.util.ValidationUtil;
import com.opensymphony.xwork2.ActionSupport;

public class ValidationAction extends ActionSupport{
	
	private String requestXML;
	private String actionXPath;
	private String requestParams;
	private ValidationUtil validationUtil;
	private boolean result;
	
	@Override
	public String execute() throws Exception {
		
	result=validationUtil.validateXMLXPath(requestXML, actionXPath);
	if(result){
		System.out.println(result);
		return SUCCESS;
	}
	else{
		return ERROR;
	}
		
	}
	
	public ValidationUtil getValidationUtil() {
		return validationUtil;
	}

	public void setValidationUtil(ValidationUtil validationUtil) {
		this.validationUtil = validationUtil;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	
	
	public ValidationAction() {
		// TODO Auto-generated constructor stub
	}
	
	public String getRequestXML() {
		return requestXML;
	}
	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}
	public String getActionXPath() {
		return actionXPath;
	}
	public void setActionXPath(String actionXPath) {
		this.actionXPath = actionXPath;
	}
	public String getRequestParams() {
		return requestParams;
	}
	public void setRequestParams(String requestParams) {
		this.requestParams = requestParams;
	}

}
