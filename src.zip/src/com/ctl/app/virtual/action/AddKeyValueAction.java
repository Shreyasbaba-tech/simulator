package com.ctl.app.virtual.action;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.ctl.simulation.http.RxContextPathDeploymentUtil;



public class AddKeyValueAction implements ServletRequestAware {
	private String drop1;
	private String drop2;
	private String drop3;
	private String value;
	private String addedString;
	private String key;
	private String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public AddKeyValueAction() {
		// TODO Auto-generated constructor stub
	}
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getAddedString() {
		return addedString;
	}
	public void setAddedString(String addedString) {
		this.addedString = addedString;
	}
	public String getDrop1() {
		return drop1;
	}
	public void setDrop1(String drop1) {
		this.drop1 = drop1;
	}
	public String getDrop2() {
		return drop2;
	}
	public void setDrop2(String drop2) {
		this.drop2 = drop2;
	}
	public String getDrop3() {
		return drop3;
	}
	public void setDrop3(String drop3) {
		this.drop3 = drop3;
	}
	
	public String execute(){
		
		
		String system=drop1;
		
		//String controlFilePath="C:\\Responses";
		RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
        String path=contextDeploymentUtil.getConfigItPath().replace("it", "VirtualConfig.properties");
        Properties pro = new Properties();
		try {
			FileInputStream f = new FileInputStream(path);
			pro.load(f);
		} catch (Exception e) {
			
		}
		String controlFilePath=pro.getProperty("ResponeFilePath");
		
				if(system!=null)
		{
			controlFilePath+="/"+system;
		}
		String subSystem=drop2;
		//System.out.println("subystem= "+subSystem);
		
		if(subSystem!=null)
		{
			controlFilePath+="/"+subSystem;
		}
		String controlFile=drop3;
	//	System.out.println(controlFile);
		String controlFileName=controlFile.replace(".vm", "");
		controlFileName=controlFileName.replace(".ctrl", "");
		if(controlFileName!=null)
		{
			controlFilePath+="/"+controlFileName+".ctrl";
		}
	//	System.out.println("in add key  value action" + controlFilePath);
		File f=new File(controlFilePath);
			try {
			
			BufferedWriter bw=new BufferedWriter(new FileWriter(f,true));
			
			addedString=key+"="+value;
			
		//	System.out.println(addedString);
		
			bw.write(addedString);
			bw.newLine();
			bw.close();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "success";
	}
	
	

	private HttpServletRequest request;
	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	
	

}
