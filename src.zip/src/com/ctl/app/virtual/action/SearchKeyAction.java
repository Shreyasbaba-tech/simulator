package com.ctl.app.virtual.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.ParserConfigurationException;


import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.xml.sax.SAXException;

import com.ctl.app.virtual.SearchPojo;
import com.ctl.app.virtual.util.SearchKeyUtil;

public class SearchKeyAction implements ServletRequestAware{

	private String inputString;
	private boolean searchResult;
//	private Map<String, Object> session;
	
	public boolean isSearchResult() {
		return searchResult;
	}

	public void setSearchResult(boolean searchResult) {
	//	this.searchResult = searchResult;
	}

	public SearchKeyAction() {
		searchResult=false;
	}
	
	public String getInputString() {
		return inputString;
	}

	public void setInputString(String inputString) {
		this.inputString = inputString;
	}

	public String execute()
	{
	    ArrayList<SearchPojo> result=new  ArrayList<SearchPojo>();
		SearchKeyUtil searchKeyUtil=new SearchKeyUtil();
	//	searchResult=false;
		try {
			result=searchKeyUtil.searchKeyInTags(inputString);
			 
			  searchResult=true;
			  request.setAttribute("result",result);
			  
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//request.setAttribute("searchResult", searchResult);
	//	session.put("searchResult", searchResult);
		return "success";
	}
	private HttpServletRequest request;
	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	/*@Override
	public void setSession(Map<String, Object> arg0) {
		session=arg0;
		
	}*/
	
	
}
