/**
 * 
 */
package com.ctl.app.virtual.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.ctl.app.virtual.AddServiceInfo;
import com.ctl.app.virtual.constant.CommonConstant;
import com.ctl.app.virtual.util.AddServiceUtil;
import com.ctl.app.virtual.util.CommonUtility;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @author aa47173
 *
 */
public class AddBulkResponseAction extends ActionSupport implements SessionAware,ServletRequestAware{

	private HttpServletRequest request;
	private Map<String, Object> session;
	private AddServiceInfo serviceInfo;
	private AddServiceUtil serviceUtil;
	private String minRange;
	private String maxRange;
	private String SelectedXpaths;
	private String reqParameters;
	
	public AddBulkResponseAction() {
		
	}
	
	public String saveBulkResponses(){
		//System.out.println("--"+minRange+"--"+maxRange+"--"+SelectedXpaths);
		serviceInfo = (AddServiceInfo) request.getSession().getAttribute("serviceInfo");
		String tempAppid=serviceInfo.getApplicationId();
		String tempService=serviceInfo.getServiceName();
		String tempOper=serviceInfo.getOperName();
		String tempKey=(String)request.getSession().getAttribute("key");
						
		//System.out.println("AppID==>>"+serviceInfo.getApplicationId());
		//serviceInfo.setServiceName(tempService);
		//serviceInfo.setApplicationId(tempAppid);
		
		Properties prop = SimulatorContextBeanPropertUtil.getVitualConfigProperties();
		String path = prop.getProperty("ResponeFilePath");
		
		//System.out.println(path+tempAppid+"//"+tempService+"//"+tempOper+"//"+tempKey);
		File f = new File(path+tempAppid+"//"+tempService+"//"+tempOper+"//"+tempKey);
		String writePath = path+tempAppid+"//"+tempService+"//"+tempOper+"//";
		
		
		//System.out.println("==>"+reqParameters);
		String[] strArr = reqParameters.split("#");
		List<String> stList = new ArrayList<String>();
		for (int i = 0; i < strArr.length; i++) {
			stList.add(strArr[i]);
			//System.out.println(strArr[i]);
		}
		
		CommonUtility.generateBulkXMLs(f,writePath, SelectedXpaths.trim(), minRange, maxRange, CommonConstant.IS_NUMBER,stList);
		
		serviceInfo.setFile(f);
		return SUCCESS;
	}
	
	public AddServiceInfo getServiceInfo() {
		return serviceInfo;
	}

	public void setServiceInfo(AddServiceInfo serviceInfo) {
		this.serviceInfo = serviceInfo;
	}

	public AddServiceUtil getServiceUtil() {
		return serviceUtil;
	}

	public void setServiceUtil(AddServiceUtil serviceUtil) {
		this.serviceUtil = serviceUtil;
	}

	public void setSession(Map<String, Object> arg0) {
		this.session=arg0;
	}

	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}

	public String getMinRange() {
		return minRange;
	}

	public void setMinRange(String minRange) {
		this.minRange = minRange;
	}

	public String getMaxRange() {
		return maxRange;
	}

	public void setMaxRange(String maxRange) {
		this.maxRange = maxRange;
	}

	public String getSelectedXpaths() {
		return SelectedXpaths;
	}

	public void setSelectedXpaths(String selectedXpaths) {
		SelectedXpaths = selectedXpaths;
	}

	public String getReqParameters() {
		return reqParameters;
	}

	public void setReqParameters(String reqParameters) {
		this.reqParameters = reqParameters;
	}
}
