/**
 * 
 */
package com.ctl.app.virtual.action;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang.StringUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.ctl.app.virtual.AddServiceInfo;
import com.ctl.app.virtual.util.AddServiceUtil;
import com.ctl.app.virtual.util.EmailUtils;
import com.ctl.app.virtual.util.SuggestionBoxUtil;
import com.ctl.simulation.helper.XpathUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.opensymphony.xwork2.ActionSupport;


/**
 * @author aa47173
 *
 */
public class CommonAjaxAction extends ActionSupport implements SessionAware,ServletRequestAware{
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	private Map<String, Object> session;
	private String fileName;
	
	public CommonAjaxAction() {
	}

	public String execute() throws Exception {
		
		
		return null;		
	}
	
	public String retriveXMLElementValueList() throws Exception {
		String f = request.getParameter("filePath");
		System.out.println("File Path : "+f);
		File file = new File(f);
		
		String returnString = "";
		String returnString1 = "";
		String returnString2 = "";
		
		List<String> generatedXpathMapKey = new ArrayList<String>();
		Map<String,String> generatedXpathMap;

		List<String> restXpathMapKey = new ArrayList<String>();
		Map<String,String> restXpathMap;
		
		XpathUtil util = new XpathUtil();
		generatedXpathMap=util.retrieveXpathsMap(util.retrieveXpathsList(file));
		restXpathMap=util.retrieveAllXpathsMap(util.retrieveXpathsList(file));
		
		Iterator itr=generatedXpathMap.keySet().iterator();
		while (itr.hasNext()) {
			  String thisEntry = (String) itr.next();
			  //generatedXpathMapKey.add(thisEntry);
			  if(returnString1.equals("")){
				  returnString1 = thisEntry;
			  }else{
				  returnString1 = returnString1+"#"+thisEntry;				  
			  }
			  //System.out.println("%%%%%%--"+thisEntry);
			}
		Iterator itr1=restXpathMap.keySet().iterator();
		while (itr1.hasNext()) {
			  String thisEntry = (String) itr1.next();
			  //System.out.println("$$$$$--"+thisEntry);
				if(!generatedXpathMap.containsKey(thisEntry))	{				 
					restXpathMapKey.add(thisEntry);
					if(!thisEntry.equals("")){
						if(returnString2.equals("")){
							  returnString2 = thisEntry;
						  }else{
							  returnString2 = returnString2+"#"+thisEntry;				  
						  }
					}
					//System.out.println("&&&&&&--"+thisEntry);
				}
			}
		returnString = returnString1+"#1#"+returnString2;
		response = ServletActionContext.getResponse();
		response.setContentType("text/html");
        response.setHeader("Cache-Control", "no-cache");
        System.out.println("Ajax call ::: "+returnString);
        try {
            response.getWriter().write(returnString);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        
		
		return null;		
	}

	
	
	public String saveUpdateComments()
	{
		System.out.println("In saveUpdateaction ");
		SuggestionBoxUtil util = new SuggestionBoxUtil();
		String newComment = request.getParameter("newComment");
		String userEmail = request.getParameter("userEmail");
		System.out.println(newComment);
		String responseString = "";
		if(!StringUtils.isBlank(newComment))
			responseString = util.submitSuggestion(newComment,userEmail);
		else
			responseString = util.readPreviousSuggestions();
		
		System.out.println("response String : "+responseString);
		response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		response.setHeader("cache-control", "no-cache"); 
		PrintWriter out;
		
			try {
				out = response.getWriter();
				out.write(responseString);
				//out.println(responseString); 
				out.flush(); 
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		return null;
	}
	
	public String sendSuggestionByEmail()
	{
		String newComment = request.getParameter("newComment");
		String userEmail = request.getParameter("userEmail");
		
		
		String[] recipients ={"VirtualizationApp@centurylink.com"};  // {"anup.dakua@centurylink.com"};
		
		String msg = newComment;
		
		
		EmailUtils.postMail(recipients, "Virtual App", msg, userEmail);
		
		
		
		
		
		
		return null;
		
	}
	
	public String viewContextFile(){
		
		RxContextPathDeploymentUtil util=new RxContextPathDeploymentUtil();
	    String path=util.getConfigItPath();
		 try
	        {
	            TransformerFactory tFactory = TransformerFactory.newInstance();

	            Source xslDoc = new StreamSource(path+"virtualAppContext.xsl");
	            Source xmlDoc = new StreamSource(path+"simulators\\"+fileName);

	            /*String outputFileName = path+"catalog.html";
	            OutputStream htmlFile = new FileOutputStream(outputFileName);*/
	            Writer outWriter = new StringWriter();
	            StreamResult result = new StreamResult( outWriter );

	            Transformer transformer = tFactory.newTransformer(xslDoc);
	            transformer.transform(xmlDoc, result);
	            StringBuffer sb = ((StringWriter) outWriter) .getBuffer(); 
	            String finalstring = sb.toString();
	            System.out.println("---->>>>"+finalstring);
	            request.getSession().setAttribute("successMessage", finalstring);
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
		return SUCCESS;
	}
	
	
	
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}
	
	public void setServletResponse(HttpServletResponse response) {
        this.response = response;
    }

	@Override
	public void setSession(Map<String, Object> arg0) {
		this.session=arg0;
		
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
