package com.ctl.app.virtual.action;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.beans.BeansException;

import com.ctl.app.virtual.AddServiceInfo;
import com.ctl.app.virtual.AddServiceResponseInfo;
import com.ctl.app.virtual.util.AddServiceUtil;
import com.ctl.app.virtual.util.CommonUtility;
import com.ctl.app.virtual.util.ReadExcelSheet;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.helper.XpathUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.ctl.simulation.simulator.BusSimulator;
import com.ctl.simulation.simulator.ISimulator;
import com.ctl.simulation.simulator.WebSimulator;
import com.ctl.simulation.spring.BeanApplicationContext;
import com.ctl.app.virtual.util.URLUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;


public class AddServiceAction extends ActionSupport implements SessionAware,ServletRequestAware {
	
		private AddServiceInfo serviceInfo;
		private AddServiceUtil serviceUtil;
		private HttpServletRequest request;
		private Map<String, Object> session;
		private String serviceComplexity;
		private File xslFile;
		private String SelectedOperationXpaths;
		private String valueOfOperToAction;
		private boolean newOperFlagToAction;
		private String operationName;
		private String operationValue;
		private String oprType;
		private String serviceURL;
		private String dataSource;
		private String contentType;
		
		//soumya start		
		private String UserName; 
		public String getUserName() {
			return UserName;
		}

		public void setUserName(String userName) {
			UserName = userName;
		}		
		//soumya end
		
		public AddServiceAction() {
			if(serviceInfo==null){
				serviceInfo = new AddServiceInfo();
			}
			if(serviceUtil==null){
				serviceUtil= new AddServiceUtil();
			}
		}

		public String execute() throws Exception {
			//soumya
			UserName = (String) session.get("UserName");
			//soumya
	    	  try{
	    		 List<String> xpaths = new ArrayList<String>();
	    		 File sampleResponseFile=serviceInfo.getSampleResponseFile();
	    		 String [] strArray =StringUtils.split(serviceInfo.getSelectedXpaths(), "#");
	    		 for (String string : strArray) {
	    			 xpaths.add(string);
				}
	    		 
	    		
	    		 serviceInfo = (AddServiceInfo) session.get("serviceInfo");
	    		 Map<String, String> xpathMap=serviceInfo.getGeneratedXpathMap();
	    		 serviceInfo=(AddServiceInfo)session.get("serviceInfo");
	    		 System.out.println(SelectedOperationXpaths);
	    		 serviceInfo.setOperName(SelectedOperationXpaths);
	    		 serviceInfo.setActionXpathValue(valueOfOperToAction.equals("NA")?"":valueOfOperToAction);
	    		 serviceInfo.setSelectedXpathsList(xpaths);
	    		 serviceInfo.setSampleResponseFile(sampleResponseFile);
	    		 //soumya
	    		 serviceInfo.setUserName((String) session.get("UserName"));
	    		 //soumya
	    		 String xpathOfSelectedOperation = xpathMap.get(SelectedOperationXpaths);
	 			if(xpathOfSelectedOperation == null)
	 				xpathOfSelectedOperation = serviceInfo.getRestXpathMap().get(SelectedOperationXpaths);
	    		 serviceUtil.addNewService(serviceInfo,null,null,null,xpathOfSelectedOperation);
	    	  }catch(Exception e){
	    		  e.printStackTrace();
	    		  return ERROR;
	    	  }
	         return SUCCESS;
		}
		
		
		public String showExistingServiceDetails()
		{
			try {
				SimulatorContextBeanPropertUtil util=new SimulatorContextBeanPropertUtil(); 
				    String serviceURI=null;
				    String serviceType=null;
				    String appId=serviceInfo.getApplicationId();
				    String serviceName=serviceInfo.getServiceName();
				    String operationName=serviceInfo.getOperName();
				    System.out.println("oper :"+operationName);
				    ISimulator iSimulator;
					String beanId=null;
					
					String[] beanIdArray= new String[BeanApplicationContext.getApplicationBeanIds().size()];
					BeanApplicationContext.getApplicationBeanIds().toArray(beanIdArray);
					for(String s:beanIdArray)
					{
						System.out.println("Bean: "+s);
						if(s.contains(appId+"_"+serviceName) || s.contains(appId+"."+serviceName))
						{
							System.out.println("Bean ID retrieved"+s);
							beanId=s;
							break;
						}else if(s.contains("Q."+appId+"."+serviceName+"."+operationName+".")){
							beanId=s;
							break;
						}
						
					}
					//To support multiple operation
					if(beanId==null){
						for(String s:beanIdArray)
						{
								System.out.println("Bean: "+s);
								if(s.contains(appId+"_"+serviceName))
								{
									System.out.println("Bean ID retrieved"+s);
									beanId=s;
									break;
								}else if(s.contains("Q."+appId+"."+serviceName+".")){
									beanId=s;
									break;
								}
						}
					}
					
					
					if (beanId!=null) {
						System.out.println(beanId);
						iSimulator = (ISimulator) BeanApplicationContext
								.getApplicationContext().getBean(beanId);
						if (iSimulator instanceof WebSimulator && "HTTPRequest".equalsIgnoreCase(operationName)) {

							serviceType = "Http service";
							serviceInfo.setServiceType(serviceType);
							serviceURI = util.getHttpprefix() + beanId;
							serviceInfo.setServiceURI(serviceURI);
							serviceInfo.setOperName(operationName);

						}else if(iSimulator instanceof BusSimulator){
							serviceType = "Bus service";
							serviceInfo.setServiceType(serviceType);
							serviceURI = SimulatorContextBeanPropertUtil.BUS_SERVICE_RVD;
							serviceInfo.setServiceURI(serviceURI);
							serviceInfo.setOperName(beanId);
						}else if (iSimulator instanceof WebSimulator) {

							serviceType = "Web service";
							serviceInfo.setServiceType(serviceType);
							serviceURI = util.getSoapprefix() + beanId;
							serviceInfo.setServiceURI(serviceURI);
							serviceInfo.setOperName(operationName);

						}
							
						String returnString = beanId + "#" + serviceURI + "#"
								+ serviceType;
						System.out.println(returnString);
					}
				
				 
			} catch (BeansException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return ERROR;
			}
			  return SUCCESS;
			
		}
		
		public String getFileInput(){
			
			//request.getParameter("dataSource");
			System.out.println("dataSourcein action1 : " + getDataSource());
			request.getSession().setAttribute("dataSource", getDataSource());
			
			//Service Type HTTP
			String serviceType = serviceInfo.getServiceType();			
			if(serviceType.equals("HttpService")){
				System.out.println("Service URL :: "+serviceURL);
				//serviceInfo.setOperName("HTTPRequest");
			}
			
			
			//Service Type WEB or BUS
			 System.out.println("flag="+newOperFlagToAction);
    		 request.getSession().setAttribute("createNewOperationFlag", newOperFlagToAction);
			String app=serviceInfo.getApplicationId();
			String oper=serviceInfo.getOperName();
			
			
			
			  if(app.equals("Create new application"))
			  {
				  String tempAppid=request.getParameter("appId");
				  String tempService=request.getParameter("serviceName");
				  serviceInfo.setServiceName(tempService);
				  serviceInfo.setApplicationId(tempAppid);
			  }
			  String service=serviceInfo.getServiceName();
			  if(service!=null)
			  {
							  
			  if(service.equals("Create new service"))
			  {
				  String tempService=request.getParameter("serviceName");
				  System.out.println(tempService+"servicename");
				  serviceInfo.setServiceName(tempService);
			  }
			  
			  }
			  
				  
			  
			try{
				List<String> generatedXpathMapKey = new ArrayList<String>();
				Map<String,String> generatedXpathMap;

				List<String> restXpathMapKey = new ArrayList<String>();
				Map<String,String> restXpathMap;
				
				XpathUtil util = new XpathUtil();
				if(serviceType.equals("HttpService")){
					File xmlFile = URLUtil.convertURLtoXml(serviceURL);
					generatedXpathMap=util.retrieveXpathsMap(util.retrieveXpathsList(xmlFile));
					restXpathMap=util.retrieveAllXpathsMap(util.retrieveXpathsList(xmlFile));
					serviceInfo.setFile(xmlFile);
					String operationString = serviceURL.split("\\?")[0];					
					String operName = operationString.substring(operationString.lastIndexOf('/')+1, operationString.length());
					setOperationName(operName);
					serviceInfo.setOperName(operName);
					serviceInfo.setContentType(contentType);					
					
					setOperationValue("NA");
				}else{
					generatedXpathMap=util.retrieveXpathsMap(util.retrieveXpathsList(serviceInfo.getFile()));
					restXpathMap=util.retrieveAllXpathsMap(util.retrieveXpathsList(serviceInfo.getFile()));
				}
		
				System.out.println(serviceInfo.getApplicationId()+" "+serviceInfo.getServiceName());
				Iterator itr=generatedXpathMap.keySet().iterator();
				while (itr.hasNext()) {
					  String thisEntry = (String) itr.next();
					  generatedXpathMapKey.add(thisEntry);
					  System.out.println("%%%%%%--"+thisEntry);
					}
				Iterator itr1=restXpathMap.keySet().iterator();
				while (itr1.hasNext()) {
					  String thisEntry = (String) itr1.next();
					  System.out.println("$$$$$--"+thisEntry);
						if(!generatedXpathMap.containsKey(thisEntry))	{				 
							restXpathMapKey.add(thisEntry);
							System.out.println("&&&&&&--"+thisEntry);
						}
					}
							
				 SimulatorContextBeanPropertUtil simulatorContextBeanPropertUtil=new SimulatorContextBeanPropertUtil();
		
				serviceInfo.setGeneratedXpathMap(generatedXpathMap);
				serviceInfo.setGeneratedXpathMapKey(generatedXpathMapKey);
				serviceInfo.setRestXpathMap(restXpathMap);
				serviceInfo.setRestXpathMapKey(restXpathMapKey);
				if(!serviceType.equals("HttpService")){
					setOperationValue((request.getParameter("oprVal")==null || request.getParameter("oprVal").equals(""))?"NA":request.getParameter("oprVal"));
					setOperationName(getOperationName());
					serviceInfo.setOperName(getOperationName());
				}
				session.put("serviceInfo", serviceInfo);
				request.setAttribute("restXpathMapKey", restXpathMapKey);
				request.setAttribute("generatedXpathMapKey", generatedXpathMapKey);

			}catch (Exception e) {
				e.printStackTrace();
				return ERROR;
			}
			
			System.out.println("serviceComplexity--"+serviceComplexity);
			if(serviceComplexity.equals("Simple"))
				return SUCCESS;
			else
				return "complex";
		}
		
		public String getBulkFileInput(){
			
			SimulatorContextBeanPropertUtil scbpu = new SimulatorContextBeanPropertUtil();
			
			String tempAppid=request.getParameter("appId");
			String tempService=request.getParameter("serviceName");
			String tempOper=request.getParameter("oper");
			String tempKey=request.getParameter("key");
			String content = request.getParameter("content");
			serviceInfo.setServiceName(tempService);
			serviceInfo.setApplicationId(tempAppid);
			
			serviceInfo.setOperName(tempOper);
			
			Properties prop = SimulatorContextBeanPropertUtil.getVitualConfigProperties();
			String path = prop.getProperty("ResponeFilePath");
			
			System.out.println(path+"\\"+tempAppid+"\\"+tempService+"\\"+tempOper+"\\"+tempKey);
			File f = new File(path+"\\"+tempAppid+"\\"+tempService+"\\"+tempOper+"\\"+tempKey);
			serviceInfo.setFile(f);

			String simPath = new RxContextPathDeploymentUtil().getConfigItPath()+"simulators";
			System.out.println("simfile[path = "+simPath);
			String simulatorFileName = null;
			File simDir = new File(simPath);
			File[] simList = simDir.listFiles();
			for (int i = 0; i < simList.length; i++) {
				String name = simList[i].getName();
				if (name.contains(tempService) && name.contains(tempAppid)) {
					simulatorFileName = name;
					System.out.println("====MilGaya====");
					break;
				}
			}
			String root = simPath+"//"+simulatorFileName;
			System.out.println("File name : " +root);
			try{
				List<String> generatedXpathMapKey = new ArrayList<String>();
				Map<String,String> generatedXpathMap;
				XpathUtil util = new XpathUtil();
				generatedXpathMap=util.retrieveXpathsMap(util.retrieveXpathsList(content));
				System.out.println(serviceInfo.getApplicationId()+" "+serviceInfo.getServiceName());
				Iterator itr=generatedXpathMap.keySet().iterator();
				while (itr.hasNext()) {
					  String thisEntry = (String) itr.next();
					  generatedXpathMapKey.add(thisEntry);
					}
			
				serviceInfo.setGeneratedXpathMap(generatedXpathMap);
				serviceInfo.setGeneratedXpathMapKey(generatedXpathMapKey);				
				session.put("serviceInfo", serviceInfo);
				//List<String> strList = CommonUtility.getSimulatorReqParams(root,scbpu.getOperationName(f));
				List<String> strList = CommonUtility.getSimulatorReqParams(root,serviceInfo.getOperName());
				System.out.println("List size : "+strList.size());
				request.getSession().setAttribute("strList", strList);
				request.getSession().setAttribute("serviceInfo", serviceInfo);
				request.getSession().setAttribute("key", tempKey);
				System.out.println("=====;;;;;???>>>> "+content);
			}catch (Exception e) {
				return ERROR;
			}
			
			 
			return SUCCESS;
		}
		
		public String uploadXSLFileInput(){
			String tempAppid=request.getParameter("appId");
			String tempService=request.getParameter("serviceName");
			String tempOper=request.getParameter("oper");
			String tempKey=request.getParameter("key");
			serviceInfo.setServiceName(tempService);
			serviceInfo.setApplicationId(tempAppid);
			System.out.println("Path===> C:\\Responses\\"+tempAppid+"\\"+tempService+"\\"+tempOper+"\\"+tempKey);
			System.out.println("====>>>"+xslFile.getName());
			
			Properties prop = SimulatorContextBeanPropertUtil.getVitualConfigProperties();
			String path = prop.getProperty("ResponeFilePath");
			
			File f = new File(path+tempAppid+"\\"+tempService+"\\"+tempOper+"\\"+tempKey);
			ReadExcelSheet res = new ReadExcelSheet();
			res.setInputFile(xslFile.getAbsolutePath());
			res.setXmlFile(path+tempAppid+"\\"+tempService+"\\"+tempOper+"\\"+tempKey);
			res.setXmlFilePath(path+tempAppid+"\\"+tempService+"\\"+tempOper+"\\");
			res.setFileName(tempKey.substring(0,tempKey.indexOf(".vm")));
			
			try {
				res.read();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return SUCCESS;
		}
		
		private String getFileNameFromPath(String path){
			String fileName="";
			String temp[] = path.split("[\\\\]");
			String str = temp[temp.length-1];
			fileName = (String) str.subSequence(0, str.indexOf("."));
			return fileName;
		}

		public AddServiceInfo getServiceInfo() {
			return serviceInfo;
		}

		public void setServiceInfo(AddServiceInfo serviceInfo) {
			this.serviceInfo = serviceInfo;
		}

		public AddServiceUtil getServiceUtil() {
			return serviceUtil;
		}

		public void setServiceUtil(AddServiceUtil serviceUtil) {
			this.serviceUtil = serviceUtil;
		}

		public void setSession(Map<String, Object> arg0) {
			this.session=arg0;
		}

		public void setServletRequest(HttpServletRequest arg0) {
			this.request=arg0;
			serviceUtil.setServletRequest(arg0);
			
		}

		public String getServiceComplexity() {
			return serviceComplexity;
		}

		public void setServiceComplexity(String serviceComplexity) {
			this.serviceComplexity = serviceComplexity;
		}

		public File getXslFile() {
			return xslFile;
		}

		public void setXslFile(File xslFile) {
			this.xslFile = xslFile;
		}

		public String getSelectedOperationXpaths() {
			return SelectedOperationXpaths;
		}

		public void setSelectedOperationXpaths(String selectedOperationXpaths) {
			SelectedOperationXpaths = selectedOperationXpaths;
		}

		public String getValueOfOperToAction() {
			return valueOfOperToAction;
		}

		public void setValueOfOperToAction(String valueOfOperToAction) {
			this.valueOfOperToAction = valueOfOperToAction;
		}

		public boolean isNewOperFlagToAction() {
			return newOperFlagToAction;
		}

		public void setNewOperFlagToAction(boolean newOperFlagToAction) {
			this.newOperFlagToAction = newOperFlagToAction;
		}

		public String getOperationName() {
			return operationName;
		}

		public void setOperationName(String operationName) {
			this.operationName = operationName;
		}

		public String getOperationValue() {
			return operationValue;
		}

		public void setOperationValue(String operationValue) {
			this.operationValue = operationValue;
		}

		public String getOprType() {
			return oprType;
		}

		public void setOprType(String oprType) {
			this.oprType = oprType;
		}

		public String getServiceURL() {
			return serviceURL;
		}

		public void setServiceURL(String serviceURL) {
			this.serviceURL = serviceURL;
		}

		
		public String getContentType() {
			return contentType;
		}

		public void setContentType(String contentType) {
			this.contentType = contentType;
		}

		public String getDataSource() {
			return dataSource;
		}

		public void setDataSource(String dataSource) {
			this.dataSource = dataSource;
		}

	
		

		
}
