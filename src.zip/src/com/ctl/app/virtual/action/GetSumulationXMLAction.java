package com.ctl.app.virtual.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.ctl.app.virtual.ExternalDataPullDTO;
import com.ctl.app.virtual.dao.CaptureUtilDAO;




public class GetSumulationXMLAction  implements ServletRequestAware {
	private String rxNumber;
	private String env;
	private List<ExternalDataPullDTO> xmlDataList;
	
	public GetSumulationXMLAction() {
		// TODO Auto-generated constructor stub
	}
	
	public String getRxNumber() {
		return rxNumber;
	}

	public void setRxNumber(String rxNumber) {
		this.rxNumber = rxNumber;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}
	
	public String execute() throws IOException{
		
		System.out.println("Rxnumber : "+rxNumber);
		System.out.println("Environment : "+env);
		//responseRepositoryPath = "C:\\Desktop";
		//rxNumber = "32578848";
		if(rxNumber.equals("") || env.equals("")){
			throw new IllegalArgumentException("invalid input");
		}
		CaptureUtilDAO captureUtilDAO = new CaptureUtilDAO();

		try {
			xmlDataList = captureUtilDAO.fetchDetailsFromEDP(rxNumber, env);
					
			request.getSession().setAttribute("xmls", xmlDataList);
			request.getSession().setAttribute("rxNumber", rxNumber);
			request.getSession().setAttribute("env", env);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return "error" ;
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return "error" ;
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "error" ;
		}
		
		return "success" ;
	}

	private HttpServletRequest request;
	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
		
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	
	private HttpServletResponse response;
	public void setServletResponse(HttpServletResponse arg1) {
		this.response=arg1;
		
	}
	public HttpServletResponse getResponse() {
		return response;
	}
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

}
