package com.ctl.app.virtual.action;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.app.virtual.util.AddKeyValueUtil;

public class DisplayControlFileContentAction implements ServletRequestAware,ServletResponseAware  {
	private HttpServletRequest request;
	private HttpServletResponse response;

	public String execute() throws IOException 
{
	String path=request.getParameter("controlFilePath");
	
	AddKeyValueUtil addKeyValueUtil=new AddKeyValueUtil();
	String output=addKeyValueUtil.displayControlFileContent(path);
	
	response.setContentType("text/text;charset=utf-8");
	response.setHeader("cache-control", "no-cache"); 
	PrintWriter out;
	try {
		out = response.getWriter();
		out.println(output); 
		out.flush(); 

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	

	return null;
}

public String tokenise(String[] controlFiles)
{
	String tokens=new String();
	for(int i=0;i<controlFiles.length;i++)
	{
		if(controlFiles[i]!=null){
		//System.out.println(controlFiles[i]);
		tokens=tokens.concat(controlFiles[i]);
		tokens=tokens.concat(",");
		}
				
	}
	
	return tokens;
}


public void setServletRequest(HttpServletRequest arg0) {
	this.request=arg0;
	
}

public HttpServletRequest getRequest() {
	return request;
}
public HttpServletResponse getResponse() {
	return response;
}

public void setResponse(HttpServletResponse response) {
	this.response = response;
}
public void setRequest(HttpServletRequest request) {
	this.request = request;
}


public void setServletResponse(HttpServletResponse arg0) {
	this.response=arg0;
	
}










}
