package com.ctl.app.virtual.action;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.ctl.simulation.action.JMSSimulatorAction;
import com.ctl.simulation.action.SimulatorAction;
import com.ctl.simulation.simulator.BusSimulator;
import com.ctl.simulation.simulator.ISimulator;
import com.ctl.simulation.simulator.JMSSimulator;
import com.ctl.simulation.simulator.WebSimulator;
import com.ctl.simulation.spring.BeanApplicationContext;

public class RetrieveServiceDetailsAction implements ServletRequestAware,ServletResponseAware{
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	


public String execute(){

String system=request.getParameter("system");
		String appId=request.getParameter("appId");
		String subSys=request.getParameter("subSys");
	System.out.println("subsys "+subSys);	

String partialBeanId=appId+"_"+system;
System.out.println("partial id "+partialBeanId);
String reqParams=retrieveServcieDetails(partialBeanId,subSys);

         
response.setContentType("text/text;charset=utf-8");
	response.setHeader("cache-control", "no-cache"); 
	PrintWriter out;
	try {
		out = response.getWriter();
		
	
			 out.println(reqParams); 
		
		out.flush(); 

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	

	return null;

}

	public String retrieveServcieDetails(String partialBeanId,String subSys){
		ISimulator iSimulator;
		String beanId=null;
		String partialBeanIdforBus = null;
		partialBeanIdforBus = partialBeanId.replaceAll("_",".");
		String[] strArayyBean= new String[BeanApplicationContext.getApplicationBeanIds().size()];
		strArayyBean = BeanApplicationContext.getApplicationBeanIds().toArray(strArayyBean);
		if(strArayyBean==null){
			System.out.println("bean id list is null....");
		}

		for(String str:strArayyBean){

			if(str.contains(partialBeanId)||str.contains(partialBeanIdforBus) )
			{
				beanId=str;
				System.out.println("bean Id matchin....");
				break;
			}
		}
		
		System.out.println("bean id "+beanId);
		if(beanId!=null)
		{
		iSimulator =(ISimulator) BeanApplicationContext.getApplicationContext().getBean(beanId);
		
		if(iSimulator instanceof WebSimulator){
			
		WebSimulator webSimulator =(WebSimulator) iSimulator;
		List<SimulatorAction> actionList=webSimulator.getActions();
		SimulatorAction action =null;//actionList.get(0);
		for (SimulatorAction simulatorAction : actionList) {
			if(simulatorAction.getActionFilePath().equals(subSys))
				action = simulatorAction;
		}
		HashMap<String, String> reqParamsMap=action.getReqParams();
		
		if(reqParamsMap!=null){
			String reqValues=new String();
			reqValues=getRequestParameters(reqParamsMap);
		return reqValues;
		}
		}
		
		else if(iSimulator instanceof BusSimulator){
			
			BusSimulator busSimulator=(BusSimulator) iSimulator;
			List<SimulatorAction> actionList=busSimulator.getActions();
			SimulatorAction action=actionList.get(0);
			HashMap<String, String> reqParamsMap=action.getReqParams();
			if(reqParamsMap!=null){
				String reqValues=new String();
				reqValues=getRequestParameters(reqParamsMap);
			return reqValues;
			}
		}
		
		else if(iSimulator instanceof JMSSimulator){
			
			JMSSimulator busSimulator=(JMSSimulator) iSimulator;
			List<JMSSimulatorAction> actionList=busSimulator.getActions();
			JMSSimulatorAction action=actionList.get(0);
			HashMap<String, String> reqParamsMap=action.getReqParams();
			if(reqParamsMap!=null){
				String reqValues=new String();
				reqValues=getRequestParameters(reqParamsMap);
			return reqValues;
			}
		}
		}
		
		return null;
	
	}
	
	public String getRequestParameters(HashMap<String, String> reqParamsMap){
		
		System.out.println("map nt null...");
		Set<String> reqKeySet=reqParamsMap.keySet();
		
		String reqValues=new String();

	
		for(String key:reqKeySet){

			String reqParamTemp=reqParamsMap.get(key);
			String reqParam = null;
			if(reqParamTemp.contains("#"))
			{
				reqParam = reqParamTemp.split("#")[2];
			}
	
			String actual=reqParamTemp.substring(reqParamTemp.lastIndexOf('/')+1,reqParamTemp.length());
			reqValues=reqValues.concat(actual);
		
			reqValues=reqValues.concat(",");
			System.out.println("req value string "+reqValues );
			
		}
		
		return reqValues;
		
	}
	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		this.response=arg0;
		
	}
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		this.request=arg0;
		
	}

	

}
