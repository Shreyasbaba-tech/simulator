package com.ctl.app.virtual.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.ctl.app.virtual.AddResponseInfo;
import com.ctl.app.virtual.util.AddResponseUtil;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.opensymphony.xwork2.ActionSupport;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.xml.sax.SAXException;

public class AddResponseAction extends ActionSupport implements ServletRequestAware{
private AddResponseInfo responseInfo;
private AddResponseUtil responseUtil;
private String content;
private String searchTags;
private ArrayList<String>  systems;
private HttpServletRequest request;
 
public AddResponseAction()
{
	if(responseInfo==null){
		responseInfo=new AddResponseInfo();
	}
	if(responseUtil==null){
		responseUtil = new AddResponseUtil();
	}

	systems=null;//responseUtil.listSystems();
}

public String execute() throws Exception {
	
	try {
	
		AddResponseInfo info=(AddResponseInfo)request.getSession().getAttribute("responseAdd_Data");
		//info.setKey(responseInfo.getKey());
	
		
		//////////////////
			String s=request.getParameter("rowCount");
			//System.out.println(s);
			int rowCount=Integer.parseInt(s);
		//System.out.println("rowCount "+rowCount);
		
		String keyValue=new String();
		for(int i=0;i<rowCount;i++){
			String textId="text"+i;
			String textValue=request.getParameter(textId);
			System.out.println("value "+textValue);
			
			keyValue=keyValue.concat(textValue);
			
		}
		System.out.println("final key "+ keyValue);
		info.setKey(keyValue);
		
	//////////////////////	
		
		info.setDesc(responseInfo.getDesc());
		info.setSampleXml(responseInfo.getSampleXml());
		info.setSearchTags(responseInfo.getSearchTags());
		responseUtil.addResponse(info);
		
	} catch (Exception e) {
		e.printStackTrace();
		 return ERROR;
	}
	
	return "success";   
  
}

public String showAddNewResponsePage()
{
	request.getSession().setAttribute("responseAdd_Data", responseInfo);
	return "success";
}

public String showEditResponsePage() 
{
	AddResponseUtil util=new AddResponseUtil();
    try {
    	String content=util.readResponseFileContents(responseInfo);
    	String searchTags;
		try {
			searchTags = util.readSearchTags(responseInfo);
			//responseInfo.setSearchTags(searchTags);
			content = content.replaceAll("[\\r\\n]", "");
			//content = StringEscapeUtils.escapeHtml(content);
			request.setAttribute("content", content);
			request.setAttribute("searchTags", searchTags);
			request.getSession().setAttribute("response_Data", responseInfo);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return "success";
}

public String editResponse()
{
	System.out.println("retrieved content= "+content);
	AddResponseInfo info=(AddResponseInfo)request.getSession().getAttribute("response_Data");
	info.setSearchTags((String)request.getAttribute("searchTags"));
	AddResponseUtil util=new AddResponseUtil();
	String key=info.getKey();
	key=key.replace(".vm", "");
	//info.setKey(key);
	util.editResponseFile(info, content);
	
	
	return "success";
}
public String showSaveAsNewResponse()
{
	AddResponseInfo info=(AddResponseInfo)request.getSession().getAttribute("response_Data");
	System.out.println(info.getAppId()+"+"+info.getSystem()+info.getSubSystem()+info.getKey());
	
	return "success";
	
}

public String saveAsNewResponse()
{
	AddResponseInfo info=(AddResponseInfo)request.getSession().getAttribute("response_Data");
	System.out.println("retrieved content= "+content);
	
	String responsePath=SimulatorContextBeanPropertUtil.getResponseFilePath();
	String appPath=responsePath+info.getAppId();
	String sysPath=appPath+"/"+info.getSystem();
	String subSysPath=sysPath+"/"+info.getSubSystem();
	System.out.println(subSysPath);
	String fileName=info.getKey();
	System.out.println(fileName);
	File xml = AddResponseUtil.writeToNewFile(subSysPath, fileName, content);
	
	responseInfo.setSampleXml(xml);
	
	//responseInfo.setSearchTags((String)request.getAttribute("searchTags"));
	
//////////////////
String s=request.getParameter("rowCount");
System.out.println(s);
int rowCount=Integer.parseInt(s);
//System.out.println("rowCount "+rowCount);

String keyValue=new String();
for(int i=0;i<rowCount;i++){
String textId="text"+i;
String textValue=request.getParameter(textId);
System.out.println("value "+textValue);

keyValue=keyValue.concat(textValue);
//keyValue=keyValue.concat(")
}
// keyValue=keyValue.r
//keyValue=keyValue.replaceFirst("_", "");
System.out.println("final key "+ keyValue);
responseInfo.setKey(keyValue);

//////////////////////	
responseInfo.setAppId(info.getAppId());
responseInfo.setSystem(info.getSystem());
responseInfo.setSubSystem(info.getSubSystem());
//responseInfo.setDesc(responseInfo.getDesc());
//responseInfo.setSampleXml(responseInfo.getSampleXml());
//responseInfo.setSearchTags(responseInfo.getSearchTags());
responseUtil.addResponse(responseInfo);
	
	
	
	return "success";
}

public String showXmlTree()
{
	
	
	String responsePath =SimulatorContextBeanPropertUtil.getResponseFilePath()+responseInfo.getAppId()+"/"+responseInfo.getSystem()+"/"+responseInfo.getSubSystem()+"/"+responseInfo.getKey();
	

	responsePath = responsePath.replaceFirst("/", "");
	System.out.println("Showing xmlTree for the file: "+responsePath);
	request.setAttribute("responsePath", responsePath);
	request.setAttribute("respName", responseInfo.getKey());
	File source= new File(responsePath);
	
	 RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
	    String xmlTreesPath=contextDeploymentUtil.getConfigItPath().substring(0, contextDeploymentUtil.getConfigItPath().lastIndexOf("config"));
	File dest = new File(xmlTreesPath+"xmltree/");
	
	
	try {
		System.out.println(dest.getCanonicalPath());
		System.out.println(dest.getAbsolutePath());
		FileUtils.copyFileToDirectory(source, dest);
		System.out.println("copied");
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	
	
	return "success";
}

private static void copyFile(File sourceFile, File destFile)
		throws IOException {
	if (!sourceFile.exists()) {
		return;
	}
	if (!destFile.exists()) {
		destFile.createNewFile();
	}
	FileChannel source = null;
	FileChannel destination = null;
	source = new FileInputStream(sourceFile).getChannel();
	destination = new FileOutputStream(destFile).getChannel();
	if (destination != null && source != null) {
		destination.transferFrom(source, 0, source.size());
	}
	if (source != null) {
		source.close();
	}
	if (destination != null) {
		destination.close();
	}

}
public AddResponseInfo getResponseInfo() {
	return responseInfo;
}

public void setResponseInfo(AddResponseInfo responseInfo) {
	this.responseInfo = responseInfo;
}

public AddResponseUtil getResponseUtil() {
	return responseUtil;
}

public void setResponseUtil(AddResponseUtil responseUtil) {
	this.responseUtil = responseUtil;
}

public List<String> getSystems() {
	return systems;
}

public void setSystems(ArrayList<String> systems) {
	this.systems = systems;
}



public String populateSystem(){
	systems=null;
	return "success";
	
	
}


public String getContent() {
	return content;
}

public void setContent(String content) {
	this.content = content;
}

public void setServletRequest(HttpServletRequest arg0) {
	// TODO Auto-generated method stub
	this.request=arg0;
}

public String getSearchTags() {
	return searchTags;
}

public void setSearchTags(String searchTags) {
	this.searchTags = searchTags;
}

}
