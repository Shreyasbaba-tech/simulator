package com.ctl.app.virtual.action;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.springframework.context.ApplicationContext;
import com.ctl.app.virtual.ExternalDataPullDTO;
import com.ctl.app.virtual.dao.CaptureUtilDAO;
import com.ctl.simulation.action.SimulatorAction;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.helper.XPathReader;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.ctl.simulation.spring.BeanApplicationContext;

public class dumpXMLDataAction implements ServletRequestAware {
	private static String rxNumberVal;
	private String envVal;
	private String combinedString;
	private List<ExternalDataPullDTO> xmlDataList;
	private static String responseRepositoryPath;
	private static com.ctl.simulation.simulator.Simulator simulatorBean = null;
	private static ApplicationContext ctx = BeanApplicationContext
			.getApplicationContext();
	private String appId;

	public dumpXMLDataAction() {
		// TODO Auto-generated constructor stub
	}

	public String getRxNumber() {
		return rxNumberVal;
	}

	public void setRxNumber(String rxNumber) {
		this.rxNumberVal = rxNumber;
	}

	public String getEnv() {
		return envVal;
	}

	public void setEnv(String env) {
		this.envVal = env;
	}

	@SuppressWarnings("unchecked")
	public String execute() throws IOException {
		rxNumberVal = request.getParameter("rxNumberVal");
		envVal = request.getParameter("envVal");
		System.out.println("Rxnumber : " + rxNumberVal);
		System.out.println("Environment : " + envVal);
		System.out.println("CombinedString : " + combinedString);
		System.out.println("appId in dump action : " + appId);
		RxContextPathDeploymentUtil contextDeploymentUtil = new RxContextPathDeploymentUtil();
		String path = contextDeploymentUtil.getConfigItPath().replace("it",
				"captureConfig.properties");
		Properties prop = new Properties();
		try {
			FileInputStream f = new FileInputStream(path);
			prop.load(f);
		} catch (Exception e) {

		}
		responseRepositoryPath = prop.getProperty("respRepositoryPath");
		System.out
				.println("responseRepositoryPath : " + responseRepositoryPath);

		if (rxNumberVal.equals("") || envVal.equals("")) {
			throw new IllegalArgumentException("invalid input");
			// return null;
		}
		String edpCheckAis[] = StringUtils.split(combinedString, ":");
		CaptureUtilDAO captureUtilDAO = new CaptureUtilDAO();
		String responseXml = null;
		String filePath = null;
		String externaDataPullAi = null;

		try {
			xmlDataList = captureUtilDAO.fetchResponseFromEDP(rxNumberVal,
					envVal);
			Iterator<ExternalDataPullDTO> itr = xmlDataList.iterator();

			while (itr.hasNext()) {
				try {

					ExternalDataPullDTO element = itr.next();
					responseXml = element.getXmlData();
					externaDataPullAi = element.getExternalDataPullAi();
					String dataSourceVal = null;
					for (String edpAi : edpCheckAis) {
						if (externaDataPullAi.equals(edpAi)) {
							System.out.println("List Ai :" + externaDataPullAi);
							System.out.println("Selected Ai :" + edpAi);
							System.out.println("Data Source :\n"
									+ element.getDataSource());
    						dataSourceVal = prop.getProperty(element
									.getDataSource());
							if (dataSourceVal != null && dataSourceVal != "") {
								System.out.println("Data Source Available :\n"
										+ dataSourceVal);
								if (element.getXmlData() != null
										&& responseXml.indexOf('<') != -1) {
									System.out
											.println("----------------------------------------------");
									System.out.println("Data Source :\n"
											+ dataSourceVal);
									System.out.println("\nresponseXml:\n"
											+ responseXml);
									System.out
											.println("----------------------------------------------");
									simulatorBean = (com.ctl.simulation.simulator.Simulator) ctx
											.getBean(dataSourceVal);
									filePath = getfilePath(simulatorBean,
											element.getRequestXmlData());
									System.out.println("filePath :" + filePath);
									storeResponseInFileSystem(responseXml,
											filePath);
								}
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "error";
		}

		return "success";
	}

	private static String getfilePath(
			com.ctl.simulation.simulator.Simulator simulatorBean,
			String requestXml ) {
		// TODO Auto-generated method stub
		SimulatorContextBeanPropertUtil simulatorContextBeanPropertUtil = new SimulatorContextBeanPropertUtil();
		String operationName=simulatorContextBeanPropertUtil.getOperationName(requestXml);
		SimulatorAction action = new SimulatorAction();
		String baseFilePath = simulatorBean.getSimulatorFilePath();
		List<SimulatorAction> actions = simulatorBean.getActions();
		String completeFilePath = null;

		for (SimulatorAction object : actions) {
			action = (SimulatorAction) object;
			String actionXpath = action.getActionXpath();
			String actionXpathValue = action.getActionXpathValue();
			boolean checkForActionXpathPresence = action
					.isCheckForActionXpathPresence();
			if (checkForActionXpathPresence) {
				if (StringUtils.isNumeric(requestXml)) {
					completeFilePath = baseFilePath + "//" + requestXml + ".vm";
				} else if (XPathReader.xmlParser(actionXpath, requestXml) != null) {
					if (action.getFilePathAvailable(requestXml) != null) {
						completeFilePath = baseFilePath
								+ "//" + operationName +"//"
								+ action.getFilePath(requestXml).get(
										"exactFileName") + ".vm";
						break;
					}
				}
			} else {
				if (XPathReader.xmlParser(actionXpath, requestXml) != null)
					if (XPathReader.xmlParser(actionXpath, requestXml).equals(
							actionXpathValue)) {
						completeFilePath = baseFilePath
								+ "//" + operationName +"//"
								+ action.getFilePath(requestXml).get(
										"exactFileName") + ".vm";
						break;
					}
			}
		}
		return completeFilePath;

	}

	private static void storeResponseInFileSystem(String responseXml,
			String filePath) throws IOException {
		File file = new File(filePath);
		if (!file.exists()) {
			int i = filePath.lastIndexOf("//");
			String directoryPath = filePath.substring(0, i);
			new File(directoryPath).mkdirs();
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		// store the response file
		storeFile(responseXml, file);
	}

	public static void storeFile(String xmlData, File file) throws IOException {

		FileWriter fstream = null;
		BufferedWriter out = null;
		try {
			fstream = new FileWriter(file);
			out = new BufferedWriter(fstream);
			out.write(xmlData);

		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());

		} finally {
			if (out != null) {
				out.flush();
				out.close();
			}
			if (fstream != null) {
				fstream.close();
			}

		}

	}

	private HttpServletRequest request;

	public void setServletRequest(HttpServletRequest arg0) {
		this.request = arg0;

	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	private HttpServletResponse response;

	public void setServletResponse(HttpServletResponse arg1) {
		this.response = arg1;

	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public String getCombinedString() {
		return combinedString;
	}

	public void setCombinedString(String combinedString) {
		this.combinedString = combinedString;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

}
