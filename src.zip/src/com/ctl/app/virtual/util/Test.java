package com.ctl.app.virtual.util;

import java.io.File;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;


public class Test {
	public static void main(String arg[]){
		   String zipFile = "RMTE E 674877 MST";
           String srcDir = "MORE:CUS\r\n WBH=Y:LB=N:DB=N:MW=N:MSC=Y:PIPE=100:ISP=USWNETDNVR:LSO=50:L-1:QAEN:P=1:ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt";
           int rmteLength = zipFile.length();
			int docomNotesLength = srcDir.length();
			
			int newDocomNotesLength = (rmteLength+docomNotesLength) > 495 ? docomNotesLength - (rmteLength+docomNotesLength-495): docomNotesLength;
			
			String newDocomNotes = StringUtils.substring(srcDir, 0, newDocomNotesLength);
			
			System.out.println(newDocomNotes);

	}

	private static void createAFile(Node mainListElement) {
		TransformerFactory tFactory = TransformerFactory.newInstance(); 
		Transformer transformer;
		Source source = new DOMSource(mainListElement);
		Result output = new StreamResult(new File("merged.xml"));	
		try {
			transformer = tFactory.newTransformer();
			transformer.transform(source, output);
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
					
	}
	
	private static void createAFile(Document mainListElement,String fileName) {
		TransformerFactory tFactory = TransformerFactory.newInstance(); 
		Transformer transformer;
		Source source = new DOMSource(mainListElement);
		Result output = new StreamResult(new File(fileName));	
		try {
			transformer = tFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, mainListElement.getDoctype().getPublicId());
			transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, mainListElement.getDoctype().getSystemId());
			transformer.transform(source, output);

		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
					
	}
}

