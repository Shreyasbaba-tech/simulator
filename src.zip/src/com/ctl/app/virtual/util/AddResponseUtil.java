package com.ctl.app.virtual.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ctl.app.virtual.AddResponseInfo;
import com.ctl.app.virtual.AddServiceInfo;
import com.ctl.app.virtual.SearchPojo;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;


public class AddResponseUtil {

	public  void addResponse(AddResponseInfo responseInfo)  {
		try {
			addTagsAndDescription(responseInfo.getKey(),responseInfo.getSearchTags(),responseInfo.getDesc(),responseInfo.getSystem(),responseInfo.getSubSystem());
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String responsePath=SimulatorContextBeanPropertUtil.getResponseFilePath();
		String appPath=responsePath+"/"+responseInfo.getAppId();
		String sysPath=appPath+"/"+responseInfo.getSystem();
		String subSysPath=sysPath+"/"+responseInfo.getSubSystem();
		System.out.println(subSysPath);
		String fileName=responseInfo.getKey()+".vm";
		System.out.println(fileName);
		File f=responseInfo.getSampleXml();
		AddKeyValueUtil util=new AddKeyValueUtil();
		
		String content=null;
		try {
			content = util.readFileAsString(f.getPath());
			System.out.println("content of sample xml= "+ content);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		File dir=new File(responsePath);
		File app=new File(appPath);
		File sys=new File(sysPath);
		File subSys=new File(subSysPath);
		
		//if response folder does not exist
		if(!dir.exists()){
			
			subSys.mkdirs();
			//System.out.println(subSysPath);
			writeToFile(subSysPath, fileName, content);
			 	
			
		}
		else{
			//if app does not exist
			 if(!app.exists())
			 {
				 subSys.mkdirs();
				 writeToFile(subSysPath, fileName, content);
			 }
			 else
			 {
				 
			
			//if sys folder does not exist
			if(!sys.exists()){
				subSys.mkdirs();
				sysPath=responsePath;
				writeToFile(subSysPath, fileName, content);
			}
			else{
			
				if(subSys.exists()){
					writeToFile(subSysPath, fileName, content);	
				}	
				else
				{
					//create sub system
				 subSys.mkdir();
				 subSysPath=sysPath;
				 writeToFile(subSysPath, fileName, content);
				}
			
			}//end else 
		}//end outer else 
		} //end outer if 
	
	
		}
		
		
	public void editResponseFile(AddResponseInfo responseInfo,String content)
	{
		String responsePath=SimulatorContextBeanPropertUtil.getResponseFilePath();
		String appPath=responsePath+"/"+responseInfo.getAppId();
		String sysPath=appPath+"/"+responseInfo.getSystem();
		String subSysPath=sysPath+"/"+responseInfo.getSubSystem();
		System.out.println(subSysPath);
		String fileName=responseInfo.getKey();
		writeToFile(subSysPath, fileName, content);
		editSearchDB(responseInfo);
		System.out.println("ho gaya 1");
		
	}
	
	public void editSearchDB(AddResponseInfo responseInfo)
	{
		    RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
		    String searchDBPath=contextDeploymentUtil.getConfigItPath()+"SearchDB.xml";
		    String searchTags = responseInfo.getSearchTags();
		    String key = responseInfo.getKey().replace(".vm", "");
		    editSearchTags(searchTags, key);
		    
		
	}
	
	public void editSearchTags(String searchTags, String key)
	{
		 RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
		    String searchDBPath=contextDeploymentUtil.getConfigItPath()+"SearchDB.xml";
		  
		    
		   

			try {
				 
			    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(searchDBPath);
				System.out.println(searchDBPath);
				
				  Node rootNode =doc.getFirstChild();
				  NodeList nodes = doc.getElementsByTagName("key");
				  for(int i = 0; i < nodes.getLength(); i++)
				  {
					  Node curNode = nodes.item(i);
					 // System.out.println(curNode.getFirstChild().getTextContent());
					   
					  String keyName = doc.getElementsByTagName("keyName").item(i).getTextContent();
					  //String keyName = curNode.getChildNodes().item(1).getTextContent();
					  if(keyName.equals(key))
					  {
						  
						  Node tagsNode = doc.getElementsByTagName("tags").item(i);
						  curNode.removeChild(tagsNode);
						 
						  
						  Element newTagNode = doc.createElement("tags");
						  String[] searchTagArray = searchTags.split("#");
						  for(String tag:searchTagArray)
						  {
							  Element tagElement = doc.createElement("tag");
							  tagElement.appendChild(doc.createTextNode(tag));
							  newTagNode.appendChild(tagElement);
						  }
						  curNode.insertBefore(newTagNode, doc.getElementsByTagName("description").item(i));
						  //curNode.appendChild(newTagNode);
					  }
					 
				  }
				  
				  TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = transformerFactory.newTransformer();
					DOMSource source = new DOMSource(doc);
					StreamResult result = new StreamResult(new File(searchDBPath));
					transformer.transform(source, result);	  
				  
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	      
			
	}
	
	public String readSearchTags(AddResponseInfo responseInfo) throws ParserConfigurationException, SAXException, IOException {
		String searchTags = null;
		String currentResponseName = responseInfo.getKey().replace(".vm", "");
		

		
		String keyName = "";
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    factory.setNamespaceAware(true);
	    DocumentBuilder builder;
	    Document doc = null;
	    XPathExpression expr = null;
	    builder = factory.newDocumentBuilder();
	    RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
	    String searchDBPath=contextDeploymentUtil.getConfigItPath()+"SearchDB.xml";
	   
         System.out.println("final path in searching : "+searchDBPath);
         
	    doc = builder.parse(searchDBPath);

	    // Create a XPathFactory
	    XPathFactory xFactory = XPathFactory.newInstance();

	    // Create a XPath object
	    XPath xpath = xFactory.newXPath();

	    // Compile the XPath expression
         
	    currentResponseName=currentResponseName.toLowerCase();
	   String xquery="//key[keyName[contains(translate(.,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'"+currentResponseName+"')]]//tag/text()";
	   // String xquery="//tags[tag[contains(tag,"+searchKey+")]]/../keyName/text()|//tags[tag[contains(tag,"+searchKey+")]]/../description/text()|//tags[tag[contains(tag,"+searchKey+")]]/../system/text()|//tags[tag[contains(tag,"+searchKey+")]]/../subSystem/text()";
	    try {
			expr = xpath.compile(xquery);
			 Object result = expr.evaluate(doc, XPathConstants.NODESET);
		       NodeList nodes = (NodeList) result;
			    for (int i=0; i<nodes.getLength();i=i+1){
			    //  System.out.println("keyName=  "+nodes.item(i).getNodeValue());
			      keyName+=nodes.item(i).getNodeValue()+"#";
			     			     
			    }
			    
			   
			    
					    
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    // Run the query and get a nodeset
	   
	    
	    // Cast the result to a DOM NodeList
	  

		//System.out.println(keyName+description+controlFilePath);
			
			if(keyName!=null && keyName.contains("#"))
			{
			searchTags = keyName.substring(0,keyName.lastIndexOf("#"));
			}
			else 
				searchTags = keyName;
		return searchTags;
	}
	public String readResponseFileContents(AddResponseInfo responseInfo) throws IOException {
		
	String responseFileContent=null;
		String responsePath=SimulatorContextBeanPropertUtil.getResponseFilePath();
		String appPath=responsePath+"/"+responseInfo.getAppId();
		String sysPath=appPath+"/"+responseInfo.getSystem();
		String subSysPath=sysPath+"/"+responseInfo.getSubSystem();
		String responseFilePath=subSysPath+"/"+responseInfo.getKey();
		System.out.println(responseFilePath);
		String fileName=responseInfo.getKey()+".vm";
		System.out.println("filename in addresponse action "+fileName);
		File f=responseInfo.getSampleXml();
		AddKeyValueUtil util=new AddKeyValueUtil();
		
		
		
		File dir=new File(responsePath);
		File app=new File(appPath);
		File sys=new File(sysPath);
		File subSys=new File(subSysPath);
		File resFilePath=new File(responseFilePath);
		//if response folder does not exist
		if(!dir.exists()){
			responseFileContent=util.readFileAsString(responseFilePath); 	
			
		}
		else{
			//if app does not exist
			 if(!app.exists())
			 {
				 responseFileContent=util.readFileAsString(responseFilePath); 
			 }
			 else
			 {
				//if sys folder does not exist
			if(!sys.exists()){
				//subSys.mkdirs();
				sysPath=responsePath;
				responseFileContent=util.readFileAsString(responseFilePath);  			
			}
			else{
				if(subSys.exists()){
					responseFileContent=util.readFileAsString(responseFilePath); 			
				}	
				else
				{
				 subSysPath=sysPath;
				 responseFileContent=util.readFileAsString(responseFilePath); 
				}
			
			}//end else 
		}//end outer else 
		} //end outer if 
		return responseFileContent;
	
	
		
		
	}
	
	
	private static boolean writeToFile(String subSysPath, String fileName,String content){
		boolean done =  false;
		try {
		File fil =  new File(subSysPath+"/"+fileName).getCanonicalFile();
		if(!fil.exists())
		{
			fil.createNewFile();
		}
			FileWriter fw  = new FileWriter(fil);
			fw.write(content);
			fw.close();
			done =  true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return done;
	}
	
	public static File writeToNewFile(String subSysPath, String fileName,String content){
		boolean done =  false;
		File fil = null;
		try {
			fil =  new File(subSysPath+"/"+fileName).getCanonicalFile();
		if(!fil.exists())
		{
			fil.createNewFile();
		}
			FileWriter fw  = new FileWriter(fil);
			fw.write(content);
			fw.close();
			done =  true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fil;
	}
	
	public static void addTagsAndDescription(String keyName,String tags,String description,String system,String subSystem) throws URISyntaxException
	{
		if(!StringUtils.isEmpty(keyName)
				&&!StringUtils.isEmpty(tags)
				&&!StringUtils.isEmpty(description)
				&&!StringUtils.isEmpty(system)
				&&!StringUtils.isEmpty(subSystem)){
			
		String[] tagArray=tags.split("#");
		AddServiceUtil addServiceUtil=new AddServiceUtil();
		RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
        String searchDBPath=contextDeploymentUtil.getConfigItPath()+"SearchDB.xml";
		    System.out.println(searchDBPath);
            System.out.println("final path : "+searchDBPath);
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(searchDBPath);
			
			
			NodeList nodeList = document.getElementsByTagName("keys");
			Node node = nodeList.item(0);
			Element keyElement = document.createElement("key");
			node.appendChild(keyElement);
			Element keyNameElement = document.createElement("keyName");
			Element descElement = document.createElement("description");
			Element sysElement = document.createElement("system");
			Element subSysElement = document.createElement("subSystem");
			Element tagsElement = document.createElement("tags");
			for(int i=0;i<tagArray.length;i++)
			{
				Element tagElement = document.createElement("tag");
				tagElement.appendChild(document.createTextNode(tagArray[i]));
				tagsElement.appendChild(tagElement);
			}
			
			descElement.appendChild(document.createTextNode(description));
			sysElement.appendChild(document.createTextNode(system));
			subSysElement.appendChild(document.createTextNode(subSystem));
			keyNameElement.appendChild(document.createTextNode(keyName));
			keyElement.appendChild(keyNameElement);
			keyElement.appendChild(sysElement);
			keyElement.appendChild(subSysElement);
			keyElement.appendChild(tagsElement);
			keyElement.appendChild(descElement);
			TransformerFactory tff  = TransformerFactory.newInstance();
			Transformer transformer = tff.newTransformer();
			DOMSource xmlSource = new DOMSource(document);
			StreamResult outputTarget = new StreamResult(searchDBPath);
			transformer.transform(xmlSource, outputTarget);
			
			
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		}
	}
}
