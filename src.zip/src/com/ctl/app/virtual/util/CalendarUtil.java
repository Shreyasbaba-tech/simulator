/**
 * 
 */
package com.ctl.app.virtual.util;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author aa47173
 *
 */
public class CalendarUtil {
	
	private Calendar localCalendar;
	private Calendar gmtCalendar;
	CalendarUtil(){
		this.localCalendar = Calendar.getInstance(TimeZone.getDefault());
		this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
	}
	
	public Date getCurrentDate(){
		return localCalendar.getTime();
	}
	
	public int getCurrentDay(){
		return localCalendar.get(Calendar.DATE);
	}
	
	public int getCurrentMonthNumber(){
		return localCalendar.get(Calendar.MONTH);
	}
	
	public String getCurrentMonth(){
		String monthArr[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		return monthArr[localCalendar.get(Calendar.MONTH)];
	}
	
	public int getCurrentYear(){
		return localCalendar.get(Calendar.YEAR);
	}
	
	public int getCurrentDayOfWeekNumber(){
		return localCalendar.get(Calendar.DAY_OF_WEEK);
	}
	
	public String getCurrentDayOfWeek(){
		String weekArr[]={"Sat","Sun","Mon","Tue","Wed","Thu","Fri"};
		return weekArr[localCalendar.get(Calendar.DAY_OF_WEEK)];
	}
	
	public int getCurrentDayOfMonth(){
		return localCalendar.get(Calendar.DAY_OF_MONTH);
	}
	
	public int getCurrentDayOfYear(){
		return localCalendar.get(Calendar.DAY_OF_YEAR);
	}
	
	public int getCurrentDayOfWeekInMonth(){
		return localCalendar.get(Calendar.DAY_OF_WEEK_IN_MONTH);
	}

}
