/**
 * 
 */
package com.ctl.app.virtual.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ctl.app.virtual.constant.CommonConstant;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;

/**
 * @author aa47173
 *
 */
public class CommonUtility {
	
	public static String readFileAsString(String filePath)
		    throws java.io.IOException{
		        StringBuffer fileData = new StringBuffer(1000);
		        BufferedReader reader = new BufferedReader(
		                new FileReader(filePath));
		        char[] buf = new char[1024];
		        int numRead=0;
		        while((numRead=reader.read(buf)) != -1){
		            String readData = String.valueOf(buf, 0, numRead);
		            fileData.append(readData);
		            buf = new char[1024];
		        }
		        reader.close();
		        return fileData.toString();
		    }
	public static boolean writeToFile(String packagePath, String fileName,String content){
		boolean done =  false;
		try {
			
			System.out.println("Cntent of the simualtor context : "+content);
			File filDirectory =  new File(packagePath);
			filDirectory.mkdirs();
			
			
			
			System.out.println("file path to be written : "+packagePath);
			File fil =  new File(packagePath+"/"+fileName);
			
			
			
			if(!fil.exists())
				fil.createNewFile();
			
			FileWriter fw  = new FileWriter(fil);
		
			fw.write(content);
			fw.close();
			done =  true;
		} catch (IOException e) {
			System.out.println("Failed to write into file, FIle path is  : "+packagePath);
			e.printStackTrace();
		}
		return done;
	}

	
	public static List<String> getSimulatorReqParams(String root, String operation){
		List<String> strList = new ArrayList<String>();
		System.out.println("-->"+root+"-->>"+operation);
		try {
			 
			File fXmlFile = new File(root);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
		 
			//optional, but recommended
			//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();
		 
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList1 = doc.getElementsByTagName("bean");
			for (int temp1 = 0; temp1 < nList1.getLength(); temp1++) {
				Node nNode1 = nList1.item(temp1);
				if (nNode1.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement1 = (Element) nNode1;
					if(eElement1.getAttribute("id")!=null && eElement1.getAttribute("id").contains(operation)){
						NodeList nList2 = eElement1.getElementsByTagName("property");
						
						System.out.println("----------------------------");
						
						for (int temp2 = 0; temp2 < nList2.getLength(); temp2++) {
							
							Node nNode2 = nList2.item(temp2);
							
							System.out.println("\nCurrent Element :" + nNode2.getNodeName());
							
							if (nNode2.getNodeType() == Node.ELEMENT_NODE) {		 
								Element eElement3 = (Element) nNode2;
								if(eElement3.getAttribute("name")!=null && eElement3.getAttribute("name").equals("reqParams")){
									NodeList nList3 = eElement3.getElementsByTagName("map");
									Node nNode3 = nList3.item(0);
									NodeList nList4 = ((Element)nNode3).getElementsByTagName("entry");
									for(int temp3 = 0; temp3 < nList4.getLength(); temp3++){
										String arg0 = ((Element)nList4.item(temp3)).getAttribute("value");//getAttribute("key");
										//String arg0 = ((Element)nList4.item(temp3)).getAttribute("key");
										arg0 = arg0.substring(arg0.lastIndexOf("/")+1);
										System.out.println("==>"+arg0);
										strList.add(arg0);
									}
									
								}
								
//					System.out.println("Staff id : " + eElement.getAttribute("id"));
//					System.out.println("First Name : " + eElement.getElementsByTagName("firstname").item(0).getTextContent());
//					System.out.println("Last Name : " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
//					System.out.println("Nick Name : " + eElement.getElementsByTagName("nickname").item(0).getTextContent());
//					System.out.println("Salary : " + eElement.getElementsByTagName("salary").item(0).getTextContent());
								
							}
						}
						
					}
				}
			}
			
		 
		    } catch (Exception e) {
			e.printStackTrace();
		    }
		Set set = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        set.addAll(strList);
        return new ArrayList(set);
	}
	
	


	
	
	public static void generateBulkXMLs(File f,String writePath, String elementToBeReplaced, String minRange, String maxRange, String format, List<String> stList){
		try {
			System.out.println("generateBulkXMLs(f,'"+writePath+"','"+elementToBeReplaced+"','"+minRange+"','"+maxRange+"','"+format);
			
			List<String> rangeList = new ArrayList<String>();
			if(format.equals(CommonConstant.IS_NUMBER)){
				rangeList = getNumberList(minRange,maxRange);
			}else if(format.equals(CommonConstant.IS_STRING)){
				
			}else if(format.equals(CommonConstant.IS_DATE)){
				
			}else{
				
			}
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			TransformerFactory transformerFactory = TransformerFactory.newInstance();         
			Transformer transformer = transformerFactory.newTransformer();   
			Document doc = dBuilder.parse(f);
			doc.getDocumentElement().normalize();
			
			System.out.println("root of xml file" + doc.getDocumentElement().getNodeName());
			int i=0;
			for (String string : rangeList) {
				doc.getElementsByTagName(elementToBeReplaced).item(0).setTextContent(string);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");     
				DOMSource source = new DOMSource(doc);             //write to console or file   
				String stringAfterUpdate = StringUtils.replace(string, "/", "");
				String temp = "";
				for(int g=0; g<stList.size(); g++){
					temp = temp+(Integer.parseInt(stList.get(g)));
				}
				//stringAfterUpdate = temp+(Integer.parseInt(stList.get(stList.size()-1))+Integer.parseInt(stringAfterUpdate));
				stringAfterUpdate = temp;
				//File fil =  new File(writePath+(f.getName().replace(".vm", ""))+"_"+stringAfterUpdate+".vm").getCanonicalFile();
			    File fil =  new File(writePath+(stringAfterUpdate + ".vm"));
				if(!fil.exists()){
					fil.createNewFile();
				}
				StreamResult file = new StreamResult(fil);     
				StreamResult console = new StreamResult(System.out);
				//write data    
				transformer.transform(source, console);          
				transformer.transform(source, file);
				
				// increase the req Ids by one
				for(int g=0; g<stList.size(); g++){
					int oldVal = Integer.parseInt(stList.get(g));
					stList.remove(g);
					stList.add(g,Integer.toString(oldVal +1));
				}
			}
			
			
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
	}
	
	public static List<String> getNumberList(String minRange, String maxRange){
		List<String> rangeList = new ArrayList<String>();
		int minR = Integer.parseInt(minRange);
		int maxR = Integer.parseInt(maxRange);
		for(int i = minR;i<=maxR;i++){
			rangeList.add(numberToString(i));
		}
		System.out.println("RangeList "+rangeList.toString());
		return rangeList;
	}
	public static String numberToString(int i){
//		if(i<10) return "0000"+i;
//		if(i>=10 && i<100) return "000"+i;
//		if(i>=100 && i<1000) return "00"+i;
//		if(i>=1000 && i<10000) return "0"+i;
//		if(i>=10000 && i<100000) return ""+i;
//		return "00000";
		return ""+i;
	}
	
	public static class pojo{
		public int a;
		public pojo() {
			// TODO Auto-generated constructor stub
		}
		public pojo(int a) {
			// TODO Auto-generated constructor stub
		this.a = a;
		}
	}
	
	
	public static void main(String[] args)
	{
		
		getContextFileList();
		
	}
	
	public static void swap(int a,int b)
	{
	   int temp = a;
		a=b;
		b=temp;
		System.out.println("inside swap method a= "+a);
		System.out.println("inside swap method b= "+b);
		
	}
/*	public static void main(String[] args)
	{
		
		Integer a= new Integer(20);
		Integer b = new Integer(10);
		swap(a,b);
		System.out.println("a= "+a);
		System.out.println("b= "+b);
		
	}
	
	public static void swap(Integer a,Integer b)
	{
	   Integer temp = new Integer(a);
		a=b;
		b=temp;
		System.out.println("inside swap method a= "+a);
		System.out.println("inside swap method b= "+b);
		
	}*/
	
	
/*	public static void main(String[] args)
	{
		pojo a = new pojo(20);
		pojo b = new pojo(10);
		System.out.println(a);
		System.out.println(b);
		swap(a,b);
		System.out.println("a= "+ a.a);
		System.out.println("b= "+ b.a);
		System.out.println(a);
		System.out.println(b);
		
	}
	
	public static void swap(pojo a,pojo b)
	{
	   pojo temp = new pojo();
	    temp.a = a.a;
		a.a = b.a;
		b.a = temp.a;
		System.out.println("inside swap method a= "+ a.a);
		System.out.println("inside swap method b= "+ b.a);
		System.out.println("inside swap method a= "+a);
		System.out.println("inside swap method b= "+b);
	}
	*/
	
	public static String fileToString(final File file) throws IOException {
	    StringBuilder result = new StringBuilder();
	    BufferedReader reader = null;
	    try {
	        reader = new BufferedReader(new FileReader(file));

	        char[] buf = new char[1024];

	        int r = 0;

	        while ((r = reader.read(buf)) != -1) {
	            result.append(buf, 0, r);
	        }
	    }
	    finally {
	        reader.close();
	    }

	    return result.toString();
	}
	public static String getPropertyValue(String propFileName, String propName){
		Properties prop = new Properties();
		try {
			//load a properties file
    		prop.load(CommonUtility.class.getClassLoader().getResourceAsStream(propFileName));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop.getProperty(propName)==null?"":prop.getProperty(propName);
	}
	
	public static List<String> getContextFileList(){
		List<String> fileList = new ArrayList<String>();
		RxContextPathDeploymentUtil util=new RxContextPathDeploymentUtil();
	    String path=util.getConfigItPath();
		File fXmlFile = new File(path+"application-context.xml");
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("import");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element :" + nNode.getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Resource : " + eElement.getAttribute("resource"));
					String rec = eElement.getAttribute("resource");
					rec = rec.substring(rec.lastIndexOf("/")+1);
					System.out.println("Resource : " + rec);
					fileList.add(rec);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
	    }
		return fileList;
	}
}
