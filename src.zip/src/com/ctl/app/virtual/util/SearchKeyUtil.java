package com.ctl.app.virtual.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


import com.ctl.app.virtual.SearchPojo;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;


public class SearchKeyUtil {

	public ArrayList<SearchPojo> searchKeyInTags(String searchKey) throws SAXException, IOException, ParserConfigurationException
	{
		System.out.println(searchKey);
		ArrayList<SearchPojo> resultList=new ArrayList<SearchPojo>();
		String keyName = null,description = null,controlFilePath=null,system=null,subSystem=null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    factory.setNamespaceAware(true);
	    DocumentBuilder builder;
	    Document doc = null;
	    XPathExpression expr = null;
	    builder = factory.newDocumentBuilder();
	    RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
	    String searchDBPath=contextDeploymentUtil.getConfigItPath()+"SearchDB.xml";
	   
         System.out.println("final path in searching : "+searchDBPath);
         
	    doc = builder.parse(searchDBPath);

	    // Create a XPathFactory
	    XPathFactory xFactory = XPathFactory.newInstance();

	    // Create a XPath object
	    XPath xpath = xFactory.newXPath();

	    // Compile the XPath expression
         
	    searchKey=searchKey.toLowerCase();
	   
	   String xquery="//tags[tag[contains(translate(.,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'"+searchKey+"')]]/../keyName/text()|//tags[tag[contains(translate(.,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'"+searchKey+"')]]/../description/text()|//tags[tag[contains(translate(.,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'"+searchKey+"')]]/../system/text()|//tags[tag[contains(translate(.,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'"+searchKey+"')]]/../subSystem/text()";
	   // String xquery="//tags[tag[contains(tag,"+searchKey+")]]/../keyName/text()|//tags[tag[contains(tag,"+searchKey+")]]/../description/text()|//tags[tag[contains(tag,"+searchKey+")]]/../system/text()|//tags[tag[contains(tag,"+searchKey+")]]/../subSystem/text()";
	    try {
			expr = xpath.compile(xquery);
			 Object result = expr.evaluate(doc, XPathConstants.NODESET);
		       NodeList nodes = (NodeList) result;
			    for (int i=0; i<nodes.getLength();i=i+4){
			    //  System.out.println("keyName=  "+nodes.item(i).getNodeValue());
			      keyName=nodes.item(i).getNodeValue();
			     
			      description=nodes.item(i+3).getNodeValue();
			      system=nodes.item(i+1).getNodeValue();
			      subSystem=nodes.item(i+2).getNodeValue();
		   
			      SearchPojo searchPojo=new SearchPojo(keyName,controlFilePath,description,system,subSystem);
			      resultList.add(searchPojo);
			    }
			    
			   
			    
					    
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    // Run the query and get a nodeset
	   
	    
	    // Cast the result to a DOM NodeList
	  

		//System.out.println(keyName+description+controlFilePath);

     
		
		return resultList;
	}
	
	
	public String fetchSearchTags(String appId,String system,String subSystem,String keyName)
	{
		String searchTags = "";
		 RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
		    String searchDBPath=contextDeploymentUtil.getConfigItPath()+"SearchDB.xml";
	
		    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		    factory.setNamespaceAware(true);
		    DocumentBuilder builder;
		    Document doc = null;
		    XPathExpression expr = null;
		    try {
				builder = factory.newDocumentBuilder();
				 doc = builder.parse(searchDBPath);
			} catch (ParserConfigurationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		   

		    // Create a XPathFactory
		    XPathFactory xFactory = XPathFactory.newInstance();

		    // Create a XPath object
		    XPath xpath = xFactory.newXPath();

		    // Compile the XPath expression
	         if(keyName.contains(".vm"));
		   keyName = keyName.replace(".vm", "");
		   
		   String xquery="//keys/key[keyName='"+ keyName +"' and system='"+ system +"']/tags/tag/text()";
		   System.out.println(xquery);
		   // String xquery="//tags[tag[contains(tag,"+searchKey+")]]/../keyName/text()|//tags[tag[contains(tag,"+searchKey+")]]/../description/text()|//tags[tag[contains(tag,"+searchKey+")]]/../system/text()|//tags[tag[contains(tag,"+searchKey+")]]/../subSystem/text()";
		    try {
				expr = xpath.compile(xquery);
				 Object result = expr.evaluate(doc, XPathConstants.NODESET);
			     NodeList nodes = (NodeList) result;
			     // List<String> nodes = (List<String>) result;
			      if(nodes != null && nodes.getLength() > 0)
			      for (int i = 0;i<nodes.getLength();i++) {
						System.out.println(nodes.item(i));
						searchTags += nodes.item(i).getNodeValue() + "#";
					}
			      if(nodes.getLength() ==0)
			      {
			    	  searchTags = "NO SEARCH TAGS AVAILABLE";
			      }
		    }
		    catch (Exception e) {
				// TODO: handle exception
		    	System.out.println();
			}
		    
		    System.out.println("saerch tags = "+searchTags);
		    return searchTags;
	}
}
