package com.ctl.app.virtual.util;

import com.qwest.appsec.actrl.*;
import com.qwest.common.util.EmployeeDetails;
import com.qwest.common.util.Employeedata;

public class LDAPUtil
{

	public boolean authenticate(String cuid , String pwd ){
		System.out.println( "In LDAPUtil.authenticate");
		try {
			AccessControl accessControl = AccessControlFactory.getInstance();
			BasicCredential basicCred = new BasicCredential( cuid, pwd );
			CTAuthToken token = accessControl.authenticate( basicCred );			
			return true;
			
		} catch (Exception e) {
			
			e.printStackTrace();
		} catch ( Throwable e  ) {
			e.printStackTrace();
		}
		return false;		
	}
	  private static Employeedata getEmployeeData(String cuid)
	    {
	        EmployeeDetails details = new EmployeeDetails();
	        Employeedata employeedata = details.getEmployeeDetails(cuid);
	        System.out.println("Name: "+employeedata.getName());
	        System.out.println("title:" +employeedata.getJobtitle());
	        System.out.println("division:" +employeedata.getDivision());
	        System.out.println("type:" +employeedata.getEmpType());
	       
	        System.out.println((new StringBuilder("Job Title : ")).append(employeedata.getJobtitle()).toString());
	        if(employeedata.getManagerCuid() != null)
	            return employeedata;
	        else
	            return null;
	    }
/*	  public String getUserRole(String cuid){
	  try{  
		 
		}catch(Exception e){  
		 // Do something here  
			e.printStackTrace();
		} 
	  }*/
   /*public String returnUserType(String cuid,String pwd)
   {
	   System.out.println("In LDAPUtil.returnUserType");
	   Properties props = new Properties(); 
	   InputStream inputStream =this.getClass().getClassLoader().getResourceAsStream("virtualapp.properties");
	   try {
		props.load(inputStream);
	} catch (IOException e) {
		e.printStackTrace();
	}
	   String user=props.getProperty("all.user1");
	   String admin=props.getProperty("all.admin");
	   if(user.equalsIgnoreCase(cuid))
	   {
		   try {
				AccessControl accessControl = AccessControlFactory.getInstance();
				BasicCredential basicCred = new BasicCredential( cuid, pwd );
				CTAuthToken token = accessControl.authenticate( basicCred );			
				return user;
				
			} catch (Exception e) {
				e.printStackTrace();
			} catch ( Throwable e  ) {
				e.printStackTrace();
			}   
	   }
	   if(admin.equalsIgnoreCase(cuid))
	   {
		   try {
				AccessControl accessControl = AccessControlFactory.getInstance();
				BasicCredential basicCred = new BasicCredential( cuid, pwd );
				CTAuthToken token = accessControl.authenticate( basicCred );			
				return admin;
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch ( Throwable e  ) {
				e.printStackTrace();
			}   
	   }
	   return null;
   }*/

    public static void main(String args[])
    {
    	LDAPUtil ut = new LDAPUtil();
        System.out.println(ut.authenticate("aa72995","ctlsrp_2061"));
       // System.out.println(ut.returnUserType("aa72995","ctlsrp_2061"));
        LDAPUtil.getEmployeeData("aa72995");
    }

    static 
    {
        System.setProperty("com.qwest.appsec.actrl.applName", "test");
        System.setProperty("com.qwest.appsec.actrl.ctenv", "employee.prod");
    }
}
