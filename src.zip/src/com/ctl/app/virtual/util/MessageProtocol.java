/**
 * 
 */
package com.ctl.app.virtual.util;

/**
 * @author aa47173
 *
 */
public class MessageProtocol {
	public String handleProtocolMessage(String messageText) {        
		String responseText;        
		if ("MyProtocolMessage".equalsIgnoreCase(messageText)) {            
			responseText = "I recognize your protocol message";        
		} else if ("MyProtocolMessage1".equalsIgnoreCase(messageText)) {            
			responseText = "I recognize your protocol message1";        
		} 
		else {            
			responseText = "Unknown protocol message: " + messageText;        
		}                 
		return responseText;    
	}

}
