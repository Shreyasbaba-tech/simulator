/**
 * 
 */
package com.ctl.app.virtual.util;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;

import com.ctl.app.virtual.constant.CommonConstant;
import com.ctl.app.virtual.util.MessageProtocol;

/**
 * @author aa47173
 *
 */
public class JMSServerUtility implements MessageListener{

	private static int ackMode;    
	private String messageQueueName;    
	private static String messageBrokerUrl;     
	private Session session;    
	private boolean transacted = false;    
	private MessageProducer replyProducer;    
	private int delMode;
	private String msg;
	static {        
		messageBrokerUrl = CommonUtility.getPropertyValue("config.properties", "MESSAGEBROKERURL");        
		//messageQueueName = "client.messages";        
		ackMode = Session.AUTO_ACKNOWLEDGE;  
	}
	
	public JMSServerUtility(){
		try {           
			//This message broker is embedded            
			BrokerService broker = new BrokerService();            
			broker.setPersistent(false);            
			broker.setUseJmx(false);            
			broker.addConnector(messageBrokerUrl);            
			broker.start();        
		} 
		catch (Exception e) {            
			e.printStackTrace();        
		}         
		new MessageProtocol();        
		this.setupMessageQueueConsumer();
	}
	
	/**
	 * Constructor for JMSServerUtility to all required parameters.
	 * @param messageQueueName String
	 * @param deliveryMode String
	 */
	public JMSServerUtility(String messageQueueName, String deliveryMode,String message){
		try {           
			//This message broker is embedded            
			BrokerService broker = new BrokerService();            
			broker.setPersistent(false);            
			broker.setUseJmx(false);            
			broker.addConnector(messageBrokerUrl);            
			broker.start();        
		} 
		catch (Exception e) {            
			e.printStackTrace();        
		}        
		
		this.messageQueueName = messageQueueName;
		this.delMode = deliveryMode.equals(CommonConstant.NON_PERSISTENT)?DeliveryMode.NON_PERSISTENT:DeliveryMode.PERSISTENT;
		
		new MessageProtocol();
		this.msg = message;
		this.setupMessageQueueConsumer();
	}
	
	private void setupMessageQueueConsumer() {
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(messageBrokerUrl);        
		Connection connection;        
		try {            
			connection = connectionFactory.createConnection();            
			connection.start();            
			this.session = connection.createSession(this.transacted, ackMode);            
			Destination adminQueue = this.session.createQueue(messageQueueName);             
			
			//Setup a message producer to respond to messages from clients, we will get the destination            
			//to send to from the JMSReplyTo header field from a Message            
			this.replyProducer = this.session.createProducer(null);            
			this.replyProducer.setDeliveryMode(delMode);             
			
			//Set up a consumer to consume messages off of the admin queue            
			MessageConsumer consumer = this.session.createConsumer(adminQueue);            
			consumer.setMessageListener(this);        
		} 
		catch (JMSException e) {           
			e.printStackTrace();        
		}    		
	}

	@Override
	public void onMessage(Message message) {
		try {            
			TextMessage response = this.session.createTextMessage();            
			if (message instanceof TextMessage) {                
				response.setText(msg);            
			}             
			
			//Set the correlation ID from the received message to be the correlation id of the response message            
			//this lets the client identify which message this is a response to if it has more than            
			//one outstanding message to the server            
			response.setJMSCorrelationID(message.getJMSCorrelationID());             
			
			//Send the response to the Destination specified by the JMSReplyTo field of the received message,            
			//this is presumably a temporary queue created by the client            
			this.replyProducer.send(message.getJMSReplyTo(), response);        
		} 
		catch (JMSException e) {            
			e.printStackTrace();
		}  
		
	}

}
