/**
 * 
 */
package com.ctl.app.virtual.util;

import java.util.Random;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

import com.ctl.app.virtual.constant.CommonConstant;

/**
 * @author aa47173
 *
 */
public class JMSClientUtility implements MessageListener{

	private static int ackMode;    
	private static String clientQueueName;     
	private boolean transacted = false;    
	private MessageProducer producer;  
	private int delMode;
	static {        
		clientQueueName = "client.messages";        
		ackMode = Session.AUTO_ACKNOWLEDGE;    
	}   
	
	public JMSClientUtility() {        
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(CommonUtility.getPropertyValue("config.properties", "MESSAGEBROKERURL"));        
		Connection connection;        
		try {            
			connection = connectionFactory.createConnection();            
			connection.start();            
			Session session = connection.createSession(transacted, ackMode);            
			Destination adminQueue = session.createQueue(clientQueueName);             
			
			//Setup a message producer to send message to the queue the server is consuming from            
			this.producer = session.createProducer(adminQueue);            
			this.producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);             
			
			//Create a temporary queue that this client will listen for responses on then create a consumer            
			//that consumes message from this temporary queue...for a real application a client should reuse            
			//the same temp queue for each message to the server...one temp queue per client            
			Destination tempDest = session.createTemporaryQueue();            
			MessageConsumer responseConsumer = session.createConsumer(tempDest);             
			
			//This class will handle the messages to the temp queue as well            
			responseConsumer.setMessageListener(this);             
			
			//Now create the actual message you want to send            
			TextMessage txtMessage = session.createTextMessage();            
			txtMessage.setText("MyProtocolMessage1");             
			
			//Set the reply to field to the temp queue you created above, this is the queue the server            
			//will respond to            
			txtMessage.setJMSReplyTo(tempDest);             
			
			//Set a correlation ID so when you get a response you know which sent message the response is for            
			//If there is never more than one outstanding message to the server then the            
			//same correlation ID can be used for all the messages...if there is more than one outstanding            
			//message to the server you would presumably want to associate the correlation ID with this            
			//message somehow...a Map works good            
			String correlationId = this.createRandomString();            
			txtMessage.setJMSCorrelationID(correlationId);            
			this.producer.send(txtMessage); 
		} catch (JMSException e) {  
			e.printStackTrace();
		}    
		
	}
	public JMSClientUtility(String messageQueueName, String deliveryMode/*NON_PERSISTENT or PERSISTENT*/) {        
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(CommonUtility.getPropertyValue("config.properties", "MESSAGEBROKERURL"));        
		Connection connection;   
		this.delMode = deliveryMode.equals(CommonConstant.NON_PERSISTENT)?DeliveryMode.NON_PERSISTENT:DeliveryMode.PERSISTENT;
		try {            
			connection = connectionFactory.createConnection();            
			connection.start();            
			Session session = connection.createSession(transacted, ackMode);            
			Destination adminQueue = session.createQueue(messageQueueName);             
			
			this.producer = session.createProducer(adminQueue);            
			this.producer.setDeliveryMode(this.delMode);             
			
			Destination tempDest = session.createTemporaryQueue();            
			MessageConsumer responseConsumer = session.createConsumer(tempDest);             
			
			responseConsumer.setMessageListener(this);             
			
			TextMessage txtMessage = session.createTextMessage();            
			txtMessage.setText("MyProtocolMessage1");             
			
			txtMessage.setJMSReplyTo(tempDest);             
			
			String correlationId = this.createRandomString();            
			txtMessage.setJMSCorrelationID(correlationId);            
			this.producer.send(txtMessage); 
		} catch (JMSException e) {     
			e.printStackTrace();
		}    
		
	}
	
	private String createRandomString() {        
		Random random = new Random(System.currentTimeMillis());        
		long randomLong = random.nextLong();        
		return Long.toHexString(randomLong);    
	}     
	public void onMessage(Message message) {        
		String messageText = null;        
		try {            
			if (message instanceof TextMessage) {                
				TextMessage textMessage = (TextMessage) message;                
				messageText = textMessage.getText();                
				System.out.println("Server messageText = " + messageText);            
			}        
		} 
		catch (JMSException e) {     
			e.printStackTrace();
		}    
	}
	
	public static void main(String args[]){
		new JMSClientUtility("1234",CommonConstant.PERSISTENT);
	}
	
}
