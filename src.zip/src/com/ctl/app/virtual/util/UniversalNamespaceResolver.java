/**
 * 
 */
package com.ctl.app.virtual.util;

import java.util.Iterator;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;

import org.w3c.dom.Document;

/**
 * @author aa47173
 *
 */
public class UniversalNamespaceResolver implements NamespaceContext{
	
	private Document sourceDocument;
	
	public UniversalNamespaceResolver(Document document) {
        sourceDocument = document;
    }
	
	public String getNamespaceURI(String prefix) {
        if (prefix.equals(XMLConstants.DEFAULT_NS_PREFIX)) {
            return sourceDocument.lookupNamespaceURI(null);
        } else {
            return sourceDocument.lookupNamespaceURI(prefix);
        }
    }
	
	public String getPrefix(String namespaceURI) {
        return sourceDocument.lookupPrefix(namespaceURI);
    }
	
	public Iterator getPrefixes(String namespaceURI) {
        // not implemented yet
        return null;
    }
}
