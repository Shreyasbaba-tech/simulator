// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   EmailUtils.java

package com.ctl.app.virtual.util;
import java.io.FileInputStream;

import java.util.*;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.opensymphony.xwork2.util.finder.Test;


// Referenced classes of package com.qwest.travel.utils:
//            PropertyManager, AsynchronousRequestEmail, LDAPUtil, AsynchronousTransportMail, 
//            AsynchronousAutoApproveEmail

public class EmailUtils {

	public EmailUtils() {
	}
 //This method can be used to directly send mails ..
	public static void postMail(String recipients[], String subject,
			String message, String from) {
		 
		java.net.URL location = Test.class.getProtectionDomain().getCodeSource().getLocation();
		String path=location.getPath();
		String contextPath=path.substring(0, path.lastIndexOf("WEB-INF"));
		contextPath=contextPath+"config/email.properties";
		
		Properties pro = new Properties();
		try {
			FileInputStream f = new FileInputStream(contextPath);
			pro.load(f);
		} catch (Exception e) {
			
		}
		
          
		
		try {
			String mailHost = pro.getProperty("MAIL_HOST");//(String) PropertyManager.getProperty("MAIL_HOST");
			String mailGateway =pro.getProperty("MAIL_GATEWAY");// (String) PropertyManager.getProperty("MAIL_GATEWAY");
			boolean debug = false;
			Properties props = new Properties();
			props.put(mailHost, mailGateway);
			Session session = Session.getDefaultInstance(props, null);
			session.setDebug(debug);
			Message msg = new MimeMessage(session);
			InternetAddress addressFrom = new InternetAddress(from);
			msg.setFrom(addressFrom);
			InternetAddress addressTo[] = new InternetAddress[recipients.length];
			for (int i = 0; i < recipients.length; i++)
				addressTo[i] = new InternetAddress(recipients[i].trim());

			msg.setRecipients(javax.mail.Message.RecipientType.TO, addressTo);
			msg.setSubject(subject);
			msg.setContent(message, "text/html");
			Transport.send(msg);
			System.out.println("Done!!!!!");
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	/*public void sendMail(String[] recipients, String subject,String msg,String senderEmail){
		
		
			
		
			
			
			OleFrame frame = new OleFrame(shell, SWT.NONE);
			OleClientSite site = new OleClientSite(frame, SWT.NONE, OLE_PROG_IDENTIFIER);
			site.doVerb(OLE.OLEIVERB_INPLACEACTIVATE);
			OleClientSite site2 = new OleClientSite(frame, SWT.NONE,OUTLOOK_APPLICATION);
			OleAutomation outlook = new OleAutomation(site2);
			OleAutomation mail = invoke(outlook, "CreateItem", 0 ).getAutomation();
			setProperty(mail, "To", recipients[0]);
			//setProperty(mail, "Cc", getPropertValue("mailCc"));
			//setProperty(mail, "Bcc", getPropertValue("mailBcc"));
			setProperty(mail, "BodyFormat", 1 );
			setProperty(mail, "Subject",subject);
			String content = msg;
			
				setProperty(mail, "HtmlBody", content);
			
			
		
			
			
			invoke(mail, "Display" );
			
		
	}
*/
	
	
}
