package com.ctl.app.virtual.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ctl.app.virtual.AddJMSServiceInfo;
import com.ctl.app.virtual.AddServiceInfo;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.ctl.simulation.spring.BeanApplicationContext;
import com.opensymphony.xwork2.util.finder.Test;

public class AddServiceUtil {
	private static Log logger =LogFactory.getLog("SimulationLogger");
	boolean isXPathCheck;
	String requestParamsBeanUtil;
	String requestParamsBean = "";
	String beanHead;
	Object[] requestParamsList =null;
	ArrayList<String> fileNameMap;
	String exactFileName = "";
	String fileNameUtil;
	String partFileNameUtil;
	private static String tailUtil;
	private HttpServletRequest request;
	String innerBeans;
	String beanTail;

	final static String appContextXmlPath="config//application-context.xml"; 
	public final static String BUS_SERVICE_CLASS_NAME = "com.ctl.simulation.simulator.BusSimulator";
	public final static String WEB_SERVICE_CLASS_NAME = "com.ctl.simulation.simulator.WebSimulator";
	public final static String HTTP_SERVICE_CLASS_NAME = "com.ctl.simulation.simulator.WebSimulator";
	public final static String JMS_SERVICE_CLASS_NAME = "com.ctl.simulation.simulator.JMSSimulator";
	public static final String SUN_JAVA_COMMAND = "sun.java.command";
	public AddServiceUtil(){}
	
	public void addNewService(AddServiceInfo serviceInfo,String keyXpath,String valueXpath,String key,String selectedOperationXpath){
		
		boolean createNewOperationFlag = (Boolean) request.getSession().getAttribute("createNewOperationFlag"); // from session variable set at AddServicePage_01;
		
		if(createNewOperationFlag)
		{
			addNewOperationToService(serviceInfo,keyXpath,valueXpath,key,selectedOperationXpath);
		}
		
		else
		addService(serviceInfo,keyXpath,valueXpath,key,selectedOperationXpath);
		
	}
	
	
	public void addJMSService(AddJMSServiceInfo servcInfo) {
		
		logger.info("Service creation is started ");
		SimulatorContextBeanPropertUtil simulatorContextBeanPropertUtil = new SimulatorContextBeanPropertUtil();
		FileSystemXmlApplicationContext context=null;
				RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
		String contextPath=contextDeploymentUtil.getConfigItPath()+"application-context.xml";
		String filePath = contextPath.substring(0, contextPath.length()-23);

		String beanHead;
		try {
			logger.info("Loading template is started ");
			beanHead = TemplateLoader.loadTemplate(new File(filePath + "JMSBeanTemplate").getCanonicalFile());
			requestParamsBeanUtil = TemplateLoader.loadTemplate(new File(filePath + "JMSBeanTemplate_RequestParameters").getCanonicalFile());
			fileNameUtil = TemplateLoader.loadTemplate(new File(filePath + "JMSBeanTemplate_ExactFileName").getCanonicalFile());
			partFileNameUtil = TemplateLoader.loadTemplate(new File(filePath + "JMSBeanTemplate_PartFileName").getCanonicalFile());
			tailUtil = TemplateLoader.loadTemplate(new File(filePath + "JMSBeanTemplate_Tail").getCanonicalFile());
			fileNameMap = new ArrayList<String>();
			Map<String, String> patterns = new HashMap<String, String>();
			
			List<String> tempXpathList = new ArrayList<String>();
			tempXpathList.add(servcInfo.getQueueName());
			servcInfo.setSelectedXpathsList(tempXpathList);
			logger.info("Loading template is success ");
			mapRequestParamsWithBean(servcInfo);
			
			simulatorContextBeanPropertUtil.setBeanId(servcInfo.getServName(), servcInfo.getServiceType(), servcInfo.getApplID(), servcInfo.getQueueName());
			
			patterns.put("$beanId", simulatorContextBeanPropertUtil.getBeanId());
			patterns.put("$queueSize", servcInfo.getQueueSize()+"");
			patterns.put("$deliveryMode", servcInfo.getDeliveryMode());
			patterns.put("$exactFileName", exactFileName);
			
			patterns.put("$secondBeanId","secondBeanId"+"_"+simulatorContextBeanPropertUtil.getBeanId()+"_"+servcInfo.getQueueName());
			patterns.put("$subSystemName", servcInfo.getQueueName());
			patterns.put("$systemName", servcInfo.getApplID()+"/"+servcInfo.getServName());
			patterns.put("$actionXpathValue", servcInfo.getQueueName());
			
			patterns.put("$simulatorClassName", JMS_SERVICE_CLASS_NAME);
			
			
			String beanUtil = beanHead + requestParamsBean + fileNameUtil + partFileNameUtil + tailUtil;
			beanUtil = TemplateLoader.applyPattern(beanUtil, patterns);
			
			logger.info("Simulator context file path: "+ filePath+"simulators/"+simulatorContextBeanPropertUtil.getBeanId() + "-simulator-context.xml");
			
			writeToFile(filePath+"simulators/", simulatorContextBeanPropertUtil.getBeanId()  
					+ "-simulator-context.xml", beanUtil);
			logger.info("Simulator context file created successfully");
			logger.info("File path before :" +filePath);
			
			RxContextPathDeploymentUtil ut= new RxContextPathDeploymentUtil();
			//context= new FileSystemXmlApplicationContext("/Qwest/config/it/simulators/"+simulatorContextBeanPropertUtil.getBeanId() + "-simulator-context.xml");
			context= new FileSystemXmlApplicationContext(ut.getConfigItPath()+"/simulators/"+simulatorContextBeanPropertUtil.getBeanId() + "-simulator-context.xml");
				logger.info("File path: " +filePath);
				logger.info("Created new application context");
				((ConfigurableApplicationContext)BeanApplicationContext.getApplicationContext()).getBeanFactory().registerSingleton(
						simulatorContextBeanPropertUtil.getBeanId(), context.getBean(
								simulatorContextBeanPropertUtil.getBeanId()));
				if(!BeanApplicationContext.getApplicationBeanIds().contains(simulatorContextBeanPropertUtil.getBeanId())){
					BeanApplicationContext.getApplicationBeanIds().add(simulatorContextBeanPropertUtil.getBeanId());
				}
				((ConfigurableApplicationContext)BeanApplicationContext.getApplicationContext()).start();
				logger.info("Service is updated to application context");
				updateApplicationContext(contextPath, simulatorContextBeanPropertUtil.getBeanId());
				logger.info("Update Application Context successfull");
//				serviceInfo.setServiceLocation(simulatorContextBeanPropertUtil.getServiceLocation(servName, serviceType, applID));
//				serviceInfo.setServiceURI(simulatorContextBeanPropertUtil.getBeanId());
				
				
				String defaultFileLocation=null; 
				defaultFileLocation=SimulatorContextBeanPropertUtil.getResponseFilePath()+servcInfo.getApplID()+"/"+servcInfo.getServName()
						+"/"+servcInfo.getQueueName();
				
				logger.info("Default file lcoation: "+defaultFileLocation);
				//File defaultFile=new File(defaultFileLocation);
				File sampleResponseFile=servcInfo.getFileField();
				 String content = FileUtils.readFileToString(sampleResponseFile);
				 writeToFile(defaultFileLocation, "default.vm", content);
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void addService(AddServiceInfo serviceInfo,String keyXpath,String valueXpath,String key,String selectedOperationXpath)
	{
		logger.info("Service creation is started ");
		SimulatorContextBeanPropertUtil simulatorContextBeanPropertUtil = new SimulatorContextBeanPropertUtil();
		FileSystemXmlApplicationContext context=null;
				RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
		String contextPath=contextDeploymentUtil.getConfigItPath()+"application-context.xml";
		String filePath = contextPath.substring(0, contextPath.length()-23);

		String beanHead;
		try {
			logger.info("Loading template is started ");
			beanHead = TemplateLoader.loadTemplate(new File(filePath + "BeanTemplate").getCanonicalFile());
			requestParamsBeanUtil = TemplateLoader.loadTemplate(new File(filePath + "BeanTemplate_RequestParameters").getCanonicalFile());
			fileNameUtil = TemplateLoader.loadTemplate(new File(filePath + "BeanTemplate_ExactFileName").getCanonicalFile());
			partFileNameUtil = TemplateLoader.loadTemplate(new File(filePath + "BeanTemplate_PartFileName").getCanonicalFile());
			tailUtil = TemplateLoader.loadTemplate(new File(filePath + "BeanTemplate_Tail").getCanonicalFile());
			fileNameMap = new ArrayList<String>();
			Map<String, String> patterns = new HashMap<String, String>();
			List<String> tempXpathList=new ArrayList<String>();
			Map<String, String> xpathMap=serviceInfo.getGeneratedXpathMap();
			if(key==null && keyXpath == null && valueXpath == null)
			{	
				
		/* for (Map.Entry<String, String> entry : xpathMap.entrySet())
		 {
			 System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
			 if(serviceInfo.getSelectedXpathsList().contains(entry.getKey()))
				 
			 tempXpathList.add(entry.getValue());
		 }*/
		
		 for (Iterator iterator = serviceInfo.getSelectedXpathsList().iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			if(xpathMap.containsKey(string))
				tempXpathList.add(xpathMap.get(string));
		 }
		
			}
			else
			{
				
				/* for (Map.Entry<String, String> entry : xpathMap.entrySet())
				 {
					 System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
					 if(serviceInfo.getSelectedXpathsList().contains(entry.getKey()))
					 tempXpathList.add(keyXpath+"#"+key+"#"+valueXpath);
				 }	*/
				 for (Iterator iterator = serviceInfo.getSelectedXpathsList().iterator(); iterator.hasNext();) {
						String string = (String) iterator.next();
						if(xpathMap.containsKey(string))
							 tempXpathList.add(keyXpath+"#"+key+"#"+valueXpath);
					}
			
			}
			 if(serviceInfo.getContentType()==null || !serviceInfo.getContentType().toLowerCase().equals("on"))
			 {
				 serviceInfo.setSelectedXpathsList(tempXpathList);
			 }
		 
		 
		 logger.info("Loading template is success ");
/*
 * Get Map and pass key. Map will return value
 * Temp List<> add values to list
 * update serviceInfo.setSelectedXpathsList()
 */
			mapRequestParamsWithBean(serviceInfo);
			
			simulatorContextBeanPropertUtil.setBeanId(serviceInfo.getServiceName(), serviceInfo.getServiceType(),
					serviceInfo.getApplicationId(),serviceInfo.getOperName());
	
			
			patterns.put("$beanId", simulatorContextBeanPropertUtil.getBeanId());
			patterns.put("$actionXPath", selectedOperationXpath);
			patterns.put("$exactFileName", exactFileName);
			
			//Inner bean id
			//if(serviceInfo.)
			String actionPathValue = serviceInfo.getActionXpathValue();
			if(StringUtils.isEmpty(actionPathValue)) 
			patterns.put("$secondBeanId","secondBeanId"+"_"+simulatorContextBeanPropertUtil.getBeanId()+"_"+serviceInfo.getOperName());
			else
			patterns.put("$secondBeanId","secondBeanId"+"_"+simulatorContextBeanPropertUtil.getBeanId()+"_"+serviceInfo.getOperName()+"_"+actionPathValue);	
			
			patterns.put("$subSystemName", serviceInfo.getOperName());
			patterns.put("$systemName", serviceInfo.getApplicationId()+"/"+simulatorContextBeanPropertUtil.getServiceName(serviceInfo));
			patterns.put("$jsonFormat", String.valueOf(serviceInfo.getContentType()));
			
			/*
			 * Not using the below 2 variable and setting its value to default
			 */
			
			
			if(StringUtils.isEmpty(actionPathValue)) // This means that operation selection is by element
			{
				patterns.put("$isXPathCheck", "true");
				patterns.put("$actionXpathValue", "");
			
			}
			else
			{
				patterns.put("$isXPathCheck", "false");
				patterns.put("$actionXpathValue", actionPathValue);
				
			}
			
			//patterns.put("$actionFilePath",actionPathValue);
			if("BusService".equalsIgnoreCase(serviceInfo.getServiceType()))
				patterns.put("$simulatorClassName", BUS_SERVICE_CLASS_NAME);
			else if("WebService".equalsIgnoreCase(serviceInfo.getServiceType()))
				patterns.put("$simulatorClassName", WEB_SERVICE_CLASS_NAME);
			else if("HttpService".equalsIgnoreCase(serviceInfo.getServiceType()))
				patterns.put("$simulatorClassName", HTTP_SERVICE_CLASS_NAME);
			
			String beanUtil = beanHead + requestParamsBean + fileNameUtil + partFileNameUtil + tailUtil;
			beanUtil = TemplateLoader.applyPattern(beanUtil, patterns);
			
			
			/*
			 * TODO
			 * 
			 */
			logger.info("Simulator context file path: "+ filePath+"simulators/"+simulatorContextBeanPropertUtil.getBeanId() + "-simulator-context.xml");
			
			writeToFile(filePath+"simulators/", simulatorContextBeanPropertUtil.getBeanId()  
					+ "-simulator-context.xml", beanUtil);
			logger.info("Simulator context file created successfully");
			logger.info("File path before :" +filePath);
			
		RxContextPathDeploymentUtil ut= new RxContextPathDeploymentUtil();
		//context= new FileSystemXmlApplicationContext("/Qwest/config/it/simulators/"+simulatorContextBeanPropertUtil.getBeanId() + "-simulator-context.xml");
		context= new FileSystemXmlApplicationContext("file:"+ut.getConfigItPath()+"/simulators/"+simulatorContextBeanPropertUtil.getBeanId() + "-simulator-context.xml");
			logger.info("File path: " +filePath);
			logger.info("Created new application context");
			((ConfigurableApplicationContext)BeanApplicationContext.getApplicationContext()).getBeanFactory().registerSingleton(
					simulatorContextBeanPropertUtil.getBeanId(), context.getBean(
							simulatorContextBeanPropertUtil.getBeanId()));
			if(!BeanApplicationContext.getApplicationBeanIds().contains(simulatorContextBeanPropertUtil.getBeanId())){
				BeanApplicationContext.getApplicationBeanIds().add(simulatorContextBeanPropertUtil.getBeanId());
			}
			((ConfigurableApplicationContext)BeanApplicationContext.getApplicationContext()).start();
			logger.info("Service is updated to application context");
			updateApplicationContext(contextPath, simulatorContextBeanPropertUtil.getBeanId());
			logger.info("Update Application Context successfull");
			serviceInfo.setServiceLocation(simulatorContextBeanPropertUtil.getServiceLocation(serviceInfo.getServiceName(), serviceInfo.getServiceType(), serviceInfo.getApplicationId()));
			if(!"BusService".equalsIgnoreCase(serviceInfo.getServiceType())){
				serviceInfo.setServiceURI(simulatorContextBeanPropertUtil.getBeanId());
			}else{
				serviceInfo.setServiceURI(SimulatorContextBeanPropertUtil.BUS_SERVICE_RVD);
			}
			
			String val ="";
			if(!StringUtils.isEmpty(actionPathValue)) 
			{
				val="_"+actionPathValue;
			}
			String defaultFileLocation=null; 
			defaultFileLocation=SimulatorContextBeanPropertUtil.getResponseFilePath()+"/"+serviceInfo.getApplicationId()+"/"+simulatorContextBeanPropertUtil.getServiceName(serviceInfo)
					+"/"+serviceInfo.getOperName()+val;
			
			logger.info("Default file lcoation: "+defaultFileLocation);
			//File defaultFile=new File(defaultFileLocation);
			File sampleResponseFile=serviceInfo.getSampleResponseFile();
			 String content = FileUtils.readFileToString(sampleResponseFile);
			 writeToFile(defaultFileLocation, "default.vm", content);
			/*
			 * wRITE  LOGIC TO UPLOAD SAMPLE RESPONSE TO rESPONSE DIRECTORY Response->AppID->ServiceName->
			 * 
			 * Condider this as default.vm
			 */
			System.out.println("new BeanID = "+simulatorContextBeanPropertUtil.getBeanId());
			String dataSource = (String)request.getSession().getAttribute("dataSource");
			if(!StringUtils.isBlank(dataSource))
				configureCaptureUtil(simulatorContextBeanPropertUtil.getBeanId(), dataSource);
			
			//soumya
			RxContextPathDeploymentUtil utilProp = new RxContextPathDeploymentUtil();
			String pathUser=utilProp.getConfigItPath().replace("it", "VirtualAppUser.properties");
			Properties pro = new Properties();
			try {
				FileInputStream f = new FileInputStream(pathUser);
				pro.load(f);
				String users=pro.getProperty("virApp.users");
				String apps=pro.getProperty(serviceInfo.getUserName());
				if(!users.contains(serviceInfo.getUserName())){
					System.out.println("updating properties file for new user ");
					logger.info("updating properties file for new user ");
					users=users.concat(","+serviceInfo.getUserName());
					pro.setProperty("virApp.users",users);
					//apps=apps.concat(","+serviceInfo.getApplicationId());
					pro.setProperty(serviceInfo.getUserName(), serviceInfo.getApplicationId());
					logger.info("updated properties file for new user ");
				}
				else{
					System.out.println("updating properties file for existing user for new service ");
					logger.info("updating properties file for existing user for new service ");
					if(!apps.contains(serviceInfo.getApplicationId()))
					{
					apps=apps.concat(","+serviceInfo.getApplicationId());
					pro.setProperty(serviceInfo.getUserName(), apps);
					logger.info("updated properties file for existing user for new service ");
					}
				}
				FileOutputStream out = new FileOutputStream(pathUser);
			    pro.store(out,null);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			//soumya
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void addNewOperationToService(AddServiceInfo serviceInfo,String keyXpath,String valueXpath,String key,String selectedOperationXpath)
	{
		SimulatorContextBeanPropertUtil simulatorContextBeanPropertUtil = new SimulatorContextBeanPropertUtil();
		FileSystemXmlApplicationContext context=null;
				RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
		String contextPath=contextDeploymentUtil.getConfigItPath()+"application-context.xml";
		String filePath = contextPath.substring(0, contextPath.length()-23);
		simulatorContextBeanPropertUtil.setBeanId(serviceInfo.getServiceName(), serviceInfo.getServiceType(),
				serviceInfo.getApplicationId(),serviceInfo.getOperName());
		
		File newNodeFile = createInnerBean(serviceInfo,keyXpath,valueXpath,key,selectedOperationXpath);
		String simFilePath = filePath+"simulators/"+simulatorContextBeanPropertUtil.getBeanId()  
				+ "-simulator-context.xml";
		String partialBeanId = serviceInfo.getApplicationId() + "_" + serviceInfo.getServiceName();
		String partialBeanIdForBus = serviceInfo.getApplicationId() + "." + serviceInfo.getServiceName();
		String beanId = "";
		
					String[] strArayyBean= new String[BeanApplicationContext.getApplicationBeanIds().size()];
					strArayyBean = BeanApplicationContext.getApplicationBeanIds().toArray(strArayyBean);
					if(strArayyBean==null){
						System.out.println("bean id list is null....");
											}
					for(String str:strArayyBean){

							if(str.contains(partialBeanId)||str.contains(partialBeanIdForBus))
				{
								beanId=str;
								System.out.println("bean Id matchin....");
								break;
				}
			
			
		
				}
					System.out.println("bean id "+beanId);
					simFilePath = filePath+"simulators/"+ beanId  
							+ "-simulator-context.xml";
					
		File simFile = new File(simFilePath);
		
		Document simDomObject = null;
		Document newBeanDomObject = null;
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder db;
		try {
			db = docBuilderFactory.newDocumentBuilder();
			simDomObject = db.parse(simFile);
			Element simRoot = simDomObject.getDocumentElement();
			Node mainListElement = simRoot.getElementsByTagName("list").item(0);
			
			newBeanDomObject = docBuilderFactory.newDocumentBuilder().parse(newNodeFile);		
			
			Node newBeanNode = (Node) newBeanDomObject.getDocumentElement();
			
			
			Node newNode = simDomObject.importNode(newBeanNode, true);
			
			mainListElement.appendChild(newNode);
			createAFile(simDomObject, simFilePath);
			
			RxContextPathDeploymentUtil ut= new RxContextPathDeploymentUtil();
			System.out.println("should be :"  + beanId);
			System.out.println("actually is : "+simulatorContextBeanPropertUtil.getBeanId());
			//context= new FileSystemXmlApplicationContext("/Qwest/config/it/simulators/"+beanId + "-simulator-context.xml");
			context= new FileSystemXmlApplicationContext(ut.getConfigItPath()+"/simulators/"+beanId + "-simulator-context.xml");
			
				logger.info("File path: " +filePath);
				logger.info("Created new application context");
				//((ConfigurableApplicationContext)BeanApplicationContext.getApplicationContext()).getBeanFactory().registerScope(simulatorContextBeanPropertUtil.getBeanId(), Scope.add(newScope));
				/*((ConfigurableApplicationContext)BeanApplicationContext.getApplicationContext()).getBeanFactory().registerSingleton(
						simulatorContextBeanPropertUtil.getBeanId(), context.getBean(
								simulatorContextBeanPropertUtil.getBeanId()));*/
				System.out.println("I am here :)");
				if(!BeanApplicationContext.getApplicationBeanIds().contains(simulatorContextBeanPropertUtil.getBeanId())){
					BeanApplicationContext.getApplicationBeanIds().add(simulatorContextBeanPropertUtil.getBeanId());
				}
				((ConfigurableApplicationContext)BeanApplicationContext.getApplicationContext()).start();
				logger.info("Service is updated to application context");
				//updateApplicationContext(contextPath, simulatorContextBeanPropertUtil.getBeanId());
				//logger.info("Update Application Context successfull");
				serviceInfo.setServiceLocation(simulatorContextBeanPropertUtil.getServiceLocation(serviceInfo.getServiceName(), serviceInfo.getServiceType(), serviceInfo.getApplicationId()));
				if(!"BusService".equalsIgnoreCase(serviceInfo.getServiceType())){
					serviceInfo.setServiceURI(simulatorContextBeanPropertUtil.getBeanId());
				}else{
					serviceInfo.setServiceURI(SimulatorContextBeanPropertUtil.BUS_SERVICE_RVD);
				}
				String actionPathValue = serviceInfo.getActionXpathValue();
				String val ="";
				if(!StringUtils.isEmpty(actionPathValue)) 
				{
					val="_"+actionPathValue;
				}
				
				String defaultFileLocation=null; 
				defaultFileLocation=SimulatorContextBeanPropertUtil.getResponseFilePath()+serviceInfo.getApplicationId()+"/"+simulatorContextBeanPropertUtil.getServiceName(serviceInfo)
						+"/"+serviceInfo.getOperName()+val;
				
				logger.info("Default file lcoation: "+defaultFileLocation);
				File sampleResponseFile=serviceInfo.getSampleResponseFile();
				 String content = FileUtils.readFileToString(sampleResponseFile);
				 writeToFile(defaultFileLocation, "default.vm", content);
				 
				 
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

		private void createAFile(Document mainListElement,String fileName) {
		TransformerFactory tFactory = TransformerFactory.newInstance(); 
		Transformer transformer;
		Source source = new DOMSource(mainListElement);
		Result output = new StreamResult(new File(fileName));	
		try {
			transformer = tFactory.newTransformer();
			
			transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, mainListElement.getDoctype().getPublicId());

			transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, mainListElement.getDoctype().getSystemId());

			transformer.transform(source, output);
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
					
	}
	public File createInnerBean(AddServiceInfo serviceInfo,String keyXpath,String valueXpath,String key,String selectedOperationXpath)
	{
		
		logger.info("Service creation is started ");
		SimulatorContextBeanPropertUtil simulatorContextBeanPropertUtil = new SimulatorContextBeanPropertUtil();
		FileSystemXmlApplicationContext context=null;
				RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
		String contextPath=contextDeploymentUtil.getConfigItPath()+"application-context.xml";
		String filePath = contextPath.substring(0, contextPath.length()-23);

		String beanHead = null;
		String part3 = null;
		fileNameMap = new ArrayList<String>();
		
		List<String> tempXpathList=new ArrayList<String>();
		Map<String, String> xpathMap=serviceInfo.getGeneratedXpathMap();
		if(key==null && keyXpath == null && valueXpath == null)
		{	
			
	/* for (Map.Entry<String, String> entry : xpathMap.entrySet())
	 {
		 System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
		 if(serviceInfo.getSelectedXpathsList().contains(entry.getKey()))
			 
		 tempXpathList.add(entry.getValue());
	 }*/
	 
	 for (Iterator iterator = serviceInfo.getSelectedXpathsList().iterator(); iterator.hasNext();) {
		String string = (String) iterator.next();
		if(xpathMap.containsKey(string))
			tempXpathList.add(xpathMap.get(string));
	}
	
		}
		else
		{
			
			/* for (Map.Entry<String, String> entry : xpathMap.entrySet())
			 {
				 System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				 if(serviceInfo.getSelectedXpathsList().contains(entry.getKey()))
				 tempXpathList.add(keyXpath+"#"+key+"#"+valueXpath);
			 }	*/
			 for (Iterator iterator = serviceInfo.getSelectedXpathsList().iterator(); iterator.hasNext();) {
					String string = (String) iterator.next();
					if(xpathMap.containsKey(string))
						 tempXpathList.add(keyXpath+"#"+key+"#"+valueXpath);
				}
		
		}
		
	 serviceInfo.setSelectedXpathsList(tempXpathList);
		
		logger.info("Loading template is started ");
		try {
			beanHead = TemplateLoader.loadTemplate(new File(filePath + "ActionBeanTemplete01").getCanonicalFile());
			requestParamsBeanUtil = TemplateLoader.loadTemplate(new File(filePath + "ActionBeanTempleteReqParam02").getCanonicalFile());
			part3 = TemplateLoader.loadTemplate(new File(filePath + "ActionBeanTemplete03").getCanonicalFile());
			partFileNameUtil = TemplateLoader.loadTemplate(new File(filePath + "ActionBeanTempletePartFile04").getCanonicalFile());
			tailUtil = TemplateLoader.loadTemplate(new File(filePath + "ActionBeanTemplete05").getCanonicalFile());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		simulatorContextBeanPropertUtil.setBeanId(serviceInfo.getServiceName(), serviceInfo.getServiceType(),
				serviceInfo.getApplicationId(),serviceInfo.getOperName());
		Map<String, String> patterns = new HashMap<String, String>();
		mapRequestParamsWithBean(serviceInfo);
		patterns.put("$beanId", simulatorContextBeanPropertUtil.getBeanId());
		
		patterns.put("$actionXPath", selectedOperationXpath);
		patterns.put("$exactFileName", exactFileName);
		
		String actionPathValue = serviceInfo.getActionXpathValue();
		if(StringUtils.isEmpty(actionPathValue)) 
		patterns.put("$secondBeanId","secondBeanId"+"_"+simulatorContextBeanPropertUtil.getBeanId()+"_"+serviceInfo.getOperName());
		else
		patterns.put("$secondBeanId","secondBeanId"+"_"+simulatorContextBeanPropertUtil.getBeanId()+"_"+serviceInfo.getOperName()+"_"+actionPathValue);	
			
		
		
		patterns.put("$subSystemName",serviceInfo.getOperName());
		patterns.put("$systemName", serviceInfo.getApplicationId()+"/"+simulatorContextBeanPropertUtil.getServiceName(serviceInfo));
		
		/*
		 * Not using the below 2 variable and setting its value to default
		 */
		
		
		
		
		if(StringUtils.isEmpty(actionPathValue)) // This means that operation selection is by element
		{
			patterns.put("$isXPathCheck", "true");
			patterns.put("$actionXpathValue", "");
		
		}
		else
		{
			patterns.put("$isXPathCheck", "false");
			patterns.put("$actionXpathValue",actionPathValue);
			
		}
		
		
		if("BusService".equalsIgnoreCase(serviceInfo.getServiceType()))
			patterns.put("$simulatorClassName", BUS_SERVICE_CLASS_NAME);
		else if("WebService".equalsIgnoreCase(serviceInfo.getServiceType()))
			patterns.put("$simulatorClassName", WEB_SERVICE_CLASS_NAME);
		else if("HttpService".equalsIgnoreCase(serviceInfo.getServiceType()))
			patterns.put("$simulatorClassName", HTTP_SERVICE_CLASS_NAME);
		
	
		
		String beanUtil = beanHead + requestParamsBean + part3 + partFileNameUtil + tailUtil;
		beanUtil = TemplateLoader.applyPattern(beanUtil, patterns);
		logger.info("Simulator context file path: "+ filePath+"simulators/Sahil-simulator-context.xml");
		
		writeToFile(filePath+"simulators/", "Temp_"+simulatorContextBeanPropertUtil.getBeanId()  
				+ "-simulator-context.xml", beanUtil);
		
		logger.info("Simulator context file created successfully");
		
		String contextFilePath = filePath+"simulators/"+"Temp_"+simulatorContextBeanPropertUtil.getBeanId()  
				+ "-simulator-context.xml";
		File contextFile = new File(contextFilePath);
		return contextFile;
	}
	
	private void mapRequestParamsWithBean(AddServiceInfo serviceInfo) {
		String requestParamsBeanUtil;
		requestParamsList=serviceInfo.getSelectedXpathsList().toArray();
		for (int i = 0; i < requestParamsList.length; i++) {
			requestParamsBeanUtil = this.requestParamsBeanUtil;
			requestParamsBeanUtil = StringUtils.replace(requestParamsBeanUtil, "$reqParam", "req"+i);
			requestParamsBeanUtil = StringUtils.replace(requestParamsBeanUtil, "$requestXPathMap", (String) requestParamsList[i]);
			requestParamsBean += requestParamsBeanUtil + "\n";
			exactFileName += "req" + i + "+";
			fileNameMap.add(requestParamsBeanUtil);
		}
		exactFileName = exactFileName.substring(0, exactFileName.length()-1);
	}
	
	private void mapRequestParamsWithBean(AddJMSServiceInfo serviceInfo) {
		String requestParamsBeanUtil;
		requestParamsList=serviceInfo.getSelectedXpathsList().toArray();
		for (int i = 0; i < requestParamsList.length; i++) {
			requestParamsBeanUtil = this.requestParamsBeanUtil;
			requestParamsBeanUtil = StringUtils.replace(requestParamsBeanUtil, "$reqParam", "req"+i);
			requestParamsBeanUtil = StringUtils.replace(requestParamsBeanUtil, "$requestXPathMap", (String) requestParamsList[i]);
			requestParamsBean += requestParamsBeanUtil + "\n";
			exactFileName += "req" + i + "+";
			fileNameMap.add(requestParamsBeanUtil);
		}
		exactFileName = exactFileName.substring(0, exactFileName.length()-1);
	}
	
	private boolean writeToFile(String packagePath, String fileName,String content){
		boolean done =  false;
		try {
			
			logger.info("Cntent of the simualtor context : "+content);
			File filDirectory =  new File(packagePath);
			filDirectory.mkdirs();
			
			
			
			logger.info("file path to be written : "+packagePath);
			File fil =  new File(packagePath+"/"+fileName);
			
			
			
			if(!fil.exists())
				fil.createNewFile();
			
			FileWriter fw  = new FileWriter(fil);
		
			fw.write(content);
			fw.close();
			done =  true;
		} catch (IOException e) {
			logger.info("Failed to write into file, FIle path is  : "+packagePath);
			e.printStackTrace();
		}
		return done;
	}
	
	public boolean updateApplicationContext(String contextPath,String serviceName)
	{
		File f=new File(contextPath);
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		String value="/simulators/"+serviceName + "-simulator-context.xml";
		try {
			DocumentBuilder db=dbf.newDocumentBuilder();
			Document dom=db.parse(f);
		  
			Element newNode=dom.createElement("import");
		    newNode.setAttribute("resource", value);
		    String abc=newNode.getAttribute("resource");
		    System.out.println(abc);
		    NodeList nodeList=dom.getElementsByTagName("beans");
		    System.out.println(nodeList.item(0).getNodeName());
		    nodeList.item(0).appendChild(newNode);
		    Transformer transformer = TransformerFactory.newInstance().newTransformer();
		    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		    transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "-//SPRING//DTD BEAN//EN");
		    transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://www.springframework.org/dtd/spring-beans.dtd");
		    StreamResult result = new StreamResult(new StringWriter());
		    DOMSource source = new DOMSource(dom);
		    transformer.transform(source, result);

		    String xmlString = result.getWriter().toString();
		    
		    String filePath = contextPath.substring(0, contextPath.length()-23);
		    writeToFile(filePath, "application-context.xml", xmlString);
		   
		   

		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		
		System.out.println("updated");
		return true;
	}

public String checkAvailability(String serviceName) {
	
	String present="false";
	System.out.println(present);
	
	if((BeanApplicationContext.getApplicationContext().getBean(serviceName))!=null)
	{
		present="true";
	}
	System.out.println(present);
	return present;
}	

public String getContextPath()
{
	java.net.URL location = Test.class.getProtectionDomain().getCodeSource().getLocation();
    
	   String path=location.getPath();
	   String contextPath=path.substring(0, path.lastIndexOf("lib"));
	   contextPath=contextPath+"config/it/application-context.xml";
	   System.out.println("final path : "+contextPath);
	   String path1=contextPath.substring(contextPath.indexOf(".metadata"), contextPath.indexOf("wtpwebapps"));
	   contextPath=contextPath.replace(path1,"/");
	   contextPath=contextPath.replace("//","/");
	   contextPath=contextPath.replace("/wtpwebapps/","/");
	   contextPath=contextPath.replace("/WEB-INF/","/WebContent/");
	   contextPath=contextPath.replaceFirst("/", "");
	   System.out.println("final path in creating new service : "+contextPath);
	   return contextPath;
}


public String getServiceComplexity(String appId,String system){
	String complexity=null;
	/*First check operation count if > 3 Complex
	=3 Medium
	< 3 
	Check fields
	if < 100 Simple
	> 100 < 150 Medium
	> 150 Complex*/
	
	String root = SimulatorContextBeanPropertUtil.getResponseFilePath()+appId;
	AddKeyValueUtil util = new AddKeyValueUtil();
	String[] subSystems = util.getSubSystems(system, root);
	int num = getLength(subSystems);
	if(num > 3)
			complexity = "COMPLEX";
		else if(num <= 3)
		complexity = "MEDIUM";
	
	else if(num ==1)
	{
		int numberOfTags = countNumberOfTags(appId,system,subSystems[0]);
		if(numberOfTags > 150)
			complexity = "COMPLEX";
		else if(numberOfTags <150 && numberOfTags >100) complexity = "MEDIUM";
		else complexity = "SIMPLE";
	}
	else if(num == 2)
	{
		int n1 = countNumberOfTags(appId,system,subSystems[0]);
		int n2 = countNumberOfTags(appId,system,subSystems[0]);
		int numberOfTags = (n1+n2)/2;
		if(numberOfTags > 150)
			complexity = "COMPLEX";
		else if(numberOfTags <150 && numberOfTags >100) complexity = "MEDIUM";
		else complexity = "SIMPLE";
	}
		
	
	
		
	
	
	
	return complexity;
}

public int countNumberOfTags(String appId,String system,String subSystem)
{
	int number=0;
	String path = SimulatorContextBeanPropertUtil.getResponseFilePath()+appId+"//"+system+"//"+subSystem+"//default.vm";
	File f = new File(path);
	DocumentBuilderFactory dbf=null;
	if(f.exists())
	dbf=DocumentBuilderFactory.newInstance();
	else return 0;
	
	DocumentBuilder db;
	try {
		db = dbf.newDocumentBuilder();
		Document dom=db.parse(f);
		NodeList list = dom.getElementsByTagName("*");

		number =list.getLength(); //dom.getChildNodes().getLength();
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SAXException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
  
	System.out.println(number);
	
	return number ;
}

public int getLength(String[] a)
{
	int number= 0;
	for(String s:a)
	{
		if(s!=null)
			number++;
	}
	return number;
}

public void configureCaptureUtil(String beanId,String adapterName)
{
	
	RxContextPathDeploymentUtil contextDeploymentUtil = new RxContextPathDeploymentUtil();
	String path = contextDeploymentUtil.getConfigItPath().replace("it",
			"captureConfig.properties");
	
	Properties prop = new Properties();
	try {
		FileInputStream f = new FileInputStream(path);
		prop.load(f);
		prop.setProperty(adapterName, beanId);
		 	File o = new File(path);
	        OutputStream out = new FileOutputStream( o );
	        prop.store(out,null);
	} catch (Exception e) {

	}
	
	
	
	
}

public void setServletRequest(HttpServletRequest arg0) {
	// TODO Auto-generated method stub
	this.request = arg0;
	
}



}
	

    

