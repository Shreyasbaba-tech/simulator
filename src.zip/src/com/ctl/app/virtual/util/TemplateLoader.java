package com.ctl.app.virtual.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

public class TemplateLoader {
	
	/**
	 * Method to load the template file
	 * @param templateFile Template file
	 * @return Template contents
	 */
	public static String loadTemplate(File templateFile){
		String templateContent= "null";
		try {
			Scanner scanner = new Scanner(templateFile);
			scanner.useDelimiter("\\\\Z");
			templateContent = scanner.next();
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return templateContent;
	}
	
	
	/**
	 * Method to apply patterns on templates
	 * @param input String to which the pattern is to be applied
	 * @param patterns Patterns to be applied
	 * @return Applied Pattern applied string
	 */
	public static String applyPattern(String input,Map<String, String> patterns){
		String output = input;
		Set<String> keys = patterns.keySet();
		Iterator<String> keysIterator = keys.iterator();
		while (keysIterator.hasNext()) {
			String key = keysIterator.next();
			String value = patterns.get(key);
			output = StringUtils.replace(output, key, value);
		}
		return output;
	}
}