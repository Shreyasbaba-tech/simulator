package com.ctl.app.virtual.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ValidationUtil {
	
	private String requestXML;
	private String actionXPath;
	private String requestParams;
	
	public ValidationUtil() {
		
	}
	
	public String getRequestXML() {
		return requestXML;
	}
	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}
	public String getActionXPath() {
		return actionXPath;
	}
	public void setActionXPath(String actionXPath) {
		this.actionXPath = actionXPath;
	}
	public String getRequestParams() {
		return requestParams;
	}
	public void setRequestParams(String requestParams) {
		this.requestParams = requestParams;
	}
	
	
	public boolean validateXMLXPath(String requestXML,String actionXPath){
		
	
		
		if(requestXML.length()==actionXPath.length()){
			return true;
		}
		else {
			return false;
		}
			
		
		
	}
	
	

}
