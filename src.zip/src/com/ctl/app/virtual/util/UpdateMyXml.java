package com.ctl.app.virtual.util;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
 
public class UpdateMyXml {
 
	public void updateXml(String key,String xpath,String elementValue,String xmlFilePath,String xmlFile,String fileName) {
		XPath xPath = XPathFactory.newInstance().newXPath();
//        String filepath="C:/Xmls/ECSR.xml";
		
		String xPathExpression = modifyXPath(xpath);
		NodeList nodes=null;;
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(new File(xmlFile));
			
			System.out.println("xPathExpression :: "+xPathExpression);
			nodes =  (NodeList) xPath.compile(xPathExpression).evaluate(doc, XPathConstants.NODESET);
			System.out.println("NodeList size :: "+nodes.getLength());
			for (int i = 0; i < nodes.getLength(); i++)
			{
			    System.out.println(nodes.item(i).getTextContent());  // Prints original value
			    nodes.item(i).setTextContent(elementValue);
			    System.out.println(nodes.item(i).getTextContent());  // Prints 111 after
			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(xmlFilePath+fileName+"_"+key+"_"+elementValue+".vm"));
			transformer.transform(source, result);
	 		System.out.println("Done");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private String modifyXPath(String xpath){
		String strArr[] = xpath.split("/");
		System.out.println(strArr.length);
		String newPath = "";
		
		for (int i = 0; i < strArr.length; i++) {
			if(strArr[i].indexOf(":")!=-1){
				strArr[i] = "*[local-name()='"+strArr[i].substring(strArr[i].indexOf(":")+1,strArr[i].length())+"']";
			}
			newPath = newPath+"/"+strArr[i];
		}
		System.out.println(newPath);
		return newPath+"/text()";
	}
}