package com.ctl.app.virtual.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.util.Enumeration;
import java.util.Properties;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.ctl.simulation.resiliency.ResiliencyParameterManager;

public class AddKeyValueUtil {
	private static Log logger =LogFactory.getLog("SimulationLogger");
	public String[] getAppIds(String root)
	{
		String[] apps=new String[100];
		apps=getOptions(root);
		
		int count=0;
		for(int i=0;i<apps.length;i++)
		{
			if(apps[i]!=null)
				count++;
		}
		String[] returnedApps=new String[count];
		for(int j=0;j<count;j++)
		{
			returnedApps[j]=apps[j];
		}
		return returnedApps;
		
	}
	public String[] getSystems(String appId,String root)
	{
		 String[] systems=new String[100];
		 
		 root+="/"+appId;
		 systems=getOptions(root);
		 int count=0;
			for(int i=0;i<systems.length;i++)
			{
				if(systems[i]!=null)
					count++;
			}
			String[] returnedSystems=new String[count];
			for(int j=0;j<count;j++)
			{
				returnedSystems[j]=systems[j];
			}
			return returnedSystems;
		
	}
	
	public String[] getSubSystems(String system,String root)
	{
		 String[] subSystems=new String[100];
		 logger.info("Root recived to get subsystems :"+root);
		 root+="/"+system;
		 logger.info("FInal path constructed to get subsystems :"+root);
		 subSystems=getOptions(root);
		 int count=0;
			for(int i=0;i<subSystems.length;i++)
			{
				if(subSystems[i]!=null)
					count++;
			}
			String[] returnedSystems=new String[count];
			for(int j=0;j<count;j++)
			{
				returnedSystems[j]=subSystems[j];
			}
			return returnedSystems;
		
	}
	public String[] getControlFiles(String subSystem,String path)
	{
		String[] controlFiles=new String[100];
		
		path+="/"+subSystem;	
		
		File f=new File(path);
		File[] list=f.listFiles();
		int i=0;
		for(File temp:list)
		{
			String extension=temp.getName().substring(temp.getName().lastIndexOf('.'));
			if(temp.isFile()&&extension!="ctrl")
			{
				
				controlFiles[i++]=temp.getName();
				
			}
			
		}
		
		return controlFiles;
	}
	
	public String[] getResponseFiles(String subSystem,String path)
	{
		
		path+="/"+subSystem;	
		
		File f=new File(path);
		File[] list=f.listFiles();
		String[] responseFiles=new String[list.length];
		int i=0;
		for(File temp:list)
		{
			String extension=temp.getName().substring(temp.getName().lastIndexOf('.'));
			//System.out.println(extension);
			if(temp.isFile()&&extension.equals(".vm"))
			{
				
				responseFiles[i++]=temp.getName();
				
			}
			
		}
		
		return responseFiles;
	}
	public String tokenise(String[] controlFiles)
	{
		String tokens=new String();
		for(int i=0;i<controlFiles.length;i++)
		{
			if(controlFiles[i]!=null){
			
			tokens=tokens.concat(controlFiles[i]);
			tokens=tokens.concat(",");
			}
					
		}
		
		return tokens;
	}
	public String[] getOptions(String root)
	{
		String[] options=new String[100];
		File f=new File(root);
		File[] list=f.listFiles();
		int i=0;
		if(list!=null){
			for(File temp:list)
			{
				if(temp.isDirectory())
				{
					logger.info("Subsystem found is  :"+temp.getName()+ "Index: "+i);
					options[i++]=temp.getName();
					
				}
				
			}
			
		}
		
		return options;
	}

	public String displayControlFileContent(String path) throws IOException
	{
	/*	//System.out.println(path);
		File f=new File(path);
		
		if(f.exists()==false)
		{
			f.createNewFile();
		}
		 StringBuffer fileData = new StringBuffer();
	        BufferedReader reader = new BufferedReader(
	                new FileReader(path));
	        char[] buf = new char[1024];
	        int numRead=0;
	        while((numRead=reader.read(buf)) != -1){
	            String readData = String.valueOf(buf, 0, numRead);
	            fileData.append(readData);
	        }
	        reader.close();
	      //  System.out.println("in util function "+fileData.toString());
	        return fileData.toString();*/
		
		
		String fileContents="";
		File f=new File(path);
		ResiliencyParameterManager man=new ResiliencyParameterManager();
		Properties pro=man.getResiliencyParameter(path);
		 Enumeration e = pro.propertyNames();
		while(e.hasMoreElements())
		{
			String key = (String) e.nextElement();
			fileContents=fileContents+key+"="+pro.getProperty(key)+"##";
		      //System.out.println(key + " -- " + pro.getProperty(key));
		    
		}

		return fileContents;
	}

	public String addToDummy(String controlFilePath,String curContents,String key,String value)
	{
		File origControlFile=new File(controlFilePath);
		File dummyFile=new File(controlFilePath.replace(".ctrl", "Dummy.ctrl"));
		String dummyContents=null;
		//code to write the cur contents to dummyfile
		BufferedWriter out;
		try {
			out = new BufferedWriter(new FileWriter(dummyFile));
			out.write(curContents);
			 out.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	
		String addedString=" ## "+key+"="+value  ;
		//code to add the new string to dummyFile
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(dummyFile,true));
		    bw.write(addedString);
			bw.newLine();
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    //code to return back the contents of the dummy file
		try {
			dummyContents=FileUtils.readFileToString(dummyFile);
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//dummyContents=dummyContents.replace("\n", " ## ");
		System.out.println("Dummy Contents= "+dummyContents);
		return dummyContents;
	}
	
	public String editDummy(String controlFilePath,String curContents,String key,String value)
	{
		String dummyContents=null;
		File dummyFile=new File(controlFilePath.replace(".ctrl", "Dummy.ctrl"));
		File dummyTempFile=new File(controlFilePath.replace(".ctrl", "DummyTemp.ctrl"));
		//code to write the cur contents to dummyfile
				BufferedWriter out;
				try {
					out = new BufferedWriter(new FileWriter(dummyFile));
					out.write(curContents);
					 out.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				//insertNewlineChars(controlFilePath.replace(".ctrl", "Dummy.ctrl"));	
				
				//empty the temp file
				try {
					new RandomAccessFile(dummyTempFile,"rw").setLength(0);
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		
				

				//code to remove the line 
				try {
					BufferedReader reader=new BufferedReader(new FileReader(dummyFile));
					BufferedWriter writer=new BufferedWriter(new FileWriter(dummyTempFile,true));
					
					String keyToRemove=key; //String keyToRemove = key;
					
					String con=FileUtils.readFileToString(dummyFile);
					String[] cons=con.split("##");
					String conNew="";
					int j=0;
					for(int i=0;i<cons.length;i++)
					{
						if(!cons[i].contains(key))
						{
							conNew=conNew+cons[i];
				             conNew+=" ## ";
							
							//writer.write("##");
							
						}
					}
					writer.write(conNew);
		
					
					/*String currentLine;
		        while((currentLine=reader.readLine())!= null) 
		        {
		        	System.out.println(currentLine+" Read");
		        	 String trimmedLine = currentLine.trim();
		        	 System.out.println("tl= "+trimmedLine);
		        	    if(trimmedLine.contains(keyToRemove)) { System.out.println(trimmedLine+ " to be deleted");continue;}
		        	   System.out.println("after check : "+currentLine);
		        	  
		        	   
		        	    writer.write(currentLine);
		        	   
		        	    writer.newLine();
		        	    
		        	    System.out.println(currentLine+" written into file");

		        	       	
		        }*/
		        
		        reader.close();
		        writer.close();
				
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				
				//empty the input file
				try {
					new RandomAccessFile(dummyFile,"rw").setLength(0);
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				copyFileContents(dummyTempFile, dummyFile);
				boolean del=dummyTempFile.delete();
				
				
				//adding new key value to edited file
				
				String editedString=key+"="+value;
	          BufferedWriter bw;
			try {
				bw = new BufferedWriter(new FileWriter(dummyFile,true));
				bw.write(editedString);
				//bw.newLine();
				bw.close();
		
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			
			 //code to return back the contents of the dummy file
			try {
				dummyContents=FileUtils.readFileToString(dummyFile);
				} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//	dummyContents=dummyContents.replace("\n", " ## ");
			System.out.println("Dummy Contents= "+dummyContents);
			
				
		return dummyContents;
	}
	
	public boolean copyFileContents(File source,File destination)
	{
		 FileChannel src;
		try {
			src = new FileInputStream(source).getChannel();
			FileChannel dest = new FileOutputStream(destination).getChannel();
			dest.transferFrom(src, 0, src.size());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 	
		return true;
	}
	
	public void insertNewlineChars(String filePath)
	{
		//System.out.println("in edit mode");
		File dummyFile=new File(filePath);
		StringBuffer fileData = new StringBuffer(1000);

		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(dummyFile));
			char[] buf = new char[1024];

			int numRead=0;

			while((numRead=reader.read(buf)) != -1){

			String readData = String.valueOf(buf, 0, numRead);

			fileData.append(readData);

			buf = new char[1024];
		
			
					
		} 
			reader.close();
			String fileDataString=fileData.toString();
			fileDataString=fileDataString.replace("//", "\n");
			System.out.println("File data string= "+fileDataString);
			
			BufferedWriter out = new BufferedWriter(new FileWriter(filePath));
			 out.write(fileDataString);
			 out.close();
			
		}
			catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	
	public String readFileAsString(String filePath)

	throws java.io.IOException{

	StringBuffer fileData = new StringBuffer(1000);

	BufferedReader reader = new BufferedReader(

	new FileReader(filePath));

	char[] buf = new char[1024];

	int numRead=0;

	while((numRead=reader.read(buf)) != -1){

	String readData = String.valueOf(buf, 0, numRead);

	fileData.append(readData);

	buf = new char[1024];

	}

	reader.close();

	return fileData.toString();

	}
	
}
