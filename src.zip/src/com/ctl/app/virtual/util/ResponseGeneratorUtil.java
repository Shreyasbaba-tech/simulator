package com.ctl.app.virtual.util;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
public class ResponseGeneratorUtil {
	
	public void generateResponseXmls(String inputString,String separator,String format,String xmlFilePath,String elementToBeReplaced)
	{
		try {
			// Input String, Seperator & format
			List<String> listOfStringToBeReplaced=null;
			 //inputString="08/27/2013-09/15/2013";
			 separator = "-";
			boolean isNumber = false;
			// format = "MM/dd/yyyy";
			// elementToBeReplaced="password";
			
			//File stocks = new File("C:\\sgolla\\xml_template\\300070000_request.xml");
			 File stocks = new File(xmlFilePath);
			if(isNumber){
				listOfStringToBeReplaced = getNumberList(inputString, separator);
			}else if(!StringUtils.isBlank(format)){
				listOfStringToBeReplaced = getDateList(inputString, separator, format);
			}else {
				listOfStringToBeReplaced = getStringList(inputString, separator);
			}
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			TransformerFactory transformerFactory = TransformerFactory.newInstance();         
			Transformer transformer = transformerFactory.newTransformer();   
			Document doc = dBuilder.parse(stocks);
			doc.getDocumentElement().normalize();

			System.out.println("root of xml file" + doc.getDocumentElement().getNodeName());
			for (String string : listOfStringToBeReplaced) {
				doc.getElementsByTagName(elementToBeReplaced).item(0).setTextContent(string);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");     
				DOMSource source = new DOMSource(doc);             //write to console or file   
				String stringAfterUpdate = StringUtils.replace(string, "/", "");
				File fil =  new File("C://sgolla//xml_template//300070000_request"+stringAfterUpdate+".xml").getCanonicalFile();
				if(!fil.exists()){
					fil.createNewFile();
				}
				StreamResult file = new StreamResult(fil);     
				StreamResult console = new StreamResult(System.out);
				//write data    
				transformer.transform(source, console);          
				transformer.transform(source, file);
			}
			
			System.out.println("==========================");

		}catch (Exception ex) {
			ex.printStackTrace();
		}
	
	}
	
	private  List<String> getStringList(String string, String separator){
		List<String> strList = new ArrayList<String>();
		String[] strArray =StringUtils.split(string, separator);
		for (String string2 : strArray) {
			strList.add(string2);
		}
		return strList;
		
	}
	
	private  List<String> getNumberList(String string, String separator){
		List<String> strList = new ArrayList<String>();
		String[] strArray =StringUtils.split(string, separator);
		if(strArray.length==2){
			int firstNumber = Integer.decode(strArray[0]).intValue();
			int secondNumber = Integer.decode(strArray[1]).intValue();
			int difference = secondNumber - firstNumber;
			int differenceAbs=Math.abs(difference);
			strList.add(Integer.valueOf(firstNumber).toString() );
			for (int i=1;i<=differenceAbs;i++) {
				strList.add(Integer.valueOf(firstNumber+i).toString() );
			}
		}
		return strList;
			
	}

	private  List<String> getDateList(String string, String separator, String format){
		List<String> strList = new ArrayList<String>();
		String[] strArray =StringUtils.split(string, separator);
		try {
			if (strArray.length == 2) {
				String firstDate = strArray[0]; // Start date
				String endDate = strArray[1];
				SimpleDateFormat sdf = new SimpleDateFormat(format);
				Calendar calFirst = Calendar.getInstance();
				calFirst.setTime(sdf.parse(firstDate));
				Calendar calSecond = Calendar.getInstance();
				calSecond.setTime(sdf.parse(endDate));
				
				strList.add(sdf.format(calFirst.getTime()));
				calFirst.add(Calendar.DATE,1 );
				while(calFirst.before(calSecond)){
					strList.add(sdf.format(calFirst.getTime()));	
					calFirst.add(Calendar.DATE,1 );
				}

			}
		} catch (Exception e) {
		}
		
		return strList;
	}
	
	

}
