/**
 * 
 */
package com.ctl.app.virtual.util;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ctl.simulation.http.RxContextPathDeploymentUtil;

/**
 * @author aa49473(Sahil Sharma)
 *
 */
public class URLUtil {
 public static void main(String args[])
 {
	 
	 String url = "http://yosemite.interprise.com/cgi-bin/QC/DSL/adtranActuals.pl?"+
"telephoneNum=2083220022"+
"&ip=172.30.207.66"+
"&shelf=1"+
"&slot=1&port=7"+
"&isTA5000=0"+
"&isTA3000=0"+
"&vcString=4344"+
"&LC=Q"+
"&tDR=172.30.207.66"+
"&isIPTV=0"+
"&orderedSpeed=896%K2F7168K"+
"&XML=1";
File f = convertURLtoXml(url);
	 
 }
	
public static File convertURLtoXml(String url)	
{
	RxContextPathDeploymentUtil util = new RxContextPathDeploymentUtil();
	String path=util.getConfigItPath().replace("it", "VirtualConfig.properties");
	Properties pro = new Properties();
	try {
	    FileInputStream f = new FileInputStream(path);
	    pro.load(f);
	} catch (Exception e) {
	    
	}
	
	String path1 = pro.getProperty("ResponeFilePath");
	
	File tempXmlFile = new File(path1+"tempFile.xml");	
	
	String operationString = url.split("\\?")[0];
	
	String operName = /*"HTTPRequest";*/ operationString.substring(operationString.lastIndexOf('/')+1, operationString.length());
	
	String reqParamsString = url.split("\\?")[1];
	
	String[] reqParamsArray = reqParamsString.split("&");
	
	System.out.println(operationString+"::::"+reqParamsString);
	
	DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder docBuilder;
	
	try {
		docBuilder = docFactory.newDocumentBuilder();
		// root elements
		Document doc = docBuilder.newDocument();
		Element rootElement = doc.createElement(operName);
		doc.appendChild(rootElement);

		
		for (int i = 0; i < reqParamsArray.length; i++) {
			// elements
			if(reqParamsArray[i]!=null)
			{
				String[] arr = reqParamsArray[i].split("=");
				
				String nodeName = arr[0];
				String nodeValue = arr[1];
				
				if(nodeName!=null && nodeValue!=null)
				{
			Element node = doc.createElement(nodeName);
			node.appendChild(doc.createTextNode(nodeValue));
			rootElement.appendChild(node);
				}
			}
			
		}
		
		

		
		// write the content into xml file
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
	
		StreamResult result = new StreamResult(tempXmlFile);

		transformer.transform(source, result);

		System.out.println("File saved!");
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (TransformerConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (TransformerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}



	
	return tempXmlFile;
}
	
	
}
