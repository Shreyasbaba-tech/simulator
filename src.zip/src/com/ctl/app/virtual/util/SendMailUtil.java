package com.ctl.app.virtual.util;

import java.io.FileInputStream;
import java.util.Properties;

import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.opensymphony.xwork2.util.finder.Test;

public class SendMailUtil {

	

	public String sendMail(String msg)
	{
		
		RxContextPathDeploymentUtil ut = new RxContextPathDeploymentUtil();
		String contextPath =ut.getConfigItPath()+"email.properties"; 
		Properties pro = new Properties();
		try {
			FileInputStream f = new FileInputStream(contextPath);
			pro.load(f);
		} catch (Exception e) {
		
		}
		
		
		pro.getProperty("RECIPIENTS");
		
		
		String[] recipients =pro.getProperty("RECIPIENTS").split("\\|\\|");  // {"anup.dakua@centurylink.com"};
		EmailUtils.postMail(recipients, "Virtual App", msg, "AppVirtualizationTeam@centurylink.com");
		
		
		return "SENT";
	}
}
