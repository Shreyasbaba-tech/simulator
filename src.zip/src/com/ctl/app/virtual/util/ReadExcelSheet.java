package com.ctl.app.virtual.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ReadExcelSheet {
    
	  private String inputFile;
	  private String xmlFilePath;
	  private String xmlFile;
	  private String fileName;
	  private int columnCount;

	  
	public void setXmlFile(String xmlFile) {
		this.xmlFile = xmlFile;
	}


	public void setXmlFilePath(String xmlFilePath) {
		this.xmlFilePath = xmlFilePath;
	}


	public void setInputFile(String inputFile) {
	    this.inputFile = inputFile;
	  }

	  
	  public void read() throws IOException  {
	    File inputWorkbook = new File(inputFile);
	    Workbook w;
	    
	    try {
	      w = Workbook.getWorkbook(inputWorkbook);
	      // Get the first sheet
	      Sheet sheet = w.getSheet(0);
	      // Loop over first 10 column and lines

	      for (int i = 1; i < sheet.getRows(); i++) {
	    	  List<String> record = new ArrayList<String>();
	      for (int j = 0; j < sheet.getColumns(); j++) {
	       
	          Cell cell = sheet.getCell(j, i);
	          CellType type = cell.getType();
	          if (type == CellType.LABEL) {
	        	  {//if(cell.getContents()!="Xpath"){
	            record.add(cell.getContents());
	            System.out.println(cell.getContents());
	            
	        	  /*}*/}
	        	  
	          }

	          if (type == CellType.NUMBER) {
	        	  record.add(cell.getContents());
	        	  System.out.println(cell.getContents());
	        	  /*if(cell.getContents()!="Value"){
	        	  }*/
	          }
	          

	        }
	      
	    UpdateMyXml mk = new UpdateMyXml();
	    mk.updateXml(record.get(0),record.get(1),record.get(2),xmlFilePath,xmlFile,fileName);
	     record.clear();
	      }
	    } catch (BiffException e) {
	      e.printStackTrace();
	    }
	  }
	  
	 	  

	public static void main(String[] args) {
		 ReadExcelSheet test = new ReadExcelSheet();
		    test.setInputFile("C:\\Xmls\\Note1.xls");
		    test.setXmlFile("C:\\Xmls\\ECSR.xml");
		    test.setFileName("ECSR.xml");
		    test.setXmlFilePath("C:\\Xmls\\");
		    try {
				test.read();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
