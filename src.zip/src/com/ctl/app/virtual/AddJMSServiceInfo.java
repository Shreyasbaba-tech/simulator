/**
 * 
 */
package com.ctl.app.virtual;

import java.io.File;
import java.util.List;

/**
 * @author aa47173
 *
 */
public class AddJMSServiceInfo {
	
	private String queueSize; 
	private String deliveryMode; 
	private String queueName; 
	private String applID; 
	private String servName; 
	private String serviceType; 
	private File fileField;
	private List<String> selectedXpathsList;
	
	
	public String getQueueSize() {
		return queueSize;
	}
	public void setQueueSize(String queueSize) {
		this.queueSize = queueSize;
	}
	public String getDeliveryMode() {
		return deliveryMode;
	}
	public void setDeliveryMode(String deliveryMode) {
		this.deliveryMode = deliveryMode;
	}
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getApplID() {
		return applID;
	}
	public void setApplID(String applID) {
		this.applID = applID;
	}
	public String getServName() {
		return servName;
	}
	public void setServName(String servName) {
		this.servName = servName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public File getFileField() {
		return fileField;
	}
	public void setFileField(File fileField) {
		this.fileField = fileField;
	}
	public List<String> getSelectedXpathsList() {
		return selectedXpathsList;
	}
	public void setSelectedXpathsList(List<String> selectedXpathsList) {
		this.selectedXpathsList = selectedXpathsList;
	}
}
