package com.ctl.app.virtual;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddServiceInfo {
	
	private String serviceName;
	private String applicationId;
	private File file =null;
	private File sampleResponseFile=null;
	private String selectedXpaths;
	private List<String> selectedXpathsList;
	private String serviceType;
	private List<String> generatedXpathMapKey;
	private String serviceLocation;
	private String serviceURI;
	private Map<String,String> generatedXpathMap;
	private String operationName;
	private File sampleReponse;
	private String sampleResponseFileFileName;
	private String fileContentType;
	private String fileFileName;
	private String sampleResponseFileContentType;
	private List<String> restXpathMapKey;
	private Map<String,String> restXpathMap;
	private String actionXpathValue;
	private String contentType;
	//soumya
	private String UserName;
	
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	//soumya
	
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}
	public File getSampleReponse() {
		return sampleReponse;
	}
	public void setSampleReponse(File sampleReponse) {
		this.sampleReponse = sampleReponse;
	}
	
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public List<String> getGeneratedXpathMapKey() {
		return generatedXpathMapKey;
	}
	public void setGeneratedXpathMapKey(List<String> generatedXpathMapKey) {
		this.generatedXpathMapKey = generatedXpathMapKey;
	}
	public File getSampleResponseFile() {
		return sampleResponseFile;
	}
	public void setSampleResponseFile(File sampleResponseFile) {
		this.sampleResponseFile = sampleResponseFile;
	}
	public String getServiceLocation() {
		return serviceLocation;
	}
	public void setServiceLocation(String serviceLocation) {
		this.serviceLocation = serviceLocation;
	}
	public String getServiceURI() {
		return serviceURI;
	}
	public void setServiceURI(String serviceURI) {
		this.serviceURI = serviceURI;
	}
	public String getSelectedXpaths() {
		return selectedXpaths;
	}
	public void setSelectedXpaths(String selectedXpaths) {
		this.selectedXpaths = selectedXpaths;
	}
	public List<String> getSelectedXpathsList() {
		return selectedXpathsList;
	}
	public void setSelectedXpathsList(List<String> selectedXpathsList) {
		this.selectedXpathsList = selectedXpathsList;
	}

	public Map<String, String> getGeneratedXpathMap() {
		return generatedXpathMap;
	}

	public void setGeneratedXpathMap(Map<String, String> generatedXpathMap) {
		this.generatedXpathMap = generatedXpathMap;
	}
	public String getOperName() {
		return operationName;
	}
	public void setOperName(String operationName) {
		this.operationName = operationName;
	}
	public String getSampleResponseFileFileName() {
		return sampleResponseFileFileName;
	}
	public void setSampleResponseFileFileName(String sampleResponseFileFileName) {
		this.sampleResponseFileFileName = sampleResponseFileFileName;
	}
	public String getFileContentType() {
		return fileContentType;
	}
	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}
	public String getFileFileName() {
		return fileFileName;
	}
	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}
	public String getSampleResponseFileContentType() {
		return sampleResponseFileContentType;
	}
	public void setSampleResponseFileContentType(
			String sampleResponseFileContentType) {
		this.sampleResponseFileContentType = sampleResponseFileContentType;
	}
	public List<String> getRestXpathMapKey() {
		if(restXpathMapKey!=null)
			return restXpathMapKey;
		else
			return new ArrayList<String>();
	}
	public void setRestXpathMapKey(List<String> restXpathMapKey) {
		if(restXpathMapKey!=null)
			this.restXpathMapKey = restXpathMapKey;
		else
			this.restXpathMapKey = new ArrayList<String>();
	}
	public Map<String, String> getRestXpathMap() {
		if(restXpathMap!=null)
			return restXpathMap;
		else
			return new HashMap<String, String>();
	}
	public void setRestXpathMap(Map<String, String> restXpathMap) {
		if(restXpathMap!=null)
			this.restXpathMap = restXpathMap;
		else
			this.restXpathMap = new HashMap<String, String>();
	}
	public String getActionXpathValue() {
		return actionXpathValue;
	}
	public void setActionXpathValue(String actionXpathValue) {
		this.actionXpathValue = actionXpathValue;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	

}
