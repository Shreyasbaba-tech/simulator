/**
 * 
 */
package com.ctl.app.virtual.constant;

/**
 * @author aa47173
 *
 */
public class CommonConstant {
	
	public static final String IS_NUMBER = "IS_NUMBER";
	public static final String IS_STRING = "IS_STRING";
	public static final String IS_DATE = "IS_DATE";
	public static final String NON_PERSISTENT = "NON_PERSISTENT";
	public static final String PERSISTENT = "PERSISTENT";

}
