/**
 * 
 */
package com.ctl.app.virtual;

import java.io.File;

/**
 * @author aa47173
 *
 */
public class LoadJMSFileInfo {
	
	private boolean isSelected;
	private File respFile;
	
	public boolean isSelected() {
		return isSelected;
	}
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}
	public File getRespFile() {
		return respFile;
	}
	public void setRespFile(File respFile) {
		this.respFile = respFile;
	}

}
