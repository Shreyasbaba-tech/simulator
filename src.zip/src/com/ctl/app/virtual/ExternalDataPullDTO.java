package com.ctl.app.virtual;

public class ExternalDataPullDTO {

	private String dataSource;
	private String xmlData;
	private String requestXmlData;
	private String externalDataPullAi;
	private String queryName;
	private String requestTimeStamp;
	
	public String getRequestXmlData() {
		return requestXmlData;
	}
	public void setRequestXmlData(String requestXmlData) {
		this.requestXmlData = requestXmlData;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getXmlData() {
		return xmlData;
	}
	public void setXmlData(String xmlData) {
		this.xmlData = xmlData;
	}
	public String getExternalDataPullAi() {
		return externalDataPullAi;
	}
	public void setExternalDataPullAi(String externalDataPullAi) {
		this.externalDataPullAi = externalDataPullAi;
	}
	public String getQueryName() {
		return queryName;
	}
	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}
	public String getRequestTimeStamp() {
		return requestTimeStamp;
	}
	public void setRequestTimeStamp(String requestTimeStamp) {
		this.requestTimeStamp = requestTimeStamp;
	}
}
