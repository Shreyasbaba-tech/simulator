package com.ctl.app.virtual.hibernate.entity;

import java.sql.Clob;

public class AppVirtualResponseRepository {
private Long app_virtual_response_ai;
private Long app_virtual_user_ai;
private String system;
private String subsystem;
private String status;
private Clob response;
private String response_key;

public Long getApp_virtual_response_ai() {
	return app_virtual_response_ai;
}

public void setApp_virtual_response_ai(Long appVirtualResponseAi) {
	app_virtual_response_ai = appVirtualResponseAi;
}

public Long getApp_virtual_user_ai() {
	return app_virtual_user_ai;
}

public void setApp_virtual_user_ai(Long appVirtualUserAi) {
	app_virtual_user_ai = appVirtualUserAi;
}

public String getSystem() {
	return system;
}

public void setSystem(String system) {
	this.system = system;
}

public String getSubsystem() {
	return subsystem;
}

public void setSubsystem(String subsystem) {
	this.subsystem = subsystem;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public Clob getResponse() {
	return response;
}

public void setResponse(Clob response) {
	this.response = response;
}

public String getResponse_key() {
	return response_key;
}

public void setResponse_key(String responseKey) {
	response_key = responseKey;
}

public AppVirtualResponseRepository(){}

public AppVirtualResponseRepository(Long appVirtulaResponeAi,
		Long appVirtualUserAi, String system, String subsystem, String status,
		Clob response, String responseKey) {
	
	this.app_virtual_response_ai = appVirtulaResponeAi;
	this.app_virtual_user_ai = appVirtualUserAi;
	this.system = system;
	this.subsystem = subsystem;
	this.status = status;
	this.response = response;
	this.response_key = responseKey;
}

}
