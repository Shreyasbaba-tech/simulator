package com.ctl.app.virtual.hibernate.entity;

import java.io.Serializable;

public class AppVirtualUser implements Serializable{
private String app_id;
private Long app_virtual_user_ai;
public AppVirtualUser(){}
public AppVirtualUser(String appId, Long appVirtualUserAi) {
	
	this.app_id = appId;
	this.app_virtual_user_ai = appVirtualUserAi;
}
public String getApp_id() {
	return app_id;
}
public void setApp_id(String appId) {
	app_id = appId;
}
public Long getApp_virtual_user_ai() {
	return app_virtual_user_ai;
}
public void setApp_virtual_user_ai(Long appVirtualUserAi) {
	app_virtual_user_ai = appVirtualUserAi;
}

}
