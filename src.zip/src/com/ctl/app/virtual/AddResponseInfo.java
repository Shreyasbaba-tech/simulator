package com.ctl.app.virtual;

import java.io.File;

public class AddResponseInfo {
	
private String appId;	
private String system;
private String subSystem;
private File sampleXml=null;
private String searchTags;
private String desc;
private String key;


public String getSystem() {
	return system;
}
public void setSystem(String system) {
	this.system = system;
}
public String getSubSystem() {
	return subSystem;
}
public void setSubSystem(String subSystem) {
	this.subSystem = subSystem;
}

public String getSearchTags() {
	return searchTags;
}
public void setSearchTags(String searchTags) {
	this.searchTags = searchTags;
}
public String getDesc() {
	return desc;
}
public void setDesc(String desc) {
	this.desc = desc;
}
public String getKey() {
	return key;
}
public void setKey(String key) {
	this.key = key;
}
public File getSampleXml() {
	return sampleXml;
}
public void setSampleXml(File sampleXml) {
	this.sampleXml = sampleXml;
}
public String getAppId() {
	return appId;
}
public void setAppId(String appId) {
	this.appId = appId;
}









}