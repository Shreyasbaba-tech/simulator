/**
 * 
 */
package com.ctl.app.virtual;

import java.io.File;

/**
 * @author aa47173
 *
 */
public class AddServiceResponseInfo {
	
	private String responseType;
	private String asynchTime;
	private String serviceType;
	private String serviceLocation;
	private String serviceURI;
	private String ackRequired;
	private File ackFile;
	public String getResponseType() {
		return responseType;
	}
	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}
	public String getAsynchTime() {
		return asynchTime;
	}
	public void setAsynchTime(String asynchTime) {
		this.asynchTime = asynchTime;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getServiceLocation() {
		return serviceLocation;
	}
	public void setServiceLocation(String serviceLocation) {
		this.serviceLocation = serviceLocation;
	}
	public String getServiceURI() {
		return serviceURI;
	}
	public void setServiceURI(String serviceURI) {
		this.serviceURI = serviceURI;
	}	
	public String getAckRequired() {
		return ackRequired;
	}
	public void setAckRequired(String ackRequired) {
		this.ackRequired = ackRequired;
	}
	public File getAckFile() {
		return ackFile;
	}
	public void setAckFile(File ackFile) {
		this.ackFile = ackFile;
	}

}
