/**
 * 
 */
package com.ctl.app.virtual.dao;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ctl.app.virtual.ExternalDataPullDTO;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;


public class CaptureUtilDAO {

	private ResultSet resultSet;
	private ArrayList<ExternalDataPullDTO> responseFromEDP;
	private PreparedStatement preparedStatement;
	
	public List<ExternalDataPullDTO> fetchResponseFromEDP(String sessionCacheAI, String env)
			throws SQLException, ClassNotFoundException {
		try {
			responseFromEDP = new ArrayList<ExternalDataPullDTO>();
			if(env.equals("dev")){
				System.out.println("Environment : "+env);
				preparedStatement = ConnectionUtil
						.getDevConnection()
						.prepareStatement(
								"SELECT DATA_SOURCE,REQUEST_XML,RESPONSE_XML,EXTERNAL_DATA_PULL_AI FROM EXTERNAL_DATA_PULL WHERE SESSION_CACHE_AI = (SELECT SESSION_CACHE_AI FROM DOC_CUSTOMER_SESSION WHERE CUSTOMER_SESSION_AI = ?)");
			} else if(env.equals("wst")){
				System.out.println("CaptureUtilDAO : "+env);
				preparedStatement = ConnectionUtil
						.getWSTConnection()
						.prepareStatement(
								"SELECT DATA_SOURCE,REQUEST_XML,RESPONSE_XML,EXTERNAL_DATA_PULL_AI FROM EXTERNAL_DATA_PULL WHERE SESSION_CACHE_AI = (SELECT SESSION_CACHE_AI FROM DOC_CUSTOMER_SESSION WHERE CUSTOMER_SESSION_AI = ?)");
			}else if(env.equals("prod")){
				System.out.println("Environment : "+env);
				preparedStatement = ConnectionUtil
						.getProdConnection()
						.prepareStatement(
								"SELECT DATA_SOURCE,REQUEST_XML,RESPONSE_XML,EXTERNAL_DATA_PULL_AI FROM EXTERNAL_DATA_PULL WHERE SESSION_CACHE_AI = (SELECT SESSION_CACHE_AI FROM DOC_CUSTOMER_SESSION WHERE CUSTOMER_SESSION_AI = ?)");
			}
			
			preparedStatement.setString(1, sessionCacheAI);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				ExternalDataPullDTO edpDTO = new ExternalDataPullDTO();
				edpDTO.setExternalDataPullAi(resultSet.getString(4));
				edpDTO.setDataSource(resultSet.getString(1));
				edpDTO.setXmlData(convertClobtoString(resultSet.getClob(3)));
				edpDTO.setRequestXmlData(convertClobtoString(resultSet.getClob(2)));
				responseFromEDP.add(edpDTO);
			}

		} catch (SQLException e) {
			System.out.println("sql catch catch :"+e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement = null;
				resultSet = null;
				ConnectionUtil.closeConnection();
			} catch (SQLException e) {
				System.out.println("Finnally catch :"+e);
				e.printStackTrace();
			}
		}

		return responseFromEDP;
	}
	
	public List<ExternalDataPullDTO> fetchDetailsFromEDP(String sessionCacheAI, String env)
			throws SQLException, ClassNotFoundException {
		try {
			responseFromEDP = new ArrayList<ExternalDataPullDTO>();
			RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
	        String path=contextDeploymentUtil.getConfigItPath().replace("it", "captureConfig.properties");
	        Properties prop1 = new Properties();
			try {
				FileInputStream f = new FileInputStream(path);
				prop1.load(f);
			} catch (Exception e) {
				
			}
			if(env.equals("dev")){
				System.out.println("Environment : "+env);
				preparedStatement = ConnectionUtil
						.getDevConnection()
						.prepareStatement(
								"SELECT REQUEST_TIMESTAMP,QUERY_NAME,EXTERNAL_DATA_PULL_AI,DATA_SOURCE FROM EXTERNAL_DATA_PULL WHERE SESSION_CACHE_AI = (SELECT SESSION_CACHE_AI FROM DOC_CUSTOMER_SESSION WHERE CUSTOMER_SESSION_AI = ?) ORDER BY QUERY_NAME ASC");
			} else if(env.equals("wst")){
				System.out.println("CaptureUtilDAO : "+env);
				preparedStatement = ConnectionUtil
						.getWSTConnection()
						.prepareStatement(
								"SELECT REQUEST_TIMESTAMP,QUERY_NAME,EXTERNAL_DATA_PULL_AI,DATA_SOURCE FROM EXTERNAL_DATA_PULL WHERE SESSION_CACHE_AI = (SELECT SESSION_CACHE_AI FROM DOC_CUSTOMER_SESSION WHERE CUSTOMER_SESSION_AI = ?) ORDER BY QUERY_NAME ASC");
			}else if(env.equals("prod")){
				System.out.println("Environment : "+env);
				preparedStatement = ConnectionUtil
						.getProdConnection()
						.prepareStatement(
								"SELECT REQUEST_TIMESTAMP,QUERY_NAME,EXTERNAL_DATA_PULL_AI,DATA_SOURCE FROM EXTERNAL_DATA_PULL WHERE SESSION_CACHE_AI = (SELECT SESSION_CACHE_AI FROM DOC_CUSTOMER_SESSION WHERE CUSTOMER_SESSION_AI = ?) ORDER BY QUERY_NAME ASC");
			}
			
			preparedStatement.setString(1, sessionCacheAI);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				String dataSourceVal=null;
				dataSourceVal = prop1.getProperty(resultSet.getString(4));
				if(dataSourceVal != null && dataSourceVal != ""){
					ExternalDataPullDTO externalDataPullDTO = new ExternalDataPullDTO();
					externalDataPullDTO.setRequestTimeStamp(resultSet.getString(1));
					externalDataPullDTO.setQueryName(resultSet.getString(2));
					externalDataPullDTO.setExternalDataPullAi(resultSet.getString(3));
					responseFromEDP.add(externalDataPullDTO);
				}
			}

		} catch (SQLException e) {
			System.out.println("sql catch catch :"+e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement = null;
				resultSet = null;
				ConnectionUtil.closeConnection();
			} catch (SQLException e) {
				System.out.println("Finnally catch :"+e);
				e.printStackTrace();
			}
		}

		return responseFromEDP;
	}

	private String convertClobtoString(Clob clob) {
		StringBuffer strOut = new StringBuffer();
		String aux = "";
		if (clob != null) {
			try {
				BufferedReader br = new BufferedReader(clob
						.getCharacterStream());
				while ((aux = br.readLine()) != null)
					strOut.append(aux);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return strOut.toString();
	}
}
