package com.ctl.app.virtual.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.ctl.simulation.http.RxContextPathDeploymentUtil;

public class ConnectionUtil {

	private static Properties prop;
	private static Connection conn;

	private static void loadDBProp(){
		RxContextPathDeploymentUtil contextDeploymentUtil=new RxContextPathDeploymentUtil();
        String path=contextDeploymentUtil.getConfigItPath().replace("it", "db_configuration.properties");
        prop = new Properties();
		try {
			FileInputStream f = new FileInputStream(path);
			prop.load(f);
		} catch (Exception e) {
			
		}
	}

	public static Connection getDevConnection() throws SQLException,
			ClassNotFoundException {
		try {
			loadDBProp();
			Class.forName(prop.getProperty("database.connection.driver_class"));
			conn = DriverManager.getConnection(prop
					.getProperty("database.connection.dev-url"), prop
					.getProperty("database.connection.dev-username"), prop
					.getProperty("database.connection.dev-password"));

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}

		return conn;
	}
	
	public static Connection getWSTConnection() throws SQLException,
		ClassNotFoundException {
		try {
			loadDBProp();
			System.out.println("Driver Class : "+prop.getProperty("database.connection.driver_class"));
			Class.forName(prop.getProperty("database.connection.driver_class"));
			System.out.println("After classLoding");
			conn = DriverManager.getConnection(prop
					.getProperty("database.connection.wst-url"), prop
					.getProperty("database.connection.wst-username"), prop
					.getProperty("database.connection.wst-password"));
		
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}
		System.out.println("Got the connection :"+conn);
		return conn;
		}
	
		public static Connection getProdConnection() throws SQLException,
			ClassNotFoundException {
		try {
			loadDBProp();
			Class.forName(prop.getProperty("database.connection.driver_class"));
			conn = DriverManager.getConnection(prop
					.getProperty("database.connection.prod-url"), prop
					.getProperty("database.connection.prod-username"), prop
					.getProperty("database.connection.prod-password"));
		
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}
		
		return conn;
		}

	public static void closeConnection() throws SQLException {
		try {
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			conn.close();
		}
	}

}
