package com.ctl.app.virtual;

public class SearchPojo {
   private String key;
   private String controlFilePath;
   private String description;
   private String system;
   private String subSystem;
   
public String getSystem() {
	return system;
}
public void setSystem(String system) {
	this.system = system;
}
public String getSubSystem() {
	return subSystem;
}
public void setSubSystem(String subSystem) {
	this.subSystem = subSystem;
}
public SearchPojo() {
	// TODO Auto-generated constructor stub
}
public SearchPojo(String key, String controlFilePath, String description,String system,String subSystem) {
	super();
	this.key = key;
	this.controlFilePath = controlFilePath;
	this.description = description;
	this.system=system;
	this.subSystem=subSystem;
}
public String getKey() {
	return key;
}
public void setKey(String key) {
	this.key = key;
}
public String getControlFilePath() {
	return controlFilePath;
}
public void setControlFilePath(String controlFilePath) {
	this.controlFilePath = controlFilePath;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
	
	
}
