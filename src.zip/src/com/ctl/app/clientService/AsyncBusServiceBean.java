/**
 * 
 */
package com.ctl.app.clientService;

/**
 * @author aa47173
 *
 */
public class AsyncBusServiceBean implements AsynchronousBean {
	
	private String asynchTime;
	private String serviceType;
	private String serviceLocation;
	private String serviceURI;

	public String getAsynchTime() {
		return asynchTime;
	}

	public void setAsynchTime(String asynchTime) {
		this.asynchTime = asynchTime;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServiceLocation() {
		return serviceLocation;
	}

	public void setServiceLocation(String serviceLocation) {
		this.serviceLocation = serviceLocation;
	}

	public String getServiceURI() {
		return serviceURI;
	}

	public void setServiceURI(String serviceURI) {
		this.serviceURI = serviceURI;
	}

	/* (non-Javadoc)
	 * @see com.ctl.app.clientService.AsynchronousBean#invoke()
	 */
	@Override
	public void invoke(String responseXml) {
		// TODO Auto-generated method stub

	}

}
