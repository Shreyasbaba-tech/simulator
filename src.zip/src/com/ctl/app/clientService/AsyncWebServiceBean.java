/**
 * 
 */
package com.ctl.app.clientService;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

/**
 * @author aa47173
 *
 */
public class AsyncWebServiceBean implements AsynchronousBean{
	
	private String asynchTime;
	private String serviceType;
	private String serviceLocation;
	private String serviceURI;

	public String getAsynchTime() {
		return asynchTime;
	}

	public void setAsynchTime(String asynchTime) {
		this.asynchTime = asynchTime;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServiceLocation() {
		return serviceLocation;
	}

	public void setServiceLocation(String serviceLocation) {
		this.serviceLocation = serviceLocation;
	}

	public String getServiceURI() {
		return serviceURI;
	}

	public void setServiceURI(String serviceURI) {
		this.serviceURI = serviceURI;
	}

	@Override
	public void invoke(final String responseXml) {
		Runnable task = new Runnable() {
            public void run() { 
                try { 
                	Thread.sleep(Integer.parseInt(asynchTime));
                	callClientService(responseXml,asynchTime,serviceType,serviceLocation,serviceURI); 
                } catch (Exception ex) { 
                   ex.printStackTrace();
                } 
            }			 
        };
       
        new Thread(task, "ServiceThread").start();
		
	}

	protected void callClientService(String requestXml,String asynchTime, String serviceType, String serviceLocation,String serviceURI) {
		//Call client service
				
		try {
            // Create SOAP Connection
            SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
            SOAPConnection soapConnection = soapConnectionFactory.createConnection();
            
            //String filename="C:\\DVARREQ.xml";

            // Send SOAP Message to SOAP Server
            String url = serviceURI;
            SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(requestXml), url);

            // Process the SOAP Response
            printSOAPResponse(soapResponse);

            soapConnection.close();
        } catch (Exception e) {
            System.err.println("Error occurred while sending SOAP Request to Server");
            e.printStackTrace();
        }
	}
	
	private static SOAPMessage createSOAPRequest(String requestXml) throws Exception {
		File file = null;
		try {
	          file = new File("temp.txt");
	          BufferedWriter output = new BufferedWriter(new FileWriter(file));
	          output.write(requestXml);
	          output.close();
	        } catch ( IOException e ) {
	           e.printStackTrace();
	        }
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();
        soapPart.setContent(new StreamSource(new FileInputStream(file)));
        soapMessage.saveChanges();
        return soapMessage;
	}
	
	/**
     * Method used to print the SOAP Response
     */
    private static void printSOAPResponse(SOAPMessage soapResponse) throws Exception {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        Source sourceContent = soapResponse.getSOAPPart().getContent();
        StreamResult result = new StreamResult(System.out);
        transformer.transform(sourceContent, result);
    }
}
