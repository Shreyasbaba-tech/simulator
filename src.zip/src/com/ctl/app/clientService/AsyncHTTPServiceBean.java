/**
 * 
 */
package com.ctl.app.clientService;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

/**
 * @author aa47173
 *
 */
public class AsyncHTTPServiceBean implements AsynchronousBean {
	
	private String asynchTime;
	private String serviceType;
	private String serviceLocation;
	private String serviceURI;

	public String getAsynchTime() {
		return asynchTime;
	}

	public void setAsynchTime(String asynchTime) {
		this.asynchTime = asynchTime;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServiceLocation() {
		return serviceLocation;
	}

	public void setServiceLocation(String serviceLocation) {
		this.serviceLocation = serviceLocation;
	}

	public String getServiceURI() {
		return serviceURI;
	}

	public void setServiceURI(String serviceURI) {
		this.serviceURI = serviceURI;
	}

	/* (non-Javadoc)
	 * @see com.ctl.app.clientService.AsynchronousBean#invoke()
	 */
	@Override
	public void invoke(final String responseXml) {
		System.out.println("responseXml------->>>>>>"+responseXml);		
		Runnable task = new Runnable() {
            public void run() { 
                try { 
                	Thread.sleep(Integer.parseInt(asynchTime));
                	callClientService(responseXml,asynchTime,serviceType,serviceLocation,serviceURI); 
                } catch (Exception ex) { 
                   ex.printStackTrace();
                } 
            }			 
        };
       
        new Thread(task, "ServiceThread").start();

	}
	
	protected void callClientService(String requestXml,String asynchTime, String serviceType, String serviceLocation,String serviceURI) {
		String response = "failed";
		HttpURLConnection urlConnection = null;
		try {
			URL url = new URL(serviceURI);   
			urlConnection = (HttpURLConnection) url.openConnection();
	        InputStream in = new BufferedInputStream(urlConnection.getInputStream());
	        response = new Scanner(in).useDelimiter("\\A").next();
	    }
	    catch (Exception e) {
	        urlConnection.disconnect();
	    }
	    finally {
	        urlConnection.disconnect();
	        System.out.println("Response ::::: "+response);
	    }
	}

}
