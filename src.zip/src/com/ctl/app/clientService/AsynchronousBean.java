/**
 * 
 */
package com.ctl.app.clientService;

/**
 * @author aa47173
 *
 */
public interface AsynchronousBean {
	
	public void invoke(String responseXml);

}
