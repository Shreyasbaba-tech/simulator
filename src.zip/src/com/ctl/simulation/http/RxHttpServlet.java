package com.ctl.simulation.http;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;

import com.ctl.simulation.action.SimulatorAction;
import com.ctl.simulation.bus.SimulatorBusService;
import com.ctl.simulation.simulator.ISimulator;
import com.ctl.simulation.spring.BeanApplicationContext;
import com.ctl.simulation.thread.SimulatorCtxThreadLocal;
import com.ctl.simulation.thread.SimulatorThread;


public class RxHttpServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Log logger =LogFactory.getLog("SimulationLogger");
	private static ApplicationContext ctx;
	
	ISimulator iSimulator;
	
	@SuppressWarnings("unchecked")
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {

		String beanId=null;
		String response=null;
		beanId=getBeanIdFromRequest(req);
		iSimulator =(ISimulator) BeanApplicationContext.getApplicationContext().getBean(beanId);
		logger.info("Simualtor is: "+iSimulator.getClass().toString());
		//response=iSimulator.simulate(req).toString();

		Thread webSimulatorThread = new SimulatorThread(iSimulator,req,beanId);
		webSimulatorThread.run();
		response=SimulatorCtxThreadLocal.get().getResponse();
		SimulatorAction action=SimulatorCtxThreadLocal.get().getAction();
		SimulatorCtxThreadLocal.unset();
		logger.info("Simualtor returned http or SOAP response");
		if(action.getJsonFormat()!=null && action.getJsonFormat().toLowerCase().equals("on"))
			resp.setContentType("application/json");
		else
			resp.setContentType("text/xml");
		
		
		resp.getOutputStream().write(response.getBytes());

	}
	

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
			doGet(req, resp);
	}
	
	@Override
	/**
	 * This initializes the Spring application context and Simulator Bus service
	 * 
	 */
	public void init() throws ServletException{	
		
		//enable below 2lines for running this app on local server
//		String contextPath = "file:///C://Users//aa47173//MiscAppWorkSpace//AppVirtualWebFormGenerator//WebContent//config//it//application-context.xml";
//		String busContextPath = "file:///C://Users//aa47173//MiscAppWorkSpace//AppVirtualWebFormGenerator//WebContent//config//it//simulation-busservice.xml";
		//getServletContext().getRealPath("/config/it/application-context.xml");

//getServletContext().getRealPath("/config/it/simulation-busservice.xml");
//contextPath="/"+StringUtils.substringBeforeLast(contextPath, "/apps/virtualApp")+"/config/it/application-context.xml";
//busContextPath="/"+StringUtils.substringBeforeLast(busContextPath, "/apps/virtualApp")+"/config/it/simulation-busservice.xml";
		String contextPath;
		String busContextPath;
		if(System.getProperty("os.name").startsWith("Windows")){
			contextPath = "file:///C://Anuj//apache-tomcat-8.0.47//webapps//virtualApp//config//it//application-context.xml";
			busContextPath = "file:///C://Anuj//apache-tomcat-8.0.47//webapps//virtualApp//config//it//simulation-busservice.xml";
		}else{
			contextPath = "/" +getServletContext().getRealPath("/config/it/application-context.xml");
			busContextPath = "/" +getServletContext().getRealPath("/config/it/simulation-busservice.xml");
			//contextPath = "/" + StringUtils.substringBeforeLast(contextPath, "/apps/virtualApp") + "/config/it/application-context.xml";
			//busContextPath = "/" + StringUtils.substringBeforeLast(busContextPath, "/apps/virtualApp") + "/config/it/simulation-busservice.xml";
		}
		
		
		
		logger.info(" Real Path for /config/it/application-context.xml  :"+contextPath);
		logger.info(" Real Path for simulation-busservice.xml  :"+busContextPath);
			
		new BeanApplicationContext(contextPath);
		ctx = BeanApplicationContext.getApplicationContext();
		if(ctx!=null){
			logger.info("Context is available");
			for (String beanId : BeanApplicationContext.getApplicationContext().getBeanDefinitionNames()) {
				if(!BeanApplicationContext.getApplicationBeanIds().contains(beanId))
				BeanApplicationContext.getApplicationBeanIds().add(beanId);
			}
			
			
		}
		//Initialize the Bus Listener
		try {
			//Start the listener
			Thread thread = new Thread(new SimulatorBusService(busContextPath).getInstance());
			thread.start();
			//SimulatorBusService.getInstance().run();
			logger.info("simulator bus listener started");
			System.out.println("********* simulator bus listener started *********************");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private String getBeanIdFromRequest(HttpServletRequest req) {
		String beanId=null;
		String pathInfo=req.getPathInfo();
	
		if(pathInfo.contains("http")){
			logger.info("Simulator recived HttpRequest Request"); 
			beanId=StringUtils.substringAfter(pathInfo, "/http/");
		}else{
			logger.info("Simulator recived SOAP Request ");
			beanId=StringUtils.substringAfter(pathInfo, "/soap/");
		}
		
		return beanId;
	}
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
		try {
			SimulatorBusService.getInstance().destroy();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*
	 * This is a test method
	 */
	public static void main(String[] args){ 
		try { 
			System.setProperty("app.config.file","drdsl_config_it.cfg"); 
			System.setProperty("app.config.dir","C:\\SGOLLAWorkSpace\\Simulation\\RxSimulation\\config");
			System.setProperty("app.resource.type","FILE"); 
			String contextPath = "file:///C://Users//aa47173//MiscAppWorkSpace//AppVirtualWebFormGenerator//WebContent//config//it//application-context.xml";
			//getServletContext().getRealPath("/config/it/application-context.xml");
	String busContextPath = "file:///C://Users//aa47173//MiscAppWorkSpace//AppVirtualWebFormGenerator//WebContent//config//it//simulation-busservice.xml";
	//getServletContext().getRealPath("/config/it/simulation-busservice.xml");
	//contextPath="/"+StringUtils.substringBeforeLast(contextPath, "/apps/virtualApp")+"/config/it/application-context.xml";
	//busContextPath="/"+StringUtils.substringBeforeLast(busContextPath, "/apps/virtualApp")+"/config/it/simulation-busservice.xml";
	
	logger.info(" Real Path for /config/it/application-context.xml  :"+contextPath);
	logger.info(" Real Path for simulation-busservice.xml  :"+busContextPath);
		
	new BeanApplicationContext(contextPath);
	ctx = BeanApplicationContext.getApplicationContext();
	if(ctx!=null){
		logger.info("Context is available");
		for (String beanId : BeanApplicationContext.getApplicationContext().getBeanDefinitionNames()) {
			if(!BeanApplicationContext.getApplicationBeanIds().contains(beanId))
			BeanApplicationContext.getApplicationBeanIds().add(beanId);
		}
		
		
	}
			
			SimulatorBusService.getInstance().init(); 
			logger.info("RxServiceClass bus listener started"); 
		} catch (Exception e) { 
			e.printStackTrace(); 
	} 
	


	
}
	}
