package com.ctl.simulation.http;

import com.opensymphony.xwork2.util.finder.Test;

public class RxContextPathDeploymentUtil {
	
	public static void main(String[] args)
	{
		RxContextPathDeploymentUtil util=new RxContextPathDeploymentUtil();
	    String path=util.getConfigItPath();
	    System.out.println(path);
	}

	public String getConfigItPath()
	{
		try {
			java.net.URL location = Test.class.getProtectionDomain().getCodeSource().getLocation();
			
			   String path=location.getPath();
			   String configItPath="";
			   System.out.println("path is"+path);
			   path=path.substring(0, path.indexOf("virtualApp"));
			   
			/*   String userHome = System.getProperty( "user.home" );
			   System.out.println(userHome);
			   */
			//   String homeDir=path;
			//   String sub=homeDir.substring(homeDir.indexOf(".metadata"),homeDir.length() );
			  // homeDir=ho   path=path.substring(0, path.indexOf("virtualApp")); path.su
			   if(System.getProperty("os.name").startsWith("Windows")){
				   configItPath="C:/Anuj/apache-tomcat-8.0.47/webapps/virtualApp/config/it/";
			   }else{
				   //path=path.substring(0, path.indexOf("rxsim01-dev"));
				   configItPath="/home/rxsim/bin/apache-tomcat-8.5.38/webapps/virtualApp/config/it/";
				   System.out.println("configItPath"+configItPath);
			   }
			   return configItPath;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
