package com.ctl.simulation.resiliency;

import java.io.FileInputStream;
import java.util.Properties;

public class ResiliencyParameterManager {

	public String applyResiliencyParameter(String controlFile){
		String responseString;
		Properties resiliencyParam = getResiliencyParameter(controlFile);
		if(resiliencyParam.getProperty("TimeOut")!=null){
			try {
					
				int waitPeriod = Integer.parseInt(resiliencyParam.getProperty("TimeOut"));
				if(waitPeriod>0){
					Thread.sleep(waitPeriod * 1000);
				}
				
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if(resiliencyParam.getProperty("Exception")!=null){
			
		}
		return "";
		
		
}
	
	public Properties getResiliencyParameter(String controlFile){
		Properties pro = new Properties();
		try {
			FileInputStream f = new FileInputStream(controlFile);
			pro.load(f);
		} catch (Exception e) {
			
		}
		
		return pro;		
		
	}
	
	public static void main(String[] args) {
		ResiliencyParameterManager manager = new ResiliencyParameterManager();
		manager.applyResiliencyParameter("C:\\Simulation\\Responses\\LoopQual\\2083220022.cntrl");
		
		
		
	}
	
}
