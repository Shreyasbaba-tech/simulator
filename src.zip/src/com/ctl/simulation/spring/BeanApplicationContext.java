package com.ctl.simulation.spring;

import java.util.ArrayList;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class BeanApplicationContext implements ApplicationContextAware {

	private static ApplicationContext ctx;
	
	private static ArrayList<String> applicationBeanIds= new ArrayList<String>();
	
	public BeanApplicationContext(String contextPath) {
		
				ctx = new FileSystemXmlApplicationContext(contextPath);
	}

	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		ctx = applicationContext;
	}

	public static ApplicationContext getApplicationContext() {
		
		return ctx;
	}
	
	
	
	public static ArrayList<String> getApplicationBeanIds() {
		return applicationBeanIds;
	}

	public static void setApplicationBeanIds(ArrayList<String> applicationBeanIds) {
		BeanApplicationContext.applicationBeanIds = applicationBeanIds;
	}
	
}
