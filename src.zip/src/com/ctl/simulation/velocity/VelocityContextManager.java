package com.ctl.simulation.velocity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.ctl.simulation.thread.SimulatorCtxThreadLocal;


public class VelocityContextManager {
	
	ITemplate iTemplate;
	public static final String EMPTY_STRING = "";

	public String applyTemplate(File resFile, String fileName){    
		  StringWriter writer = new StringWriter();   
        try
        {   
			if (resFile != null) {
				
				System.out.println("file canonical path:"+resFile.getCanonicalPath());
				System.out.println("file absoulate path:"+resFile.getAbsolutePath());
	            Map tokenMap= new HashMap();
	            VelocityContext context = new VelocityContext();
	    		Properties props = new Properties();
	    		props.put("resource.loader", "file");
	    		props.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.FileResourceLoader");
	    		
	    		props.put("file.resource.loader.path", resFile.getAbsolutePath());

	    		VelocityEngine vEngine = new VelocityEngine();
	    		vEngine.init(props);
	    		
	    		// Get the request parameter map.
	            tokenMap = SimulatorCtxThreadLocal.get().getReqParamsMap();
	            context.put("date", new DateTemplate());
	            
	            // Iterate tokenMap and set to velocity context.
				Iterator it = tokenMap.keySet().iterator();
				while (it.hasNext()) {
					String key = (String) it.next();
					Object value = tokenMap.get(key);
					context.put(key, value);
					System.out.println("key====>:"+key);
					System.out.println("value==>:"+value);
				}
	           // context.put("tokenMap", tokenMap);
	          
	            Template template = vEngine.getTemplate(fileName);
	            template.merge( context , writer);  
        	}
			
        }
        catch( Exception e )
        {
           e.printStackTrace();
           System.out.println("Exception : " + e);
        }
        finally
        {
            if ( writer != null)
            {
                try
                {
                    writer.flush();
                    writer.close();
                }
                catch( Exception ee )
                {
                    System.out.println("Exception : " + ee );
                }
            }
        }
        System.out.println("writer.toString()======================>:"+writer.toString());
		return writer != null ? writer.toString() : EMPTY_STRING;
	}


	public String getTemplateFromResource(File templateFile) {
			    try {
			    	
			    	InputStream stream = new FileInputStream(templateFile) ;
			        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
			        StringBuilder sb = new StringBuilder();
			        String line = null;
			        while ((line = reader.readLine()) != null) {
			          sb.append(line + "\n");
			        }
			      
			        return sb.toString();
			     
			    } catch (IOException ex) {
			        throw new RuntimeException(ex);
			    }
			}
	
	public static void main(String args[]){
		VelocityContextManager vm = new VelocityContextManager();
	//	vm.applyTemplate(null);
	}
}
