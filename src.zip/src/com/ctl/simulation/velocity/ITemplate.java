package com.ctl.simulation.velocity;

public interface ITemplate {
	public Object get(String str, int add);
}
