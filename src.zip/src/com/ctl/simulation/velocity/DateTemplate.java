package com.ctl.simulation.velocity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateTemplate implements ITemplate {
	public String get(String pattern, int additional) {
	SimpleDateFormat format = new SimpleDateFormat(pattern);
	Calendar currentDate = Calendar.getInstance();
	currentDate.add(Calendar.DAY_OF_MONTH,additional);
	String dateNow = format.format(currentDate.getTime());
	return dateNow;
	}
	
}
