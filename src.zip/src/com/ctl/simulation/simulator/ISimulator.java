package com.ctl.simulation.simulator;

public interface ISimulator {
	
	public Object simulate(Object reqObject);

}
