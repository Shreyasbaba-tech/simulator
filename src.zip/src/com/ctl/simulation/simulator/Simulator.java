package com.ctl.simulation.simulator;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.ctl.app.clientService.AsynchronousBean;
import com.ctl.simulation.action.SimulatorAction;
import com.ctl.simulation.helper.XpathUtil;
import com.ctl.simulation.thread.SimulatorCtxThreadLocal;

public abstract class Simulator implements ISimulator {
	List<SimulatorAction> actions;
	
	String simulatorFilePath;

	
	public Object simulate(Object reqObject) {

		return simulateImpl(reqObject);
	}

	abstract Object simulateImpl(Object reqObject);

	protected String getResponseXML(String requestXml){
		System.out.println("request hitting the server : "+requestXml);
		XpathUtil xpathUtil = new XpathUtil();
		String responseXml=null;
		SimulatorAction action;
		String baseFilePath = getSimulatorFilePath();
		List<SimulatorAction> actions = getActions();


		for (SimulatorAction object : actions) {
			action=	(SimulatorAction) object;
			String actionXpath = action.getActionXpath();
			String actionXpathValue=action.getActionXpathValue();
			boolean checkForActionXpathPresence = action.isCheckForActionXpathPresence();
			String responseType = action.getResponseType();
			String ackRequired = action.getAckRequired();
			if(checkForActionXpathPresence){
				if(StringUtils.equalsIgnoreCase(action.getJsonFormat(), "on")){
						//JSONObject obj=new JSONObject(requestXml);
						SimulatorCtxThreadLocal.get().setAction(action);
						responseXml = action.getResponse(requestXml, baseFilePath);
						if("ASYNCHRONOUS".equals(responseType)){
							AsynchronousBean asynchronourBean = action.getAsynchronourBean();
							asynchronourBean.invoke(responseXml);
							if("true".equals(ackRequired))
								action.getAcknowledgement(requestXml, baseFilePath);
						}
						break;
					
				}
				if(!StringUtils.isEmpty(xpathUtil.retrieveElementValue(actionXpath, requestXml))){
					SimulatorCtxThreadLocal.get().setAction(action);
					responseXml = action.getResponse(requestXml, baseFilePath);
					if("ASYNCHRONOUS".equals(responseType)){
						AsynchronousBean asynchronourBean = action.getAsynchronourBean();
						asynchronourBean.invoke(responseXml);
						if("true".equals(ackRequired))
							action.getAcknowledgement(requestXml, baseFilePath);
					}
					break;
				}
			}
			else{
				if(!StringUtils.isEmpty(xpathUtil.retrieveElementValue(actionXpath, requestXml)))
					if(xpathUtil.retrieveElementValue(actionXpath, requestXml).equals(actionXpathValue)){
						SimulatorCtxThreadLocal.get().setAction(action);
						responseXml = action.getResponse(requestXml, baseFilePath);
						if("ASYNCHRONOUS".equals(responseType)){
							AsynchronousBean asynchronourBean = action.getAsynchronourBean();
							asynchronourBean.invoke(responseXml);
						}
						break;
					}
			}
		}
		//Apply Template before sending back the response to Rx
		
	//	VelocityContextManager templateManager =  new VelocityContextManager();
		//responseXml=templateManager.applyTemplate(responseXml);
		if(!StringUtils.isEmpty(responseXml)){
			
		}

		return responseXml;

	}


	protected String convertRequestParameterMapToXML(String request){
		StringTokenizer token = new StringTokenizer(request,"&");
		Map map=new HashMap<String, String>();
        while(token.hasMoreTokens()){
              StringTokenizer token1= new StringTokenizer(token.nextToken(),"=");
              while(token1.hasMoreTokens()){
              map.put(token1.nextToken(), token1.nextToken());
        }}
        
              StringBuffer xml= new StringBuffer();
              xml.append("<HTTPRequest>");
        
        Iterator itr = map.entrySet().iterator();
        while(itr.hasNext()){
              Map.Entry pairs = (Map.Entry)itr.next();
              xml.append("<"+pairs.getKey()+">"+pairs.getValue()+"</"+pairs.getKey()+">");
        }
        xml.append("</HTTPRequest>");

		return xml.toString();
	}
	
	
	
	public String getSimulatorFilePath() {
		return simulatorFilePath;
	}

	public void setSimulatorFilePath(String simulatorFilePath) {
		this.simulatorFilePath = simulatorFilePath;
	}
	
	public List<SimulatorAction> getActions() {
		return actions;
	}

	public void setActions(List<SimulatorAction> actions) {
		this.actions = actions;
	}
	


}
