/**
 * 
 */
package com.ctl.simulation.simulator;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;

import com.ctl.simulation.action.JMSSimulatorAction;
import com.ctl.simulation.helper.XpathUtil;
import com.ctl.simulation.thread.SimulatorCtxThreadLocal;

/**
 * @author aa47173
 *
 */
public abstract class JSimulator implements ISimulator{

List<JMSSimulatorAction> actions;
	
	String simulatorFilePath;

	
	public Object simulate(Object reqObject) {

		return simulateImpl(reqObject);
	}

	abstract Object simulateImpl(Object reqObject);

	protected String getResponseXML(String requestXml){
		System.out.println("request hitting the server : "+requestXml);
		XpathUtil xpathUtil = new XpathUtil();
		String responseXml=null;
		JMSSimulatorAction action;
		String baseFilePath = getSimulatorFilePath();
		List<JMSSimulatorAction> actions = getActions();


		for (JMSSimulatorAction object : actions) {
			action=	(JMSSimulatorAction) object;
			responseXml = action.getResponse(requestXml, baseFilePath);
			/*String actionXpath = action.getActionXpath();
			String actionXpathValue=action.getActionXpathValue();
			boolean checkForActionXpathPresence = action.isCheckForActionXpathPresence();
			if(checkForActionXpathPresence){
				if(!StringUtils.isEmpty(xpathUtil.retrieveElementValue(actionXpath, requestXml))){
					SimulatorCtxThreadLocal.get().setAction(action);
					break;
				}
			}
			else{
				if(!StringUtils.isEmpty(xpathUtil.retrieveElementValue(actionXpath, requestXml)))
					if(xpathUtil.retrieveElementValue(actionXpath, requestXml).equals(actionXpathValue)){
						SimulatorCtxThreadLocal.get().setAction(action);
						responseXml = action.getResponse(requestXml, baseFilePath);
						break;
					}
			}*/
		}
		//Apply Template before sending back the response to Rx
		
	//	VelocityContextManager templateManager =  new VelocityContextManager();
		//responseXml=templateManager.applyTemplate(responseXml);
		

		return responseXml;

	}


	protected String convertRequestParameterMapToXML(String request){
		StringTokenizer token = new StringTokenizer(request,"&");
		Map map=new HashMap<String, String>();
        while(token.hasMoreTokens()){
              StringTokenizer token1= new StringTokenizer(token.nextToken(),"=");
              while(token1.hasMoreTokens()){
              map.put(token1.nextToken(), token1.nextToken());
        }}
        
              StringBuffer xml= new StringBuffer();
              xml.append("<HTTPRequest>");
        
        Iterator itr = map.entrySet().iterator();
        while(itr.hasNext()){
              Map.Entry pairs = (Map.Entry)itr.next();
              xml.append("<"+pairs.getKey()+">"+pairs.getValue()+"</"+pairs.getKey()+">");
        }
        xml.append("</HTTPRequest>");

		return xml.toString();
	}

	
	
	public String getSimulatorFilePath() {
		return simulatorFilePath;
	}

	public void setSimulatorFilePath(String simulatorFilePath) {
		this.simulatorFilePath = simulatorFilePath;
	}
	
	public List<JMSSimulatorAction> getActions() {
		return actions;
	}

	public void setActions(List<JMSSimulatorAction> actions) {
		this.actions = actions;
	}
	
	static int startInt = 1;
public static void main(String[] args)
{
	int numOfLines = 5;
	int numOfSpaces = numOfLines -1; 
	int curLine = 1;
	
	while(curLine<numOfLines)
	{
		for(int i=numOfSpaces;i>0;i--)
		{
			System.out.print(" ");
		}
	   for(int j =0 ;j<curLine;j++)
		{
		  
			System.out.print(startInt++);
			//startInt;
		}	
		numOfSpaces--;
		//numOfLines--;
		System.out.println("\n");
		curLine++;
		//for(int i=)
	}
	
	
	
	
}
}
