package com.ctl.simulation.simulator;

import com.ctl.simulation.thread.SimulatorCtxThreadLocal;
import com.qwest.bus.BusMessage;

public class BusSimulator extends Simulator{

	@Override
	Object simulateImpl(Object reqObject) {
	BusMessage reqMessage = (BusMessage) reqObject;
	
	String requestXml=null;
	String response=null;
	requestXml=reqMessage.getCapsule().getAttribute("DATA").getValue().toString();
	SimulatorCtxThreadLocal.get().setRequest(requestXml);
	response=getResponseXML(requestXml);
	return response;
	}

}