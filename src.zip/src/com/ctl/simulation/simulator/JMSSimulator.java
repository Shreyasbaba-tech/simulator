/**
 * 
 */
package com.ctl.simulation.simulator;

import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.ctl.simulation.thread.SimulatorCtxThreadLocal;

/**
 * @author aa47173
 *
 */
public class JMSSimulator extends JSimulator{
	
	Object simulateImpl(Object reqObject) {
		
		String requestXml=null;
		String response=null;
		HttpServletRequest request = (HttpServletRequest) reqObject;	
		if(checkForHttp(request)){
			requestXml=convertRequestParameterMapToXML(request.getQueryString());
			SimulatorCtxThreadLocal.get().setRequest(requestXml);
			response=getResponseXML(requestXml);
			
		}else{
			requestXml=getPostData(request);
			SimulatorCtxThreadLocal.get().setRequest(requestXml);
			System.out.println("request hitting the webSimulator : "+requestXml);
			response=getResponseXML(requestXml);
		}
		
		return response;
	}
	
	public String getPostData(HttpServletRequest req) {
	    StringBuilder sb = new StringBuilder();
	    try {
	        BufferedReader reader = req.getReader();
	        reader.mark(10000);

	        String line;
	        do {
	            line = reader.readLine();
	            if(line!=null)
	            	sb.append(line).append("\n");
	            
	        } while (line != null);
	        reader.reset();
	    } catch(IOException e) {
	            
	    }

	    return sb.toString();
	}
	private boolean checkForHttp(HttpServletRequest request) {
		String pathInfo=request.getPathInfo();
		if(pathInfo.contains("http")){
			return true;	
		}
				
		return false;
	}

}
