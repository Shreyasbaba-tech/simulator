package com.ctl.simulation.simulator;

import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.ctl.simulation.thread.SimulatorCtxThreadLocal;

public class WebSimulator extends Simulator {

	Object simulateImpl(Object reqObject) {
	
		String requestXml=null;
		String response=null;
		HttpServletRequest request = (HttpServletRequest) reqObject;	
		if(checkForHttp(request)){
			if(request.getQueryString()!=null){
			 requestXml=convertRequestParameterMapToXML(request.getQueryString());
			 SimulatorCtxThreadLocal.get().setRequest(requestXml);
			 System.out.println("request hitting the webSimulator for http request get : "+requestXml);
			 response=getResponseXML(requestXml);
			}else{
			 requestXml=getPostData(request);
			 SimulatorCtxThreadLocal.get().setRequest(requestXml);
			 System.out.println("request hitting the webSimulator for http request post : "+requestXml);
			 response=getResponseXML(requestXml);
		   }
		}else{
			   requestXml=getPostData(request);
			   requestXml = removeXmlStringNamespaceAndPreamble(requestXml);
			   SimulatorCtxThreadLocal.get().setRequest(requestXml);
			   			 System.out.println("request hitting the webSimulator for web service : "+requestXml);
			   response=getResponseXML(requestXml);
		   }
		
		return response;
	}
	
	public static String removeXmlStringNamespaceAndPreamble(String xmlString) {

		for(int i=0;i<25;i++){
			xmlString = xmlString.replaceAll("ns"+i+":", "");
		}
		return xmlString;
	}
	
	public String getPostData(HttpServletRequest req) {
	    StringBuilder sb = new StringBuilder();
	    try {
	        BufferedReader reader = req.getReader();
	        reader.mark(10000);

	        String line;
	        do {
	            line = reader.readLine();
	            if(line!=null)
	            	sb.append(line).append("\n");
	            
	        } while (line != null);
	        reader.reset();
	    } catch(IOException e) {
	            
	    }

	    return sb.toString();
	}
	private boolean checkForHttp(HttpServletRequest request) {
		String pathInfo=request.getPathInfo();
		if(pathInfo.contains("http")){
			return true;	
		}
				
		return false;
	}
	
}
