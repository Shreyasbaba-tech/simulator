/**
 * 
 */
package com.ctl.simulation.unittest;

import junit.framework.TestCase;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ctl.simulation.bus.SimulatorBusService;






/**
 * @author sgolla
 *
 */
public class SimulationBusServiceTest extends TestCase {

	private static Log log = LogFactory.getLog("RxLogger");
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		System.setProperty("app.config.file","drdsl_config_it.cfg"); 
		System.setProperty("app.config.dir","C:\\SGOLLAWorkSpace\\Simulation\\RxSimulation\\config");
		System.setProperty("app.resource.type","FILE"); 
	}

		
	public void testSimulationBusListener() {
		try { 
			SimulatorBusService.getInstance().init(); 
			log.info("RxServiceClass bus listener started"); 
		} catch (Exception e) { 
			e.printStackTrace(); 
		} 
		
		
	}
	


}
