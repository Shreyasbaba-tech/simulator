package com.ctl.simulation.unittest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.tools.generic.DateTool;

import com.ctl.simulation.velocity.DateTemplate;
import com.ctl.simulation.velocity.ITemplate;


public class XMLTest {
	
	ITemplate iTemplate;
	 public XMLTest( String templateFile, File responseFile, File requestFile)
	    {   
		 
		 String str;
	  
	        Writer writer = null;
	        try
	        {         
//	            SAXBuilder builder;
//	            Document root = null;
	            Map tokenMap=null;
//	            try 
//	            {
//	                builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser" );
//	                root = builder.build(responseFile);
//	            }
//	            catch( Exception ee)
//	            { 
//	                return;
//	            }
	            
//	        		Properties p = new Properties();
//	        		p.setProperty("resource.loader", "string");
//	        		p.setProperty("resource.loader.class", "org.apache.velocity.runtime.resource.loader.StringResourceLoader");
	            
	            VelocityEngine vEngine = new VelocityEngine( );
	            vEngine.setProperty("velocimacro.library", "./src/macros.vm");
	            vEngine.init();
	            
	            tokenMap = constructTokenMap();
	            VelocityContext context = new VelocityContext();
	        
	            context.put("req1", "12345");
	            context.put("req2", "6789");
	            context.put("req3", "027329");
	            context.put("date", new DateTemplate());
	            tokenMap.put("date", new DateTemplate());
	            Template template = Velocity.getTemplate("./src/2083220022.vm");
	            writer = new BufferedWriter(new OutputStreamWriter(System.out));
	           // Velocity.evaluate(context, writer, "", str1);
	        
	            template.merge( context , writer);  
	        }
	        catch( Exception e )
	        {
	           System.out.println("Exception : " + e);
	        }
	        finally
	        {
	            if ( writer != null)
	            {
	                try
	                {
	                    writer.flush();
	                    writer.close();
	                }
	                catch( Exception ee )
	                {
	                    System.out.println("Exception : " + ee );
	                }
	            }
	        }
	    }

	    public static void main(String[] args)
	    {
	        XMLTest t;
//	               
	        File responseFile = new File("C:\\Simulation\\Responses\\LoopQual\\2083220022.vm");
	        File requestFile = new File("C:\\SGOLLAWorkSpace\\Simulation\\RxSimulation\\config\\vcsrresponse.xml");
	        t = new XMLTest("./webinf-merge/Template.vm",responseFile,requestFile);
	    	
	    	DateTool date = new DateTool();
	    	
	    	System.out.println(date.getFormattedDate("dd/mm/yyyy"));
	    	
	    }
	    
	 
	    
private Map constructTokenMap(){
			Map tokenMap = new HashMap<String, Object>();
			//tokenMap.put($req1, "12345");
		   	return tokenMap;
			
		
	}
private DateTemplate getDate() {
	// TODO Auto-generated method stub
	return  new DateTemplate();
}

public static String test(String a,  String b){
	return a+b;
}

public static String replacevalues(File responseFile, File requestFile){
	
	
	return null;
	
}

public String getTemplateFromResource(final String templatePath) {
    try {
        InputStream stream = new FileInputStream(new File(templatePath)) ;
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        StringBuilder sb = new StringBuilder();
        String line = null;
        while ((line = reader.readLine()) != null) {
          sb.append(line + "\n");
        }
      
        return sb.toString();
     
    } catch (IOException ex) {
        throw new RuntimeException(ex);
    }
}

}
