package com.ctl.simulation.bus;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ctl.simulation.simulator.ISimulator;
import com.ctl.simulation.spring.BeanApplicationContext;
import com.ctl.simulation.thread.SimulatorCtxThreadLocal;
import com.ctl.simulation.thread.SimulatorThread;
import com.qwest.bus.BusMessage;
import com.qwest.bus.responder.BusProcessor;
import com.qwest.capsule.AttributeException;

public class SimulatorBusProcessor extends BusProcessor {
	
	
	private static Log _log = LogFactory.getLog("SimulationLogger");
	
	ISimulator iSimulator;
	
	@Override
	public BusMessage process(BusMessage msg) {
		
		 _log.info("BusMessage Recieved");
		String response;
		
		BusMessage resMessage = null;
		
		String topic=msg.getTopic();
		String beanId= topic;
		iSimulator =(ISimulator) BeanApplicationContext.getApplicationContext().getBean(beanId);
		 _log.info("Simualtor is: "+iSimulator.getClass().toString());
		Thread busSimulatorThread = new SimulatorThread(iSimulator,msg, beanId);
		busSimulatorThread.run();
		response=SimulatorCtxThreadLocal.get().getResponse();
		SimulatorCtxThreadLocal.unset();
		//response=iSimulator.simulate(msg).toString();
	
		try {
			resMessage=msg.createResponse();
			resMessage.getCapsule().setAttribute("DATA",response);
		} catch (AttributeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		_log.info("BusMessage Returned");
		return resMessage;
		
	}

	
	
}
