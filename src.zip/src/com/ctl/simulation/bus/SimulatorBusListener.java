package com.ctl.simulation.bus;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class SimulatorBusListener implements ServletContextListener {

	private static Log _log = LogFactory.getLog("SimulationLogger");

	public void contextInitialized(ServletContextEvent event) {
		try {
//			Start the listener
			SimulatorBusService.getInstance().init();
			_log.info("simulator bus listener started");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void contextDestroyed(ServletContextEvent arg0) {
		try {
			SimulatorBusService.getInstance().destroy();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// do nothing
	}
	
	public static void main(String[] args){ 
		try { 
			System.setProperty("app.config.file","drdsl_config_it.cfg"); 
			System.setProperty("app.config.dir","C:\\Users\\aa47173\\MiscAppWorkSpace\\AppVirtualWebFormGenerator\\WebContent\\config");
			System.setProperty("app.resource.type","FILE"); 
			SimulatorBusService.getInstance().init(); 
			_log.info("RxServiceClass bus listener started"); 
		} catch (Exception e) { 
			e.printStackTrace(); 
		} 
	}
}
