package com.ctl.simulation.bus;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.qwest.bus.responder.BusResponder;


public class SimulatorBusService implements Runnable {
	
	private static Log logger =LogFactory.getLog("SimulationLogger");
	    
    private static SimulatorBusService instance;    
    private BusResponder busResponder = null;
    private static String busContextPath;
    
    /**
     * This is a static factory method for getting an instance of the IBusService
     * @return BusService
     */
    public static SimulatorBusService getInstance()
    {
    	if(instance == null)
    	{
			synchronized(SimulatorBusService.class)
			{
				if(instance == null)
					instance = new SimulatorBusService(busContextPath);
			}
    	}
		return instance;
    }
	
    /**
     * This method initializes BusService
     * @throws ConfigurationInitializationException
     * @throws BusServiceException
     */
	public void init()
	{
		try
		{
			if(logger.isDebugEnabled())
			logger.debug("Initializing Application context and Bus Responder ...");			
	        configure();	        
		}
	
		catch(Exception e)
		{
			logger.error("Unable to initialize Bus Service",e);
		
		}
	}
	
	/**
     * This method shuts down BusService
     * @throws BusServiceException
     */
	public void destroy()
	{
	
		try
        {
			if(logger.isInfoEnabled())
        	logger.info("BusService releasing Rx Application Configuratoin resources...");
        	shutdownAllBusResponder();
        	busResponder = null;        	
        	  	
        	if(logger.isInfoEnabled())
        	logger.info("BusService destroyed...");
        } 
        catch (Exception e) 
        {
        	logger.error("Unable to destroy BusService...",e);
        	
        }
	}
	
	
	
     
	
	private void configure() 
	{
		try
    	{
			if(logger.isDebugEnabled())
				logger.debug("Configuring bus service: BusService.configure()");
    	
    		System.setProperty("cfg.uri",busContextPath);
    		if(logger.isInfoEnabled())
    			logger.info("Config URI "+busContextPath);
    		busResponder = new BusResponder(new String[]{busContextPath});
    	
    	}
    	catch(Exception e)
    	{
    		logger.error("Bus Service could not be initialized properly",e);
    	
    	}
    	
	}
	
	/**
     * Creates an IBusAction for the specific Bus Action Type. 
     * 
     * @param request String
     * @param subject String 
     * @return IBusAction 
     * @throws ConfigurationInitializationException
     * @throws InvalidBusRequestException
     * @throws Exception
     */
    
    private void shutdownAllBusResponder()
    {
    	try
    	{
	    	busResponder.shutdown();
    	}
    	catch(Exception e)
    	{
    		logger.error("Unable to shutdown all BusResponder...",e);
    		
    	}
    }
    public void run() {
    	this.init();
    }
    
    /**
     * Instantiates a new simulator bus service.
     * 
     * @param busContextPath the bus context path
     */
    public SimulatorBusService(String busContextPath){
    	this.busContextPath = busContextPath;
    }
}
