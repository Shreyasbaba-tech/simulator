package com.ctl.simulation.action;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.ctl.app.clientService.AsynchronousBean;
import com.ctl.simulation.helper.FileUtility;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.helper.XpathUtil;
import com.ctl.simulation.resiliency.ResiliencyParameterManager;
import com.ctl.simulation.velocity.VelocityContextManager;

public class SimulatorAction {
		
	private static Log _log = LogFactory.getLog("SimulationLogger");
	  private String actionXpath;

	  private boolean checkForActionXpathPresence;
	private boolean isKeyValue;	
	  private String actionFilePath;	
	  private HashMap<String, String> actionFileNames;	
	private HashMap<String, String> actionMap;	
	  private String actionXpathValue;	
	  private HashMap<String, String> reqParams;	
	  private String defaultFile;	
	private String responseType;
	private String ackRequired;
	private AsynchronousBean asynchronourBean;
	private String jsonFormat;
	
	
	
	public String getJsonFormat() {
		return jsonFormat;
	}

	public void setJsonFormat(String jsonFormat) {
		this.jsonFormat = jsonFormat;
	}

	public String getDefaultFile() {
		return defaultFile;
	}

	public void setDefaultFile(String defaultFile) {
		this.defaultFile = defaultFile;
	}

	public HashMap<String, String> getReqParams() {
		return reqParams;
	}

	public void setReqParams(HashMap<String, String> reqParams) {
		this.reqParams = reqParams;
	}

	public String getActionXpath() {
		return actionXpath;
	}

	public void setActionXpath(String actionXpath) {
		this.actionXpath = actionXpath;
	}

	
	public String getActionXpathValue() {
		return actionXpathValue;
	}

	public void setActionXpathValue(String actionXpathValue) {
		this.actionXpathValue = actionXpathValue;
	}

	public String getActionFilePath() {
		return actionFilePath;
	}

	public void setActionFilePath(String actionFilePath) {
		this.actionFilePath = actionFilePath;
	}


	public HashMap<String, String> getActionMap() {
		return actionMap;
	}

	public void setActionMap(HashMap<String, String> actionMap) {
		this.actionMap = actionMap;
	}

	public boolean isCheckForActionXpathPresence() {
		return checkForActionXpathPresence;
	}

	public void setCheckForActionXpathPresence(boolean checkForActionXpathPresence) {
		this.checkForActionXpathPresence = checkForActionXpathPresence;
	}

	
	public HashMap<String, String> getActionFileNames() {
		return actionFileNames;
	}

	public void setActionFileNames(HashMap<String, String> actionFileNames) {
		this.actionFileNames = actionFileNames;
	}
	

	
	public String getResponseType() {
		return responseType;
	}

	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}

	public String getAcknowledgement(String request, String filePath){
		String responseXml=null;
		String subFolderName;
		
		subFolderName=doGetSubFolderName(request);
		String operationName=subFolderName;
		if(!StringUtils.isEmpty(subFolderName)&&subFolderName!=null){
			filePath=filePath+"/"+subFolderName;
		}else if(!StringUtils.isEmpty(operationName)&&operationName!=null){
			filePath=filePath+"/"+operationName;
		}
		if(StringUtils.isEmpty(responseXml)){
			File file = FileUtility.getResponseAsFile(filePath);
			_log.info("Simualtor is trying to apply the templates to replaces token in the response XML");
			VelocityContextManager templateManager =  new VelocityContextManager();
			responseXml=templateManager.applyTemplate(file,"acknowledge.vm");
	
		}

		
		return responseXml;
	}

	public String getResponse(String request, String filePath){

		
		String controlFilePath;
		String subFolderName;
		SimulatorContextBeanPropertUtil simulatorContextBeanPropertUtil = new SimulatorContextBeanPropertUtil();
		
		subFolderName=doGetSubFolderName(request);
		String operationName=subFolderName;//simulatorContextBeanPropertUtil.getOperationName(request);
		
		/*
		 * This will either gets the operation folder name from bean configuration xml or from the request xml.
		 */
		
		if(!StringUtils.isEmpty(subFolderName)&&subFolderName!=null){
			filePath=filePath+"/"+subFolderName;
		}else if(!StringUtils.isEmpty(operationName)&&operationName!=null){
			filePath=filePath+"/"+operationName;
		}
		
		
		LinkedHashMap<String, String> filePathMap=getFilePath(request);
		String responseXml=null;
			//appending the base filePath
		Iterator itr= filePathMap.entrySet().iterator();
		String fileName=null;
		while(itr.hasNext()){
			
			Map.Entry pairs = (Map.Entry)itr.next();
		
			fileName=pairs.getValue()+".vm";
			controlFilePath = filePath +"/"+ pairs.getValue()+".cntrl";
			_log.info("Response file path is :"+filePath);
			_log.info("Control file path is :"+controlFilePath);
			File file = FileUtility.getResponseAsFile(filePath);
			//responseXml = FileUtility.getResponseAsString(filePath);
			
			_log.info("Simualtor is trying to apply the resiliency parameters");
			ResiliencyParameterManager resiliency = new ResiliencyParameterManager();
			resiliency.applyResiliencyParameter(controlFilePath);
			
			_log.info("Simualtor is trying to apply the templates to replaces token in the response XML");
			VelocityContextManager templateManager =  new VelocityContextManager();
			responseXml=templateManager.applyTemplate(file,fileName);
			if(!StringUtils.isEmpty(responseXml)){
				 break;
			 }
		}
/*		filePath = baseFilePath +"//"+ filePath+".xml";
		String responseXml = FileUtility.getResponseAsString(filePath);*/
		if(StringUtils.isEmpty(responseXml)){
			File file = FileUtility.getResponseAsFile(filePath);
			_log.info("Simualtor is trying to apply the templates to replaces token in the response XML");
			VelocityContextManager templateManager =  new VelocityContextManager();
			responseXml=templateManager.applyTemplate(file,getDefaultFile());	
		}

		
		return responseXml;

	}
	
	public String getFilePathAvailable(String requestXml) {
		// TODO Auto-generated method stub
		String available = null;
		LinkedHashMap<String, String> filePathMap = new LinkedHashMap<String, String>();
			Map<String, String> reqParamValues = extractRequestInfo(this.reqParams,requestXml);
			Iterator itr2 = actionFileNames.entrySet().iterator();
			while(itr2.hasNext()){
				
				Map.Entry pairs1 = (Map.Entry)itr2.next();
		String[] paramList = pairs1.getValue().toString().split("\\+");

		for(String itr : paramList){
			Iterator itr1 = reqParamValues.entrySet().iterator();
				while(itr1.hasNext()){
					Map.Entry pairs = (Map.Entry)itr1.next();
					if(pairs.getKey().equals(itr)){
						available = (String) pairs.getValue();
						break;
					}
				}
				break;
			}
		break;
		}
		return available;
	}

	public LinkedHashMap<String, String> getFilePath(String requestXml) {
		// TODO Auto-generated method stub
		
		LinkedHashMap<String, String> filePathMap = new LinkedHashMap<String, String>();
			//Map<String, String> reqParamValues = extractRequestInfo(this.reqParams,requestXml);
			Map<String, String> reqParamValues = extractRequestInfo(this.reqParams,requestXml);		
			_log.info("reqParamValues map :"+reqParamValues);
			Iterator itr2 = actionFileNames.entrySet().iterator();
			while(itr2.hasNext()){
				String filePath = "";
				Map.Entry pairs1 = (Map.Entry)itr2.next();
		String[] paramList = pairs1.getValue().toString().split("\\+");
		_log.info("paramList :"+paramList);

		for(String itr : paramList){
			_log.info("itr value :"+itr);
			Iterator itr1 = reqParamValues.entrySet().iterator();
			while(itr1.hasNext()){
				Map.Entry pairs = (Map.Entry)itr1.next();
				if(pairs.getKey().equals(itr)){
					filePath = filePath+pairs.getValue().toString();
					_log.info("filePath :"+filePath);

				}
			}
		}
		//appending subfolder
	//	filePath = doGetSubFolderName(requestXml, filePath);
		
		filePathMap.put(pairs1.getKey().toString(), filePath);
			}
		System.out.println(filePathMap.toString());
		return filePathMap;
	}

	private String doGetSubFolderName(String requestXml) {
		String actionFilePathValue=null;
		
		String val="";// = actionFilePathValue;
		if (!checkForActionXpathPresence) {
			val = "_"+actionXpathValue;
		} 
		 XpathUtil xpathUtil = new XpathUtil(requestXml);
		if(!StringUtils.isBlank(actionFilePath)&&!StringUtils.startsWith(actionFilePath,"/")){
			actionFilePathValue=actionFilePath+val;
		} else if(!StringUtils.isBlank(actionFilePath)){
			actionFilePathValue =xpathUtil.getValueForNode(actionFilePath);
			
		 }
		return actionFilePathValue;
	}

	public Map<String, String> extractRequestInfo(
			HashMap<String, String> reqParams2, String requestXml) {
		// TODO Auto-generated method stub
		com.ctl.simulation.helper.XpathUtil xpath = null;		
		Map<String, String> reqParamValues = new HashMap<String, String>();		
		Iterator itr = reqParams.entrySet().iterator();
		
		System.out.println(requestXml);
		if(jsonFormat!=null && jsonFormat.toLowerCase().equals("on")) {
			//Uncomment below two lines in case of GET requests
			requestXml=requestXml.replace("<HTTPRequest>","");
			requestXml=requestXml.replace("</HTTPRequest>", "");
			try{
				//For POST requests uncommment below line
			//JSONObject jobj=new JSONObject(requestXml);
			//For GET requests uncomment below line
				JSONObject jobj=XML.toJSONObject(requestXml);
			System.out.println(jobj);
			
			while(itr.hasNext()){
				Map.Entry pairs = (Map.Entry)itr.next();
				String requestValue=null;
				requestValue=jobj.getString(pairs.getValue().toString());
				reqParamValues.put(pairs.getKey().toString(), requestValue);
			}
			//String wtn= jobj.getString("wtn");
			//String state=jobj.getString("state");
			
			}catch(JSONException e){
				e.printStackTrace();
			}
			}else{
			 xpath = new com.ctl.simulation.helper.XpathUtil(requestXml);
			 while(itr.hasNext()){
					Map.Entry pairs = (Map.Entry)itr.next();
					String requestValue=null;
					if(pairs.getValue().toString().contains("#"))
					{
					String[] reqParams = pairs.getValue().toString().split("#");

					requestValue = xpath.getAssociatedValue(requestXml, reqParams[0], reqParams[1], reqParams[2]);
					}
					else
					requestValue = xpath.retrieveElementValue((String)pairs.getValue(),requestXml);
				
					reqParamValues.put(pairs.getKey().toString(), requestValue);
				}
		}
		
		
		return reqParamValues;
	}

	public AsynchronousBean getAsynchronourBean() {
		return asynchronourBean;
	}

	public void setAsynchronourBean(AsynchronousBean asynchronourBean) {
		this.asynchronourBean = asynchronourBean;
	}

	public String getAckRequired() {
		return ackRequired;
	}

	public void setAckRequired(String ackRequired) {
		this.ackRequired = ackRequired;
	}
	
}
