/**
 * 
 */
package com.ctl.simulation.action;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ctl.simulation.helper.FileUtility;
import com.ctl.simulation.helper.SimulatorContextBeanPropertUtil;
import com.ctl.simulation.helper.XpathUtil;
import com.ctl.simulation.resiliency.ResiliencyParameterManager;
import com.ctl.simulation.velocity.VelocityContextManager;

/**
 * @author aa47173
 *
 */
public class JMSSimulatorAction {
	
	private static Log _log = LogFactory.getLog("SimulationLogger");
	
	private String queueSize;
	private String deliveryMode;
	private String defaultFile;
	private HashMap<String, String>   reqParams;
	private String actionFilePath;
	private HashMap<String, String> actionFileNames;
	public String getQueueSize() {
		return queueSize;
	}
	public void setQueueSize(String queueSize) {
		this.queueSize = queueSize;
	}
	public String getDeliveryMode() {
		return deliveryMode;
	}
	public void setDeliveryMode(String deliveryMode) {
		this.deliveryMode = deliveryMode;
	}
	public String getDefaultFile() {
		return defaultFile;
	}
	public void setDefaultFile(String defaultFile) {
		this.defaultFile = defaultFile;
	}	
	public HashMap<String, String> getReqParams() {
		return reqParams;
	}
	public void setReqParams(HashMap<String, String> reqParams) {
		this.reqParams = reqParams;
	}
	public String getActionFilePath() {
		return actionFilePath;
	}
	public void setActionFilePath(String actionFilePath) {
		this.actionFilePath = actionFilePath;
	}
	public HashMap<String, String> getActionFileNames() {
		return actionFileNames;
	}
	public void setActionFileNames(HashMap<String, String> actionFileNames) {
		this.actionFileNames = actionFileNames;
	}
	
	
	
	
	
	
	
	public String getResponse(String request, String filePath){

		
		String controlFilePath;
		String subFolderName;
		SimulatorContextBeanPropertUtil simulatorContextBeanPropertUtil = new SimulatorContextBeanPropertUtil();
		
		subFolderName=doGetSubFolderName(request);
		String operationName=subFolderName;//simulatorContextBeanPropertUtil.getOperationName(request);
		
		/*
		 * This will either gets the operation folder name from bean configuration xml or from the request xml.
		 */
		
		if(!StringUtils.isEmpty(subFolderName)&&subFolderName!=null){
			filePath=filePath+"/"+subFolderName;
		}else if(!StringUtils.isEmpty(operationName)&&operationName!=null){
			filePath=filePath+"/"+operationName;
		}
		
		
		LinkedHashMap<String, String> filePathMap=getFilePath(request);
		String responseXml=null;
			//appending the base filePath
		Iterator itr= filePathMap.entrySet().iterator();
		String fileName=null;
		while(itr.hasNext()){
			
			Map.Entry pairs = (Map.Entry)itr.next();
		
			fileName=pairs.getValue()+".vm";
			controlFilePath = filePath +"/"+ pairs.getValue()+".cntrl";
			_log.info("Response file path is :"+filePath);
			_log.info("Control file path is :"+controlFilePath);
			File file = FileUtility.getResponseAsFile(filePath);
			//responseXml = FileUtility.getResponseAsString(filePath);
			
			_log.info("Simualtor is trying to apply the resiliency parameters");
			ResiliencyParameterManager resiliency = new ResiliencyParameterManager();
			resiliency.applyResiliencyParameter(controlFilePath);
			
			_log.info("Simualtor is trying to apply the templates to replaces token in the response XML");
			VelocityContextManager templateManager =  new VelocityContextManager();
			responseXml=templateManager.applyTemplate(file,fileName);
			if(!StringUtils.isEmpty(responseXml)){
				 break;
			 }
		}
/*		filePath = baseFilePath +"//"+ filePath+".xml";
		String responseXml = FileUtility.getResponseAsString(filePath);*/
		if(StringUtils.isEmpty(responseXml)){
			File file = FileUtility.getResponseAsFile(filePath);
			_log.info("Simualtor is trying to apply the templates to replaces token in the response XML");
			VelocityContextManager templateManager =  new VelocityContextManager();
			responseXml=templateManager.applyTemplate(file,getDefaultFile());
	
		}

		
		return responseXml;

	}
	public String getFilePathAvailable(String requestXml) {
		// TODO Auto-generated method stub
		String available = null;
		LinkedHashMap<String, String> filePathMap = new LinkedHashMap<String, String>();
			Map<String, String> reqParamValues = extractRequestInfo(this.reqParams,requestXml);
			Iterator itr2 = actionFileNames.entrySet().iterator();
			while(itr2.hasNext()){
				
				Map.Entry pairs1 = (Map.Entry)itr2.next();
		String[] paramList = pairs1.getValue().toString().split("\\+");

		for(String itr : paramList){
			Iterator itr1 = reqParamValues.entrySet().iterator();
				while(itr1.hasNext()){
					Map.Entry pairs = (Map.Entry)itr1.next();
					if(pairs.getKey().equals(itr)){
						available = (String) pairs.getValue();
						break;
					}
				}
				break;
			}
		break;
		}
		return available;
	}

	public LinkedHashMap<String, String> getFilePath(String requestXml) {
		// TODO Auto-generated method stub
		
		LinkedHashMap<String, String> filePathMap = new LinkedHashMap<String, String>();
			//Map<String, String> reqParamValues = extractRequestInfo(this.reqParams,requestXml);
			Map<String, String> reqParamValues = extractRequestInfo(this.reqParams,requestXml);		
			
			Iterator itr2 = actionFileNames.entrySet().iterator();
			while(itr2.hasNext()){
				String filePath = "";
				Map.Entry pairs1 = (Map.Entry)itr2.next();
		String[] paramList = pairs1.getValue().toString().split("\\+");

		for(String itr : paramList){
			Iterator itr1 = reqParamValues.entrySet().iterator();
			while(itr1.hasNext()){
				Map.Entry pairs = (Map.Entry)itr1.next();
				if(pairs.getKey().equals(itr)){
					filePath = filePath+pairs.getValue().toString();
				}
			}
		}
		//appending subfolder
	//	filePath = doGetSubFolderName(requestXml, filePath);
		
		filePathMap.put(pairs1.getKey().toString(), filePath);
			}
		System.out.println(filePathMap.toString());
		return filePathMap;
	}

	private String doGetSubFolderName(String requestXml) {
		String actionFilePathValue=null;
		 XpathUtil xpathUtil = new XpathUtil(requestXml);
		if(!StringUtils.isBlank(actionFilePath)&&!StringUtils.startsWith(actionFilePath,"/")){
			actionFilePathValue=actionFilePath;
		} else if(!StringUtils.isBlank(actionFilePath)){
			actionFilePathValue =xpathUtil.getValueForNode(actionFilePath);
			
		 }
		return actionFilePathValue;
	}

	public Map<String, String> extractRequestInfo(
			HashMap<String, String> reqParams2, String requestXml) {
		// TODO Auto-generated method stub
		com.ctl.simulation.helper.XpathUtil xpath = new com.ctl.simulation.helper.XpathUtil(requestXml);
		
		Map<String, String> reqParamValues = new HashMap<String, String>();
		

		Iterator itr = reqParams.entrySet().iterator();
		while(itr.hasNext()){
			Map.Entry pairs = (Map.Entry)itr.next();
			String requestValue=null;
			if(pairs.getValue().toString().contains("#"))
			{
			String[] reqParams = pairs.getValue().toString().split("#");

			requestValue = xpath.getAssociatedValue(requestXml, reqParams[0], reqParams[1], reqParams[2]);
			}
			else
			requestValue = xpath.retrieveElementValue((String)pairs.getValue(),requestXml);
		
			reqParamValues.put(pairs.getKey().toString(), requestValue);
		}
		return reqParamValues;
	}

}
