package com.ctl.simulation.thread;

import com.ctl.simulation.helper.SimulatorContext;

public class SimulatorCtxThreadLocal {
	
		
		public static final ThreadLocal simulatorThreadLocal = new ThreadLocal(); 
		
		public static void set(SimulatorContext simulatorCtx) {
			simulatorThreadLocal.set(simulatorCtx);
		}
		
		public static void unset() {   
			simulatorThreadLocal.remove();
		}
		 
		public static SimulatorContext get() {   
			return (SimulatorContext) simulatorThreadLocal.get();
		}

}