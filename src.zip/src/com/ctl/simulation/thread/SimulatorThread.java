package com.ctl.simulation.thread;

import com.ctl.simulation.helper.SimulatorContext;
import com.ctl.simulation.simulator.ISimulator;

public class SimulatorThread extends Thread {
	
	ISimulator iSimulator;
	
	Object req;
	
	String beanId;
	  
	public SimulatorThread(ISimulator iSimulator,Object req, String beanId) {
		super();
		this.iSimulator = iSimulator;
		this.req=req;
		this.beanId =beanId;
	}

	public void run() {     
		SimulatorContext context = new SimulatorContext();
		context.setRequestObj(this.req);
		context.setBeanId(beanId);
		SimulatorCtxThreadLocal.set(context); 
		SimulatorCtxThreadLocal.get().setResponse((String) iSimulator.simulate(context.getRequestObj()));
	 
	}
	

}
