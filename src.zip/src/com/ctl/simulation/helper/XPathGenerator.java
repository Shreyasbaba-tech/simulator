package com.ctl.simulation.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

public class XPathGenerator extends DefaultHandler{

	
	private String xPath = "/";
    private XMLReader xmlReader;
    private XPathGenerator parent;
    private StringBuilder characters = new StringBuilder();
    private Map<String, Integer> elementNameCount = new HashMap<String, Integer>();
    private String temp;
    private  List<String> xpathList;

	
	public XPathGenerator() {
		
	}
	
    public XPathGenerator(XMLReader xmlReader,List<String> xpathList) {
        this.xmlReader = xmlReader;
        this.xpathList=xpathList;
    }

    private XPathGenerator(String xPath, XMLReader xmlReader, XPathGenerator parent,List<String> xpathList) {
        this(xmlReader,xpathList);
        this.xPath = xPath;
        this.parent = parent;
    }
  
    public void startElement(String uri, String localName,
        String qName, Attributes attributes)
    throws SAXException {

    //	System.out.println("----Inside Start Element----");
    	Integer count = elementNameCount.get(qName);
    	String childXPath=null;
    	//System.out.println(elementNameCount.get(qName)+"-->"+qName);
        if(count==null) {
            count = 1;
        } else {
            count++;
        }
        elementNameCount.put(qName, count);
        if(count>1){ 
     childXPath = xPath + "/" + qName + "[" + count + "]";
        }else{
        	childXPath = xPath + "/" + qName;
        }

        int attsLength = attributes.getLength();
        for(int x=0; x<attsLength; x++) {
         //   System.out.println(childXPath + "[@" + attributes.getQName(x) + "='" + attributes.getValue(x) + "']");
          temp=childXPath + "[@" + attributes.getQName(x) + "='" + attributes.getValue(x) + "']";
         
            //System.out.println(xpath);
             xpathList.add(temp);
           // System.out.println("inside start-->"+xpathList.size());
          // System.out.println("xpath in d list-->"+xpathList.get(x));
                     
        }

        XPathGenerator child = new XPathGenerator(childXPath, xmlReader, this,this.xpathList);
        xmlReader.setContentHandler(child);

    }

   

    
	

	public String getTemp() {
		return temp;
	}

	public void setTemp(String temp) {
		this.temp = temp;
	}

	public  List<String> getXpathList() {
		//System.out.println("inside get");
		return xpathList;
	}

	public  void setXpathList(List<String> xpathList) {
		this.xpathList = xpathList;
	}

	public void endElement(String uri, String localName, String qName)
    throws SAXException {
	//	System.out.println("----Inside End Element-----");
    	 String value = characters.toString().trim();
//         if(value.length() > 0) {
//         //    System.out.println("inside end elem--->"+xPath + "='" + characters.toString() + "'");
//             temp=xPath + "='" + characters.toString() + "'";
//             xpathList.add(temp);
//             
//         //    System.out.println("size inside end--->"+xpathList.size());
//       //    System.out.println("xpath list in end elem-->"+xpathList.get(xpathList.size()-1));
//             
//         }
         xmlReader.setContentHandler(parent);

  //      System.out.println("end element      : " + qName);
    }

    public void characters(char ch[], int start, int length)
    throws SAXException {
    	
    	characters.append(ch, start, length);

  //     System.out.println("start characters : " +
         //  new String(ch, start, length));
    }
	

}
