package com.ctl.simulation.helper;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

public class XpathGenerationUtil extends DefaultHandler{


	private String xpath="";
	private  List<String> xpathList=new ArrayList<String>();
	
	
	
	
	public XpathGenerationUtil() {
		
	}
	
	public List<String> retrieveXpaths(File file){
		DocumentBuilderFactory documentBuilderFactory;
		DocumentBuilder documentBuilder;
		Document document;
		try{	
		     documentBuilderFactory=DocumentBuilderFactory.newInstance(); 
			 documentBuilder=documentBuilderFactory.newDocumentBuilder();
			 document=documentBuilder.parse(file);
			 generateXpath(document.getDocumentElement(),xpath,xpathList);
			 for(String xp:xpathList){
				System.out.println("xpath == "+xp);
			 }
		}catch(Exception e){
			e.printStackTrace();
		}
	return xpathList;
	}
	
	public List<String> retrieveXpaths(String file){
		DocumentBuilderFactory documentBuilderFactory;
		DocumentBuilder documentBuilder;
		Document document;
		try{	
		     documentBuilderFactory=DocumentBuilderFactory.newInstance(); 
			 documentBuilder=documentBuilderFactory.newDocumentBuilder();
			 document=documentBuilder.parse(new InputSource(new ByteArrayInputStream(file.getBytes("utf-8"))));
			 generateXpath(document.getDocumentElement(),xpath,xpathList);
			 for(String xp:xpathList){
				System.out.println("xpath == "+xp);
			 }
		}catch(Exception e){
			e.printStackTrace();
		}
	return xpathList;
	}

	 
	 
	public void generateXpath(Node root,String xpath,List<String> xpathList){
		 NodeList childList=root.getChildNodes();
		 xpath=xpath+"/"+root.getNodeName();
		 if(xpath.contains("soapenv:Envelope"))
		 xpath=ignoreElement("soapenv:Envelope", xpath);
		
		 xpathList.add(xpath);
		if(childList==null){
			return;
		}
		else{
			if(childList.getLength()==1){
				if(xpath.contains("soapenv:Envelope"))
				xpath=ignoreElement("soapenv:Envelope", xpath);
				
				System.out.println(xpath);
				xpathList.add(xpath);
				
			}
			 for(int i=0;i<childList.getLength();i++){
				 Node tempNode=childList.item(i);
				 
				 if(tempNode.getNodeType()==Node.ELEMENT_NODE){
						
				 generateXpath(tempNode,xpath,xpathList);
				 }

				 }
		 }
	 
	 }

	
String ignoreElement(String element,String xpath)
{
	xpath=xpath.replace("/"+element, "");
	return xpath;
	
}
	
	
}
