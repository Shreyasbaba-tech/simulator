package com.ctl.simulation.helper;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.namespace.QName;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XPathReader {

	private String xmlFile;
	private Document xmlDocument;
	private XPath xPath;

	public XPathReader(String xmlFile) {
		this.xmlFile = xmlFile;
		initObjects();
	}

	private void initObjects() {
		try {
			xmlDocument = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder().parse(xmlFile);
			xPath = XPathFactory.newInstance().newXPath();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (SAXException ex) {
			ex.printStackTrace();
		} catch (ParserConfigurationException ex) {
			ex.printStackTrace();
		}
	}

	public Object read(String expression, QName returnType) {
		try {
			XPathExpression xPathExpression = xPath.compile(expression);
			return xPathExpression.evaluate(xmlDocument, returnType);
		} catch (XPathExpressionException ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public static void traverse(NodeList rootNode) {
		for (int index = 0; index < rootNode.getLength(); index++) {
			Node aNode = rootNode.item(index);
			if (aNode.getNodeType() == Node.ELEMENT_NODE) {
				NodeList childNodes = aNode.getChildNodes();
				if (childNodes.getLength() > 0) {
					System.out.println("Node Name-->"
							+ aNode.getNodeName().trim());
					System.out.println("Node Value-->"
							+ aNode.getTextContent().trim());
				}
				traverse(aNode.getChildNodes());
			}
		}
	}

	public static void main(String[] args) {

		/*
		 * XPathReader reader = new XPathReader(
		 * "C:\\Documents and Settings\\vt0060557\\Desktop\\test.xml"); String
		 * expression =
		 * "/WorkflowGetDataProductDetailResponse/QwestDotNetCustomer/QwestDotNetAccount/RequestedQwestDotNetProduct/WebProductInfo/USOC"
		 * ; // System.out.println(reader.read(expression,XPathConstants.STRING)
		 * + "\n");
		 * 
		 * traverse((NodeList) reader.read(expression, XPathConstants.NODESET));
		 */
		//String TN=xmlParser("TN");
		//System.out.println(TN);
	}

	public static String xmlParser(String lookUpParam, String xmlString) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		// Use the factory to create a builder
		try {
			String s="";
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
			//Document doc = builder.parse(filePath);
			// Get a list of all elements in the document
			//NodeList list = doc.getElementsByTagName("ARTISInfoObject");
			NodeList list = doc.getElementsByTagName(lookUpParam);
			for (int i = 0; i < list.getLength(); i++) {
				// Get element

				Element element = (Element) list.item(i);
				if (element != null && element.hasChildNodes()) {
					NodeList li = element.getChildNodes();
					for (int j = 0; j < li.getLength(); j++) {
						Node el = li.item(j);

						if (el != null && el.hasChildNodes())
						{
							s+=el.getFirstChild().getNodeValue().trim();
							
						}
						else
						{
							s+=el.getNodeValue().trim();
						}
							
					}
				}
			}
			//System.out.println("next -->"+ s);
			return s;

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static String getFileAsString(File file){ 
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		StringBuffer sb = new StringBuffer();
		try {
		fis = new FileInputStream(file);
		bis = new BufferedInputStream(fis);
		dis = new DataInputStream(bis);

		while (dis.available() != 0) {
		sb.append( dis.readLine() +"\n");
		}
		fis.close();
		bis.close();
		dis.close();

		} catch (FileNotFoundException e) {
		e.printStackTrace();
		} catch (IOException e) {
		e.printStackTrace();
		}
		return sb.toString();
		}


}
