package com.ctl.simulation.helper;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


/**
 *
 *@author sgolla
 */

public class XpathUtil {
	private String xml;
	private String rootNodeName;
	private String xpathValue;
	private Document doc;
	private String nodeValue;
	 
	public XpathUtil() {
	}
	
	public XpathUtil(String xml) {
		super();
		this.xml = xml;
		
		try {
			DOMParser parser = new DOMParser();
			InputSource inputSource = new InputSource(new java.io.StringReader((String) this.xml));
			parser.parse(inputSource);
			
			doc = parser.getDocument();
		    Node node = doc.getDocumentElement();
		    
		    String rootNodeArray[] = null; 
		    String rootNode = null;
		    if (node.getNodeName().contains(":")) {
		    	rootNodeArray = node.getNodeName().split(":");
		    	rootNode = (String) rootNodeArray[1];
			} else {
				rootNode = node.getNodeName();
			}
		    this.setRootNodeName(rootNode);
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args){
		
	//	String reqXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><msg> <head>  <Client>dummy</Client>  <Source>dummy</Source>  <Destination>dummy</Destination> </head> <body>  <RetrieveLocation>	   <Key>8035440010001196</Key>	   <KeyType>AN</KeyType>	  </RetrieveLocation>	 </body>	</msg>";
		String actionFilePathValue=null;
	
		XpathUtil util = new XpathUtil();
		//String reqXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Body><accountDataRequest xmlns=\"http://www.centurytel.com/AccountDataWS\"><securityInfo xmlns=\"\"><application>RIB</application><environment>DEPLOYI1</environment><operatorId>1000319</operatorId><password>unix12t</password></securityInfo><accountNumber xmlns=\"\">300070000</accountNumber><forceByProductId xmlns=\"\">false</forceByProductId><filterAccounts xmlns=\"\">Active</filterAccounts></accountDataRequest></soapenv:Body></soapenv:Envelope>";
		//String reqXML="<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Header><ns1:ServiceEventContext xmlns:ns1=\"http://www.qwest.com/ngs/afprofilews/v1\"> <ns1:ProviderID></ns1:ProviderID> <ns1:EventTime>2011-10-19T13:08:53.637Z</ns1:EventTime></ns1:ServiceEventContext></soapenv:Header> <soapenv:Body>  <ReadServiceProfile xmlns=\"http://www.qwest.com/ngs/afprofilews/v1\">   <ReadServiceProfile>    <AccountID>7209959445</AccountID>    <ServiceNameType>CallLogs</ServiceNameType>   </ReadServiceProfile>  </ReadServiceProfile> </soapenv:Body></soapenv:Envelope>";
	//	String reqXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><msg> <head>  <Client>dummy</Client>  <Source>dummy</Source>  <Destination>dummy</Destination> </head> <body>  <RetrieveLocation>	   <Key>8035440010001196</Key>	   <KeyType>AN</KeyType>	  </RetrieveLocation>	 </body>	</msg>";
     
      // String reqXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <soapenv:Envelope> <soapenv:Header> <ns1:ServiceEventContext> <ns1:ProviderID></ns1:ProviderID> 	<ns1:EventTime>2011-10-19T13:08:53.637Z</ns1:EventTime>	</ns1:ServiceEventContext>	</soapenv:Header>	<soapenv:Body>		<ReadServiceProfile>				<AccountID>7209959445</AccountID>				<ServiceNameType>CallLogs</ServiceNameType>			</ReadServiceProfile>			<ReadServiceProfile>				<AccountID>734673575375</AccountID>				<ServiceNameType>xyz</ServiceNameType>			</ReadServiceProfile>	</soapenv:Body></soapenv:Envelope>";
		//actionFilePathValue =util.retrieveElementValue("/soapenv:Envelope/soapenv:Header/ns1:ServiceEventContext/ns1:EventTime",reqXML);	
		//actionFilePathValue=reader.xmlParser("/soapenv:Envelope/soapenv:Body/ReadServiceProfile/ReadServiceProfile/AccountID",reqXML);
		//String value=util.getAssociatedValue(reqXML,"/soapenv:Body/ReadServiceProfile/ReadServiceProfile/AccountID","734673575375","/soapenv:Body/ReadServiceProfile/ReadServiceProfile/ServiceNameType");
		//System.out.println("done");
		
	String reqXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:icl=\"http://www.ICLNBI.com/ICLNBI_V2.00.xsd\">   <soapenv:Header/>   <soapenv:Body> <CreateDeviceRequest>	<MessageElements>		<MessageAddressing>			<from>DSP</from>			<to>ICL</to>			<replyTo>DSP</replyTo>			<messageID>DSP12345</messageID>			<action>CreateDevice</action>			<timestamp>2008-09-29T07:19:45</timestamp>			<transactionID>1234</transactionID>			<serviceName>CreateDevice</serviceName>			<serviceVersion>3.0</serviceVersion>			<userId/>	<password/>  </MessageAddressing>	</MessageElements></CreateDeviceRequest>   </soapenv:Body></soapenv:Envelope>";	
		//File f = new File("C:\\Users\\aa49473\\Desktop\\soap_xmls\\soap_xmls\\NICProvDeviceCreateRequest.xml") ;
		//String xmlString = FileUtility.readXmlAsString(f);
		//System.out.println(xmlString);
		String val = util.getAssociatedValue(reqXML, "/soapenv:Body/tns:CreateDeviceRequest/MessageElements/MessageAddressing/from", "DSP", "/soapenv:Body/tns:CreateDeviceRequest/MessageElements/MessageAddressing/to");
				//Map<String , String> xpathMap=util.retrieveXpathsMap(list);
		//System.out.println(actionFilePathValue);
	/*	
		XpathUtil util = new XpathUtil();
		util.retrieveXpathsList("");*/
	}


	public boolean isOperation(String nodeName, String Value){
	   if(nodeName != null ){
		   return true;
	   }
		return false;
	}
	
	public String getValueForNode(String nodeName){
		try{
			XPath xpath = XPathFactory.newInstance().newXPath();
			xpath.setNamespaceContext(new NameSpaceHandler(doc,false));
			InputSource inputSource = new InputSource(new java.io.StringReader((String) xml));
			xpathValue =(String)(xpath.evaluate(nodeName,inputSource,XPathConstants.STRING));
		}catch (XPathExpressionException e) {
			e.printStackTrace();
		}
		return xpathValue;
	}
	
	public static String xmlParser(String lookUp, String reqXml){
		 XpathUtil xpathUtil = new XpathUtil(reqXml);
		 return xpathUtil.getValueForNode(lookUp);
		
		
	}
	
	
	public String retrieveElementValue(String lookUpParam, String xmlString) {
		String[] stringArray=null;
		String result =new String();
		int count=0;
		stringArray=StringUtils.split(lookUpParam, "/");
		Document doc;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.parse(new InputSource(new StringReader(xmlString)));
			NodeList list = doc.getElementsByTagName(stringArray[0]);
			parseNodeListForChild(list,stringArray,count,result);
			return getNodeValue();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return "";
	}
	
	public List<String> retrieveXpathsList(File file){
		XpathGenerationUtil generator = new XpathGenerationUtil();
		return generator.retrieveXpaths(file);
	}
	
	public List<String> retrieveXpathsList(String file){

		XpathGenerationUtil generator = new XpathGenerationUtil();

		return generator.retrieveXpaths(file);

		}

	
	public Map<String,String> retrieveXpathsMap(List<String> list){
		 Map<String, String> xpathMap=new HashMap<String, String>();
		 
		 for(String ele:list)
		 {
			 String key=ele.substring(ele.lastIndexOf('/')+1,ele.length());
			// System.out.println("key= "+key);
			 if(checkForDuplicacy(key, list))
			 {
				 String subEle=ele.substring(0, ele.lastIndexOf('/'));
				 key=key.replace("/", subEle.substring(subEle.lastIndexOf('/'),subEle.length())+'/');
			     //System.out.println("duplicaty "+key);
			 }
			System.out.println(key+" = "+ele);
			 xpathMap.put(key, ele);
		 }
		 
		 
		return xpathMap;
	}
	
	public Map<String,String> retrieveAllXpathsMap(List<String> list){
		 Map<String, String> xpathMap=new HashMap<String, String>();
		 
		 for(String ele:list)
		 {
			 String arr[] = ele.split("/");
			 for (int i = 1; i < arr.length; i++) {
				
				 String key="";
				 if(arr[i].lastIndexOf('/')!=-1)
					 key = arr[i].substring(0, arr[i].lastIndexOf('/'));
				 else
					 key = arr[i];
				 // System.out.println("key= "+key);
				 if(checkForDuplicacy(key, list))
				 {
					 String subEle=ele.substring(0, ele.lastIndexOf('/'));
					 key=key.replace("/", subEle.substring(subEle.lastIndexOf('/'),subEle.length())+'/');
					 //System.out.println("duplicaty "+key);
				 }
				 System.out.println(key+" = "+ele);
				 xpathMap.put(key, ele);
			}
		 }
		 
		 
		return xpathMap;
	}
	
	public boolean checkForDuplicacy(String key,List<String> list)
	{
		boolean result=false;
		int occ=0;
		
		for(String ele:list)
		 {
			if(!StringUtils.isBlank(ele) && ele.length()>0 )
			{
				String key1=ele.substring(ele.lastIndexOf('/'),ele.length());
		 //   System.out.println(key+"="+key1);
				if(key.equals(key1))
				{
				occ++;
				}
			}
		 }
		 //System.out.println("for "+key+ " result= "+result);
		if(occ>1)
		{
			result=true;
		}
		return result;
	}
	
	
	
	private void parseNodeListForChild(NodeList list, String[] tagName,int count, String result) {
		count++;
		Element element=null;
		NodeList nodeList=null;
		if(list!=null &&list.getLength()>0){
			element =(Element)list.item(0);
			if (element != null && element.hasChildNodes()&&count<tagName.length) {
				nodeList=element.getElementsByTagName(tagName[count]);
				parseNodeListForChild(nodeList,tagName,count,result);
			}else{
				setNodeValue(element.getTextContent());
			}
			
		}
	
	}
	
	

	public String getValueByXpath(File file,String xpath){
		System.out.println("INside Util "+xpath);
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder;
		Document doc = null;
		XPathExpression expr = null;
		Object result = null;
		try {
			builder = factory.newDocumentBuilder();
			doc = builder.parse(file);
			// Create a XPathFactory
			XPathFactory xFactory = XPathFactory.newInstance();
			// Create a XPath object
			XPath xpath1 = xFactory.newXPath();
			System.out.println("/"+xpath+"/text()");
			expr = xpath1.compile("/"+xpath+"/text()");
			result = expr.evaluate(doc, XPathConstants.STRING);
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Result "+(String)result);
		return (String)result;
	}

	public String getValueByXpath(String fileText,String xpath){
		File file = null;
		System.out.println("INside Util "+xpath);
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder;
		Document doc = null;
		XPathExpression expr = null;
		Object result = null;
		try {
			file = new File("temp.txt");
			BufferedWriter output = new BufferedWriter(new FileWriter(file));
			output.write(fileText);
			output.close();
			
			builder = factory.newDocumentBuilder();
			doc = builder.parse(file);
			// Create a XPathFactory
			XPathFactory xFactory = XPathFactory.newInstance();
			// Create a XPath object
			XPath xpath1 = xFactory.newXPath();
			System.out.println("/"+xpath+"/text()");
			expr = xpath1.compile("/"+xpath+"/text()");
			result = expr.evaluate(doc, XPathConstants.STRING);
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Result "+(String)result);
		return (String)result;
	}

public String getAssociatedValue(String xmlString,String keyXpath,String key,String valueXpath)
	{
		File xmlFile = new File("tempXmlFile.xml");
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();   
		  
        DocumentBuilder builder;   
        
            try {
				builder = factory.newDocumentBuilder();
		           // Use String reader   
	            Document document = builder.parse( new InputSource(   
	                    new StringReader( xmlString ) ) );   
	  
	            TransformerFactory tranFactory = TransformerFactory.newInstance();   
	            Transformer aTransformer = tranFactory.newTransformer();   
	            Source src = new DOMSource( document );   
	            Result dest = new StreamResult(xmlFile);   
	            
	            
	            aTransformer.transform( src, dest );   
			} catch (ParserConfigurationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}   
  
 
		String value = "";
		//List<String> list = retrieveXpathsList(xmlString);
		System.out.println("keyXpath = "+ keyXpath);
		System.out.println("key = "+key);
		System.out.println("valueXpath = " + valueXpath);
		String commonXpath = getCommonXpath(keyXpath,valueXpath);
		commonXpath = commonXpath.substring(0, commonXpath.lastIndexOf("/"));
		System.out.println("commonPath = " +commonXpath);
		String lastCommonElement = commonXpath.substring(commonXpath.lastIndexOf("/")).replace("/","");
		System.out.println("lastCommonElement = " + lastCommonElement);

		Document doc,doc1;
			
			try {
				InputStream inputStream = new FileInputStream(xmlFile);

				builder = factory.newDocumentBuilder();
				doc = builder.parse(inputStream);
				NodeList list = doc.getElementsByTagName(lastCommonElement);
				
				/*XPathFactory xPathfactory = XPathFactory.newInstance();
				XPath xpath = xPathfactory.newXPath();
				XPathExpression keyXpathExpr = xpath.compile(keyXpath);
				NodeList nl = (NodeList) keyXpathExpr.evaluate(doc, XPathConstants.NODESET);*/
				
				for(int i=0;i<list.getLength();i++)
				{
					Node n = list.item(i);
					System.out.println(n.getNodeName());
					
					//evaluate xpath value of keyXpath
					doc1 = builder.parse(new InputSource(new StringReader("<?xml version=\"1.0\" encoding=\"UTF-8\"?>  <Body></Body>")));
					Node node = doc1.getElementsByTagName("Body").item(0);
					//node.appendChild(n);
					node.appendChild(doc1.adoptNode(n.cloneNode(true)));
					
					XPathFactory xPathfactory = XPathFactory.newInstance();
					XPath xpath = xPathfactory.newXPath();
					XPathExpression keyXpathExpr = xpath.compile("/Body/"+lastCommonElement+keyXpath.replace(commonXpath, ""));
					XPathExpression valueXpathExpr = xpath.compile("/Body/"+lastCommonElement+valueXpath.replace(commonXpath, ""));
					String keyName= keyXpathExpr.evaluate(doc1);
						System.out.println("keyName = "+keyName);
						if(key.equalsIgnoreCase(keyName))
						{
							
							String val= valueXpathExpr.evaluate(doc1);
							System.out.println("val = "+val);
							value = val;
							break;
						}
						
					
				}
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (XPathExpressionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
		return value;
	}
	
	public String getCommonXpath(String keyXpath,String valueXpath)
	{
		String common="";
		String[] kPathList = keyXpath.split("/");
		String[] vPathList = valueXpath.split("/");
		for( int i=0;i < minOf(kPathList.length,vPathList.length);i++)
		{
			//System.out.println("numbOfIterations= "+i);
			if(kPathList[i].equalsIgnoreCase(vPathList[i]))
			{
				common +=  kPathList[i] +"/";
			}
		}
		
		return common;
	}
	
	public int minOf(int x,int y)
	{
		if(x < y)
			return x;
		else
			return y;
	}
	public String getNodeValue() {
		return nodeValue;
	}

	public void setNodeValue(String nodeValue) {
		this.nodeValue = nodeValue;
	}
	
	
	public String getRootNodeName() {
		return rootNodeName;
	}

	public void setRootNodeName(String rootNodeName) {
		this.rootNodeName = rootNodeName;
	}

	public String getXml() {
		return xml;
	}

	public void setXml(String xml) {
		this.xml = xml;
	}

}
