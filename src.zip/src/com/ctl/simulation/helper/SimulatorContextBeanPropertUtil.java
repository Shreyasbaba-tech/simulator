package com.ctl.simulation.helper;
//Input for SimulatorContextBeanPropertUtil class should be AddServiceInfo object
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.ctl.app.virtual.AddServiceInfo;
import com.ctl.simulation.http.RxContextPathDeploymentUtil;
import com.opensymphony.xwork2.util.finder.Test;

public class SimulatorContextBeanPropertUtil {
	public static String httpPrefix="";
	public static String soapPrefix="";
    final public static String busSuffix="CUSTSI.PROBH119";
    public final static String BUS_SERVICE_RVD="rvd://;239.85.2.3:8523/omahft3:8523";
    
    private String beanId;
    
	private XpathUtil xpathUtil;
	
	public SimulatorContextBeanPropertUtil() {
		if(System.getProperty("os.name").startsWith("Windows")){
			httpPrefix= "http://10.140.49.236:8080/virtualApp/services/http/";
			soapPrefix="http://10.140.49.236:8080/virtualApp/services/soap/";
		}else{
			httpPrefix = "http://rxsim01-dev.dev.intranet:8080/virtualApp/services/http/";
			soapPrefix="http://rxsim01-dev.dev.intranet:8080/virtualApp/services/soap/";
		}
       this.xpathUtil=new XpathUtil();	
	}

public String getServiceName(AddServiceInfo serviceInfo){
	
	return serviceInfo.getServiceName();
	
}


public  String getOperationName(File sampleFile){
	String operationName=null;
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder;
	try {
		dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(sampleFile);
	
		Node next=doc.getDocumentElement();
		
		if(next.getNodeName().equals("soapenv:Envelope") ||
				next.getNodeName().equals("soap:Envelope") ||next.getNodeName().equals("SOAP-ENV:Envelope")  )  
		{
			if(next.getNodeName().equals("soapenv:Envelope"))
				next=doc.getElementsByTagName("soapenv:Body").item(0);
			
			else if(next.getNodeName().equals("soap:Envelope"))
				next=doc.getElementsByTagName("soap:Body").item(0);
			
			else if(next.getNodeName().equals("SOAP-ENV:Envelope"))
				next=doc.getElementsByTagName("SOAP-ENV:Body").item(0);
			
			if(next!=null){
				next=next.getFirstChild();
							
				while( next.getNodeType()!=1 ) //node type==1 for element type// rest all types should be ignored
				{
					
					next=next.getNextSibling();
					System.out.println("In soap body "+next.getNodeName()); 
				}
			}
					
		}
		
		operationName=next.getNodeName();
		
		

	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SAXException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

	return operationName;
	
}


public  String getOperationName(String sampleFile){
	String operationName=null;
	InputStream stream = null;
	try {
		stream = new ByteArrayInputStream(sampleFile.getBytes("UTF-8"));
	} catch (UnsupportedEncodingException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder;
	try {
		dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(stream);
	
		Node next=doc.getDocumentElement();
		
		if(next.getNodeName().equals("soapenv:Envelope") ||
				next.getNodeName().equals("soap:Envelope") )  
		{
		
			next=doc.getElementsByTagName("soapenv:Body").item(0);
			if(next!=null){
				next=next.getFirstChild();
							
				while( next.getNodeType()!=1 ) //node type==1 for element type// rest all types should be ignored
				{
					
					next=next.getNextSibling();
					System.out.println("In soap body "+next.getNodeName()); 
				}
			}
					
		}
		
		operationName=next.getNodeName();
		
		

	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SAXException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

	return operationName;
	
}
/*
public Map<String,String> getRequestParametrMap(AddServiceInfo serviceInfo){
	List<String> selectedXpaths =serviceInfo.getSelectedXpaths();
	
	
	
	 * 
	 * <property name="reqParams">
						<map>
							<entry key="req1"
								value="//accountNumber" />
								<entry key="req2"
								value="//accountNumber" />
									<entry key="req3"
								value="//accountNumber" />
						</map>
					</property>
					
	
	
	return null;
	
}

 */

public String getDefaultFileName(AddServiceInfo serviceInfo){
	return "default.vm";
	
}

/*
public Map<String,String> getActionFileNameMap(AddServiceInfo serviceInfo){
	/*
	 * ExactFileName, partFileName
	 * 
	 * 	<property name="actionFileNames">
						<map>
							<entry key="exactFileName" value="req1+req2+req3" />
							<entry key="partFileName1" value="req1+req2" />
							<entry key="partFileName2" value="req1" />
							
						</map>
					</property>
	return null;
}

*/
/*

public String getActionFilePath(AddServiceInfo serviceInfo){
	List<String> list=null;
	list=xpathUtil.retrieveXpathsList(FileUtility.retrieveFileContent(serviceInfo.getFile()));
	/*
	 * If (list.get[0] equls soap xml)
	 * (list.get[0].toArray)[2] 
	 * Else
	 * list.toArray[0]
	 * 
	return null;
	
}

*/

public String getSimulatorFilePath(AddServiceInfo serviceInfo){
	return serviceInfo.getApplicationId()+"/"+serviceInfo.getServiceName();
}

public String getServiceLocation(String serviceName,String serviceType,String appId){
		String result=null;
		if(serviceType.equals("HttpService"))
		{
			result=getHttpprefix()+getBeanId();
		}
		else if(serviceType.equals("WebService"))
		{
			result=soapPrefix+getBeanId();
		}else{
			result=getBeanId();
		}
	
		return result;
	}

public String getBeanId() {
	return beanId;
}

public void setBeanId(String serviceName,String serviceType,String appId,String operationName) {
	
	String result=null;
	if(serviceType.equals("HttpService"))
	{
		result=appId+"_"+serviceName;//+"_"+operationName+"_"+System.currentTimeMillis();
	}
	else if(serviceType.equals("WebService"))
	{
		result=appId+"_"+serviceName;//+"_"+operationName+"_"+System.currentTimeMillis();
	}
	else if(serviceType.equals("JMS"))
	{
		result=appId+"_"+serviceName+"_"+operationName;//+"_"+System.currentTimeMillis();
	}else{
		result="Q."+appId+"."+serviceName +"."+operationName+"."+busSuffix+"."+System.currentTimeMillis();
	}
	this.beanId = result;
}

public static Properties getVitualConfigProperties(){
	String contextPath = "";
	RxContextPathDeploymentUtil util = new RxContextPathDeploymentUtil();
	contextPath = util.getConfigItPath().replace("it","VirtualConfig.properties" );
	//contextPath=contextPath+"config/VirtualConfig.properties";
	
	Properties pro = new Properties();
	try {
		FileInputStream f = new FileInputStream(contextPath);
		pro.load(f);
	} catch (Exception e) {
		
	}
	
	return pro;		
	
}

public static String getResponseFilePath(){
	return getVitualConfigProperties().getProperty("ResponeFilePath");
	
}

public static String getHttpprefix() {
	return httpPrefix;
}

public static String getSoapprefix() {
	return soapPrefix;
}

public static String getBussuffix() {
	return busSuffix;
}
}
