package com.ctl.simulation.helper;

import java.io.StringWriter;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.tools.VelocityFormatter;

public class TemplateEngine {

	public static void main(String[] args) throws Exception {

		Map map = new HashMap();
		map.put("t1", "t11");
		map.put("t2", "t22");
		map.put("t3", "t33");
		
		
	    VelocityContext context = new VelocityContext();
	    context.put("args", map);

	    String template = "args = #foreach ($arg in $args) $arg #end";

	    StringWriter writer = new StringWriter();

	    Velocity.init();
//	    Velocity.evaluate(context,
//	                      writer,
//	                      "LOG",  // used for logging
//	                      template);

	    System.out.println(writer.getBuffer());
	    
	  
	    Date today = new Date();

	    context.put("formatter", new VelocityFormatter(context));
	    context.put("today", today);

	    Velocity.evaluate(context, writer, "TEST", "today is $formatter.formatShortDate($today)");

	    DateFormat format = DateFormat.getDateInstance(DateFormat.SHORT);
	    String expected =  "today is " + format.format(today);
	    System.out.println("Expected: "+expected);
	    System.out.println("Actual: "+writer.getBuffer().toString());
	  //  assertEquals(expected, writer.getBuffer().toString());

	  }

}
