package com.ctl.simulation.helper;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;


public class FileUtility {

	public static String getResponseAsString(String filePath){
		
		/*int i = filePath.lastIndexOf("//");
		String directoryPath= filePath.substring(0, i);
		final String fileName = filePath.substring(i+2, filePath.length()).replace(".xml", "");
		File dir = new File(directoryPath);
		File file=null;
		FileFilter filter = new FileFilter() {

			public boolean accept(File file) {
				// TODO Auto-generated method stub
				if(file.getName().startsWith(fileName)){
					return true;
				}
				return false;
			}
		};
		
		File[] files = dir.listFiles(filter);
		int numberOfFiles=files.length;

		if(numberOfFiles!=0){
			if(numberOfFiles>1){
				long lastMod = Long.MIN_VALUE;
				File choice = null;
				for (File fileIterator : files) {
					if (fileIterator.lastModified() > lastMod) {
						choice = fileIterator;
						lastMod = fileIterator.lastModified();
					}
				}
				file=choice;

			}
			else{
				return XPathReader.getFileAsString(files[0]);
			}
		}
		else{
			file = new File(filePath);
			if(!file.exists()){
				return "";
			}
		}*/
		 byte[] buffer = new byte[(int) new File(filePath).length()];
		    FileInputStream f;
			try {
				f = new FileInputStream(filePath);
				f.read(buffer);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("NO FILE FOUND FOR "+ filePath);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("IO Exception");
			}
		    
		    return new String(buffer);

		
		//return XPathReader.getFileAsString(file);
	}

	
	public static File getResponseAsFile(String filePath){
		File file = new File(filePath);
		return file;
	}
	
	public static String retrieveFileContent(File file){
	    int ch;
	    StringBuffer strContent = new StringBuffer("");
	    FileInputStream fin = null;
	    try {
		     fin = new FileInputStream(file);
		     while ((ch = fin.read()) != -1)
		       strContent.append((char) ch);
		     fin.close();
		    } catch (Exception e) {
		     System.out.println(e);
	    }
		return strContent.toString();
	}
	
	public static String readXmlAsString(File fXmlFile){
		
		    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		    DocumentBuilder dBuilder;
		    String content="";
			try {
				dBuilder = dbFactory.newDocumentBuilder();
				  Document doc = dBuilder.parse(fXmlFile);
				  System.out.println(doc);
				  System.out.println(doc.getTextContent());
				  content = doc.getTextContent();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  

		  


		return content;
	}
	
	
}
