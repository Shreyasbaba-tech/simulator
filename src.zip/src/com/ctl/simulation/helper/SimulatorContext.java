package com.ctl.simulation.helper;

import java.util.Map;

import com.ctl.simulation.action.SimulatorAction;

public class SimulatorContext {
	
	String request;
	
	String response;
	
	SimulatorAction action;

	Map<String, String> reqParamsMap;
	
	String baseFilePath;
	
	Object requestObj;
	
	String beanId;
	
	
	
	public Object getRequestObj() {
		return requestObj;
	}

	public void setRequestObj(Object requestObj) {
		this.requestObj = requestObj;
	}

	public Map<String, String> getReqParamsMap() {
		setReqParamsMap();
		return reqParamsMap;
	}

	public void setReqParamsMap() {
		this.reqParamsMap = getAction().extractRequestInfo(getAction().getReqParams(), this.request);
	}

	public SimulatorAction getAction() {
		return action;
	}

	public void setAction(SimulatorAction action) {
		this.action = action;
	}

		public String getBaseFilePath() {
		return baseFilePath;
	}

	public void setBaseFilePath(String baseFilePath) {
		this.baseFilePath = baseFilePath;
	}
	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getBeanId() {
		return beanId;
	}

	public void setBeanId(String beanId) {
		this.beanId = beanId;
	}
	
	
}
