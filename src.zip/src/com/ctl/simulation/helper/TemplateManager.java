package com.ctl.simulation.helper;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;




public class TemplateManager {


	public static void main (String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException{
		
//	/*	NodeList nodeList =searchTags();
//		setTagValuesFromRequest(nodeList);*/
//		File file = new File("response.xml");
//		String responseXml=XPathReader.getFileAsString(file);
//		file=new File("request.xml");
//		String requestXml=XPathReader.getFileAsString(file);
//		String resp = applyTemplate(responseXml,requestXml);
//		System.out.println(resp);
	}

/*	private void setTagValuesFromRequest(NodeList nodeList,String requestXml) {
		NodeList nodes = (NodeList) nodeList;
		for (int i = 0; i < nodes.getLength(); i++) {

			String value = XPathReader.xmlParser(nodes.item(i).getNodeName(), requestXml);
		}

	}
*/
	public static String applyTemplate(String responseXml, String requestXml)throws ParserConfigurationException, SAXException, IOException, XPathExpressionException{
		XpathUtil xpathUtil = new XpathUtil();
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		domFactory.setNamespaceAware(true); 
		DocumentBuilder builder = domFactory.newDocumentBuilder();
		Document doc = builder.parse("response.xml");

		XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();
		XPathExpression expr 
		= xpath.compile("//*[.='$reqParam']");

		Object result = expr.evaluate(doc, XPathConstants.NODESET);
		NodeList nodes = (NodeList) result;
		for (int i = 0; i < nodes.getLength(); i++) {
			String nodeName = nodes.item(i).getNodeName(); 
			String requestValue = xpathUtil.retrieveElementValue(nodeName, requestXml);
			
			String toBeReplacedString = "<"+nodeName+">$reqParam</"+nodeName+">";
			String replaceString = "<"+nodeName+">" + requestValue +"</"+nodeName+">";
			
			responseXml = responseXml.replace(toBeReplacedString, replaceString);
			
		}
		return responseXml;
	}
}

