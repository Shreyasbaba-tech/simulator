package com.ctl.simulation.helper;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.apache.commons.exec.Executor;

public class ConverterUtil {
public static void main(String[] args)
{
	File f=new File("C:\\Users\\aa49473\\Desktop\\books.xsd");
	ConverterUtil util=new ConverterUtil();
	File f2=util.xsdToXml(f,"books");
}
	public File xsdToXml(File xsd,String rootElement)
	{
		String xsdPath=xsd.getPath();
		String xsdName=xsd.getName();
		System.out.println(xsdName);
		String xigName=xsdName.replace(".xsd", ".xig");
		System.out.println(xsdPath);
		String workingDirectoryPath=xsdPath.substring(0, xsdPath.lastIndexOf("\\"));
		System.out.println(workingDirectoryPath);
		Executor exec = new DefaultExecutor();
		exec.setWorkingDirectory(new File(workingDirectoryPath));
		String command="java -jar xig.jar "+xsdName+" "+rootElement+" "+xigName;
		boolean res=insertCommandToBatchFile(command, workingDirectoryPath);
		System.out.println(res);
		CommandLine cl=new CommandLine(new File(workingDirectoryPath+"\\cmd.bat"));
		try {
			int exitvalue = exec.execute(cl);
		} catch (ExecuteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boolean renameRes=rename(xsdPath);
		System.out.println(res);
		return xsd;
	}
	
	public boolean rename(String xsdPath)
	{
		String xigPath=xsdPath.replace(".xsd",".xsd.xml");
		File xigFile=new File(xigPath);
		File xmlFile=new File(xigPath.replace(".xsd.xml", ".xml"));
		xigFile.renameTo(xmlFile);
		File tempFile=new File(xigPath.replace(".xsd.xml", ".xsd.xig"));// deleting the .xig file created by the jar
		tempFile.delete();
		return true;
	}
	
	public boolean insertCommandToBatchFile(String cmd,String workingDirectory)
	{
		BufferedWriter out;
		try {
			out = new BufferedWriter(new FileWriter(workingDirectory+"\\cmd.bat"));
			 out.write(cmd);
			 out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	
}
